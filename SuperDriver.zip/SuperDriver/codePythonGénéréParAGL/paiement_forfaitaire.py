#!/usr/bin/python
#-*- coding: utf-8 -*-

from paiement import paiement

class paiement_forfaitaire(paiement):
    pass
