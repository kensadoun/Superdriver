#!/usr/bin/python
#-*- coding: utf-8 -*-

class passer:
    def __init__(self):
        self.resultat = None

