#!/usr/bin/python
#-*- coding: utf-8 -*-

class vehicule:
    def __init__(self):
        self.matricule = None
        self.marque = None
        self.categorie = None
        self.nombre_de_place = None
        self.poids_total = None
        self.en_fonction = None

