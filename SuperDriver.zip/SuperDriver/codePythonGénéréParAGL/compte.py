#!/usr/bin/python
#-*- coding: utf-8 -*-

class compte:
    def __init__(self):
        self.numero_utilisateur = None
        self.mot_passe = None
        self.type_utilisateur = None
        self.adresseMailRecuperation = None

