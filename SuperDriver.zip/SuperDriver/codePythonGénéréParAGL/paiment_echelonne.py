#!/usr/bin/python
#-*- coding: utf-8 -*-

from paiement import paiement

class paiment_echelonne(paiement):
    pass
