#!/usr/bin/python
#-*- coding: utf-8 -*-

from cours import cours

class cours_code(cours):
    pass
