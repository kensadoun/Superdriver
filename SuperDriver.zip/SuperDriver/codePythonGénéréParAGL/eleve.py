#!/usr/bin/python
#-*- coding: utf-8 -*-

class eleve:
    def __init__(self):
        self.id_eleve = None
        self.nom = None
        self.prenom = None
        self.date_naissance = None
        self.nationalite = None
        self.adresse = None
        self.categorie_permis_demandee = None
        self.telephone = None
        self.existe = None

