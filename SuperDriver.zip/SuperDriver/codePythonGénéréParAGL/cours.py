#!/usr/bin/python
#-*- coding: utf-8 -*-

class cours:
    def __init__(self):
        self.id_seance = None
        self.date = None
        self.heure = None

