#!/usr/bin/python
#-*- coding: utf-8 -*-

class paiement:
    def __init__(self):
        self.id_paiement = None
        self.date_paiement = None
        self.somme = None

