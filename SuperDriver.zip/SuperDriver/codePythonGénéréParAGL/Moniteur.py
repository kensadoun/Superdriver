#!/usr/bin/python
#-*- coding: utf-8 -*-

class Moniteur:
    def __init__(self):
        self.id_moniteur = None
        self.nom = None
        self.prenom = None
        self.adresse = None
        self.numero_telephone = None
        self.categorie = None
        self.type_lecon = None
        self.en_fonction = None

