#!/usr/bin/python
#-*- coding: utf-8 -*-

class groupe:
    def __init__(self):
        self.id_groupe = None
        self.nom = None

