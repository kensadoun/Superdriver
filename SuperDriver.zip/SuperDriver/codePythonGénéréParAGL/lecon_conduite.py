#!/usr/bin/python
#-*- coding: utf-8 -*-

from cours import cours

class lecon_conduite(cours):
    def __init__(self):
        self.categorie = None
        self.type_lecon_conduite = None

