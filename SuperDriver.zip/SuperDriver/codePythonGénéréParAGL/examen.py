#!/usr/bin/python
#-*- coding: utf-8 -*-

class examen:
    def __init__(self):
        self.id_examen = None
        self.date = None
        self.categorie = None
        self.type = None
        self.centreExamen = None

