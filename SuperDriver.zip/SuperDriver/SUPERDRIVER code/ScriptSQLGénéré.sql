-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema autoEcole
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema autoEcole
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `autoEcole` ;
USE `autoEcole` ;

-- -----------------------------------------------------
-- Table `autoEcole`.`moniteur`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `autoEcole`.`moniteur` (
  `id_moniteur` INT NOT NULL,
  `nom` VARCHAR(45) NOT NULL,
  `prenom` VARCHAR(45) NOT NULL,
  `adresse` VARCHAR(45) NOT NULL,
  `numero_telephone` INT(10) NOT NULL,
  `categorie` VARCHAR(2) NULL,
  `type_lecon` VARCHAR(50) NULL,
  `en_fonction` VARCHAR(45) NULL,
  PRIMARY KEY (`id_moniteur`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `autoEcole`.`groupe`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `autoEcole`.`groupe` (
  `id_groupe` INT(11) NOT NULL,
  `nom` VARCHAR(7) NULL,
  PRIMARY KEY (`id_groupe`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `autoEcole`.`eleves`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `autoEcole`.`eleves` (
  `id_eleve` INT NOT NULL,
  `nom` VARCHAR(45) NOT NULL,
  `prenom` VARCHAR(45) NOT NULL,
  `date_naissance` DATE NOT NULL,
  `nationalite` VARCHAR(45) NOT NULL,
  `adresse` VARCHAR(45) NOT NULL,
  `catégorie_permis_demandee` VARCHAR(2) NOT NULL,
  `telephone` INT(11) NULL,
  `existe` INT(1) NULL,
  `groupe` INT(11) NOT NULL,
  PRIMARY KEY (`id_eleve`),
  UNIQUE INDEX `id_eleve_UNIQUE` (`id_eleve` ASC) VISIBLE,
  INDEX `fk_eleves_groupe1_idx` (`groupe` ASC) VISIBLE,
  CONSTRAINT `fk_eleves_groupe1`
    FOREIGN KEY (`groupe`)
    REFERENCES `autoEcole`.`groupe` (`id_groupe`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `autoEcole`.`compte`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `autoEcole`.`compte` (
  `numero_utilisateur` INT NOT NULL,
  `mot_de_passe` VARCHAR(100) NOT NULL,
  `type_utilisateur` VARCHAR(45) NOT NULL,
  `id_moniteur` INT NOT NULL,
  `id_eleve` INT NOT NULL,
  `active` INT(1) NULL,
  `adresse_recuperation` VARCHAR(100) NULL,
  PRIMARY KEY (`numero_utilisateur`),
  INDEX `fk_compte_moniteur1_idx` (`id_moniteur` ASC) VISIBLE,
  INDEX `fk_compte_eleves1_idx` (`id_eleve` ASC) VISIBLE,
  CONSTRAINT `fk_compte_moniteur1`
    FOREIGN KEY (`id_moniteur`)
    REFERENCES `autoEcole`.`moniteur` (`id_moniteur`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_compte_eleves1`
    FOREIGN KEY (`id_eleve`)
    REFERENCES `autoEcole`.`eleves` (`id_eleve`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `autoEcole`.`cours_code`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `autoEcole`.`cours_code` (
  `id_seance` INT NOT NULL,
  `date` DATE NOT NULL,
  `heure` TIME NOT NULL,
  `id_moniteur` INT NOT NULL,
  PRIMARY KEY (`id_seance`),
  UNIQUE INDEX `id_seance_UNIQUE` (`id_seance` ASC) VISIBLE,
  INDEX `fk_cours_code_moniteur1_idx` (`id_moniteur` ASC) VISIBLE,
  CONSTRAINT `fk_cours_code_moniteur1`
    FOREIGN KEY (`id_moniteur`)
    REFERENCES `autoEcole`.`moniteur` (`id_moniteur`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `autoEcole`.`concerner_cours_code`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `autoEcole`.`concerner_cours_code` (
  `id_seance` INT NOT NULL,
  `id_eleve` INT NOT NULL,
  PRIMARY KEY (`id_seance`, `id_eleve`),
  INDEX `fk_cours_code_has_eleves_eleves1_idx` (`id_eleve` ASC) VISIBLE,
  INDEX `fk_cours_code_has_eleves_cours_code1_idx` (`id_seance` ASC) VISIBLE,
  CONSTRAINT `fk_cours_code_has_eleves_cours_code1`
    FOREIGN KEY (`id_seance`)
    REFERENCES `autoEcole`.`cours_code` (`id_seance`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_cours_code_has_eleves_eleves1`
    FOREIGN KEY (`id_eleve`)
    REFERENCES `autoEcole`.`eleves` (`id_eleve`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `autoEcole`.`vehicule`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `autoEcole`.`vehicule` (
  `matricule` INT NOT NULL,
  `marque` VARCHAR(45) NOT NULL,
  `categorie` VARCHAR(45) NOT NULL,
  `nombre_de_places` INT(3) NULL,
  `poids_total` DECIMAL(5,2) NULL,
  `en_fonction` INT(1) NULL,
  PRIMARY KEY (`matricule`),
  UNIQUE INDEX `matricule_UNIQUE` (`matricule` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `autoEcole`.`lecons_conduite`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `autoEcole`.`lecons_conduite` (
  `id_seance` INT NOT NULL,
  `date` DATE NOT NULL,
  `heure` TIME NOT NULL,
  `type_lecon_conduite` VARCHAR(45) NULL,
  `categorie` VARCHAR(2) NOT NULL,
  `id_moniteur` INT NOT NULL,
  `eleves_id_eleve` INT NOT NULL,
  `vehicule_matricule` INT NOT NULL,
  PRIMARY KEY (`id_seance`),
  INDEX `fk_lecons_conduite_moniteur1_idx` (`id_moniteur` ASC) VISIBLE,
  INDEX `fk_lecons_conduite_eleves1_idx` (`eleves_id_eleve` ASC) VISIBLE,
  INDEX `fk_lecons_conduite_vehicule1_idx` (`vehicule_matricule` ASC) VISIBLE,
  CONSTRAINT `fk_lecons_conduite_moniteur1`
    FOREIGN KEY (`id_moniteur`)
    REFERENCES `autoEcole`.`moniteur` (`id_moniteur`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_lecons_conduite_eleves1`
    FOREIGN KEY (`eleves_id_eleve`)
    REFERENCES `autoEcole`.`eleves` (`id_eleve`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_lecons_conduite_vehicule1`
    FOREIGN KEY (`vehicule_matricule`)
    REFERENCES `autoEcole`.`vehicule` (`matricule`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `autoEcole`.`examen`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `autoEcole`.`examen` (
  `id_examen` INT NOT NULL,
  `date` VARCHAR(45) NOT NULL,
  `categorie` VARCHAR(2) NOT NULL,
  `type` VARCHAR(45) NOT NULL,
  `centre_examen` VARCHAR(45) NULL,
  PRIMARY KEY (`id_examen`),
  UNIQUE INDEX `id_examen_UNIQUE` (`id_examen` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `autoEcole`.`passer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `autoEcole`.`passer` (
  `id_eleve` INT NOT NULL,
  `examen_id_examen` INT NOT NULL,
  `resultat` INT(1) NULL,
  PRIMARY KEY (`id_eleve`, `examen_id_examen`),
  INDEX `fk_eleves_has_examen_examen1_idx` (`examen_id_examen` ASC) VISIBLE,
  INDEX `fk_eleves_has_examen_eleves1_idx` (`id_eleve` ASC) VISIBLE,
  CONSTRAINT `fk_eleves_has_examen_eleves1`
    FOREIGN KEY (`id_eleve`)
    REFERENCES `autoEcole`.`eleves` (`id_eleve`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_eleves_has_examen_examen1`
    FOREIGN KEY (`examen_id_examen`)
    REFERENCES `autoEcole`.`examen` (`id_examen`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `autoEcole`.`paiement_forfaitaire`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `autoEcole`.`paiement_forfaitaire` (
  `id_paiement` INT NOT NULL,
  `date_paiement` DATE NULL,
  `somme` INT(11) NULL,
  `id_eleve` INT NOT NULL,
  PRIMARY KEY (`id_paiement`),
  INDEX `fk_paiement_forfaitaire_eleves1_idx` (`id_eleve` ASC) VISIBLE,
  CONSTRAINT `fk_paiement_forfaitaire_eleves1`
    FOREIGN KEY (`id_eleve`)
    REFERENCES `autoEcole`.`eleves` (`id_eleve`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `autoEcole`.`paiement_echelonne`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `autoEcole`.`paiement_echelonne` (
  `id_paiement` INT NOT NULL,
  `date_paiement` DATE NULL,
  `somme` INT(11) NULL,
  `id_eleve` INT NOT NULL,
  `id_examen` INT NOT NULL,
  PRIMARY KEY (`id_paiement`),
  INDEX `fk_paiement_echelonne_eleves1_idx` (`id_eleve` ASC) VISIBLE,
  INDEX `fk_paiement_echelonne_examen1_idx` (`id_examen` ASC) VISIBLE,
  CONSTRAINT `fk_paiement_echelonne_eleves1`
    FOREIGN KEY (`id_eleve`)
    REFERENCES `autoEcole`.`eleves` (`id_eleve`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_paiement_echelonne_examen1`
    FOREIGN KEY (`id_examen`)
    REFERENCES `autoEcole`.`examen` (`id_examen`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE USER 'user1';


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
