<?php
session_start();
if(!isset($_SESSION['nom'])){
  header("location:../connexion.php",true);
}
else{
  $username="user1";
  $passeword="user1";
  $BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);
  //$eleves=$BDD->prepare("SELECT * FROM eleves ");
  //$eleves->execute();
  if(isset($_GET["supp"]) && isset($_GET["type"]) ){
    $id=$_GET["supp"];
    if($_GET["type"]=="cours_code"){
      ini_set('display_errors',1);
      error_reporting(E_ALL);
      $cours=$BDD->prepare("DELETE FROM cours_code where id_seance=:id ");
      $cours->bindParam("id",$id);
      $cours->execute();
      header("location:secritaire/code.php",true);
    }
    elseif($_GET["type"]=="lecon_conduite"){
      ini_set('display_errors',1);
      error_reporting(E_ALL);
      $conduite=$BDD->prepare("DELETE FROM  lecons_conduite where id_seance=:id ");
      $conduite->bindParam("id",$id);
      $conduite->execute();
      header("location:secritaire/conduite.php",true);

    }
    elseif($_GET["type"]=="eleve"){
      ini_set('display_errors',1);
      error_reporting(E_ALL);
      $eleve=$BDD->prepare("UPDATE eleves set existe=0 where id_eleve=:id");
      $eleve->bindParam("id",$id);
      $eleve->execute();
      $compte=$BDD->prepare("DELETE from compte where id_eleve=:id");
      $compte->bindParam("id",$id);
      $compte->execute();
      header("location: secritaire/index.php",true);
    }
    elseif($_GET["type"]=="paiement"){
      ini_set('display_errors',1);
      error_reporting(E_ALL);
      $paiement=$BDD->prepare("DELETE FROM paiement_echelonne where id_paiement=:id");
      $paiement->bindParam("id",$id);
      $paiement->execute();
      header("location:secritaire/payement.php",true);
    }
    elseif($_GET["type"]=="moniteur"){
      ini_set('display_errors',1);
      error_reporting(E_ALL);

      $moniteur=$BDD->prepare("UPDATE moniteur set en_fonction=0 where id_moniteur=:id");
      $moniteur->bindParam("id",$id);
      $moniteur->execute();

      $compte=$BDD->prepare("UPDATE compte set active=0  where id_moniteur=:id");
      $compte->bindParam("id",$id);
      $compte->execute();
      header("location:secritaire/moniteur.php",true);
    }
    elseif($_GET["type"]=="vehicule"){
      ini_set('display_errors',1);
      error_reporting(E_ALL);
      $vehicule=$BDD->prepare("UPDATE vehicule set en_fonction=0 where matricule=:id");
      $vehicule->bindParam("id",$id);
      $vehicule->execute();
      header("location: secritaire/vehicule.php",true);
    }
  
    /*elseif($_GET["type"]=="eleve"){
      ini_set('display_errors',1);
      error_reporting(E_ALL);
      $eleve=$BDD->prepare("UPDATE eleves set existe=0 where id_eleve=:id");
      $eleve->bindParam("id",$id);
      $eleve->execute();
      $compte=$BDD->prepare("DELETE from compte where id_eleve=:id");
      $compte->bindParam("id",$id);
      $compte->execute();
      header("location: secritaire/index.php",true);
    }
      /*$ident=$_GET["supp"];
      $compte=$BDD->prepare("UPDATE compte set id_eleve =NULL where id_eleve=:id_e");
      $compte->bindParam("id_e",$ident);
      $compte->execute();
      $supp=$BDD->prepare("DELETE FROM eleves where id_eleve=:id");
      $supp->bindParam("id",$ident);
      $supp->execute();
      header("location:secritaire/index.php",true);*/
    //}
  }

  //if(isset($_GET["type"])){

  //}
}
?>