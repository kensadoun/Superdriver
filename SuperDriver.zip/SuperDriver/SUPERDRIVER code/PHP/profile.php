<?php
session_start();
ob_start();
require_once "connexionBDD.php";
/*$username="user1";
$passeword="user1";
$BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="../css/bootstrap.min.profile.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/profile.css">


</head> 
<body>
<div class="posP">
    <div class="posF nav-item dropdown">
        <a href="#" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action">
            <img src="image/person.svg" class="person">
            <b> <?php echo $_SESSION["nom"] ?></b>
            </a>
            <div class="dropdown-menu">
                <a href="profile.php" class="dropdown-item"> <img src="image/person-gear.svg" /> <i class="fa fa-user-o"></i> Profile</a>
                <div class="divider dropdown-divider"></div>
                <a href="deconnexion.php" class="dropdown-item"><i class="material-icons"><img src="image/box-arrow-right.svg" /></i> Déconnexion</a>
            </div>
    </div>
</div>

<div class="container-xl px-4 mt-4">    
    <div class="row">
        <div class="col-xl-8">
            <div class="card mb-4">
                <div class="card-header">Information du compte</div>
                <div class="card-body">
                    <form id="f1" name="modification" method="POST">
                        <div class="row gx-3 mb-3">
                            <div class="col-md-6">
                                <label class="small mb-1" for="inputFirstName">Numero d'utilisateur</label>
                                <input class="form-control" id="inputFirstName" name="identifiant" type="text" placeholder="Enter your first name" value="<?= $_SESSION['numero_utilisateur'] ?>" readonly="true">
                            </div>
                            <div class="col-md-6">
                                <label class="small mb-1" for="inputEmailAddress">Type utilisateur</label>
                                <input class="form-control" id="inputEmailAddress"  type="text" placeholder="Enter your email address" value="<?= $_SESSION['type_utilisateur'] ?>" disabled>  
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="small mb-1" for="inputLastName">Adresse mail de récupération</label>
                            <input class="form-control" id="inputLastName" name="adresse" type="text" placeholder="Enter your last name" value="<?=  $_SESSION['adresse_recuperation'] ?>" >
                        </div>
                        <div class="mb-3">
                            <label class="small mb-1" for="inputEmailAddress">Mot de passe</label>
                            <input class="form-control " id="inputEmailAddress" type="password" placeholder="Enter your email address" value="<?= $_SESSION['mot_de_passe'] ?>"  readonly="true">
                            
                        </div>
                        <div class="row gx-3 mb-3">
                            <div class="col-md-6">
                                <label class="small mb-1" for="inputPassword">Nouveau mot de passe</label>
                                <input class="form-control nouveauMotPasse" id="inputPassword"  type="password"  >
                                <span class="error_mot_passe" />
                                
                            </div>
                            <div class="col-md-6">
                                <label class="small mb-1" for="inputPassword2">Confirmer le nouveau mot de passe</label>
                                <input class="form-control nouveauMotPasse" id="inputPassword2" name="nouveau" type="password" name="birthday"  >
                                <span class="error_mot_passe" />
                            </div>
                        </div>
                        <button class="btn btn-primary" type="submit" name="enregistrer" >Enregistrer </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
                    <script src="../javascript/profile.js"  >
     
                    </script>
                    <script src="main.js"></script>
                    
                    <script src="../javascript/jquery.min.js"></script>
                    <script src="../javascript/popper.min.js"></script>
                    <script src="../javascript/bootstrap.min.js"></script>
                    <script src="../javascript/bootstrap.bundle.min.js"></script>
                    <script src="../javascript/select2.min.js"></script>
                    
</body>
</html>
<?php
        error_reporting(E_ALL);
        ini_set('display_errors','On');
        if(isset($_POST["adresse"]) && isset($_POST["nouveau"])){
            error_reporting(E_ALL);
            ini_set('display_errors','On');
            $mot_de_passe=password_hash($_POST["nouveau"],PASSWORD_DEFAULT);
            $compte=$BDD->prepare("UPDATE compte set adresse_recuperation=:adresse ,mot_de_passe=:mot_passe where numero_utilisateur=:identifiant");
            $compte->bindParam("adresse",$_POST["adresse"]);
            $compte->bindParam("mot_passe",$mot_de_passe);
            $compte->bindParam("identifiant",$_SESSION['numero_utilisateur']);
            $compte->execute();
            $_SESSION['mot_de_passe']=$_POST["nouveau"];
        }
    
    ob_end_flush();
?>



