<?php
session_start();
if(!isset($_SESSION['nom'])){
    header("location:../connexion.php",true);
}
else{
echo "<h1>numero d'utilisateur=".$_SESSION['numero_utilisateur']."</h1> 
      <h1>type d'utilisateur=".$_SESSION['type_utilisateur']."</h1>";
}
?>