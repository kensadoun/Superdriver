<?php
session_start();
if(!isset($_SESSION["id_eleve"])){
    header("location:../login/PHP/connexion.php",true);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title>Auto-ecole</title>
    <link rel="stylesheet" type="text/css" href="stylecondidat.css">
    <link rel="stylesheet" type="text/css" href="stylecondidat.css">
    <link rel="stylesheet" type="text/css" media="screen" href="profile_et_deconnexion.css">
    
</head>
<header class="mainhead">
    <nav>
        <img src="logo.png" alt="Description de l'image" class="logo">
        
    </nav>

</header>
<body >
<?php
    session_start();
    ini_set('display_errors',1);
    error_reporting(E_ALL);
    $username="user1";
    $passeword="user1";
    $BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);
    $nbre_passer=$BDD->prepare("SELECT COUNT(p.id_eleve) as nb_pa from passer p where p.id_eleve=:id ");
    $nbre_passer->bindParam("id",$_SESSION["id_eleve"]);
    $nbre_passer->execute();

    $nbr_p=$nbre_passer->fetchObject();
    $nbre_pe=$BDD->prepare("SELECT COUNT(pe.eleve) as nb_pe from paiement_echelonne pe where pe.eleve=:id ");
    $nbre_pe->bindParam("id",$_SESSION["id_eleve"]);
    $nbre_pe->execute();

    $nbre_pae=$nbre_pe->fetchObject();

    $nbre_pf=$BDD->prepare("SELECT COUNT(pf.id_eleve) as nb_pf  from paiement_forfaitaire pf where pf.id_eleve=:id");
    $nbre_pf->bindParam("id",$_SESSION["id_eleve"]);
    $nbre_pf->execute();
    $nbr_paf=$nbre_pf->fetchObject();

    $nombre=$nbr_p->nb_pa-$nbr_paf->nb_pf-$nbre_pae->nb_pe;

    if($nombre>0){
?>
    <center id="rappel" >IMPORTANT!: MONSIEUR <?=$_SESSION["nom"]?> <? echo " "?><?=$_SESSION["prenom"] ?>,NOUS VOUS DEMANDONS DE BIEN VOULOIR RÉGULARISER VOTRE SITUATION DANS LES MEILLEURS DÉLAIS.</center>
    <?php
        }
    ?> 


   
 <CEnter><p id="titre">  <STrong>Bienvenue<?=$_SESSION["id_eleve"]?>  </STrong>  </p></CEnter>

 <div class="posP">
                    <div class="posF nav-item dropdown">
                        <a href="#" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action">
                            <img src="../image/person.svg" class="person">
                            <b> Secrétaire</b>
                        </a>
                        <div class="dropdown-menu">
                            <a href="#" class="dropdown-item"> <img src="../image/person-gear.svg" /> <i class="fa fa-user-o"></i> Profile</a>
                            <div class="divider dropdown-divider"></div>
                            <a href="../deconnexion.php" class="dropdown-item"><i class="material-icons"><img src="../image/box-arrow-right.svg" /></i> Déconnexion</a>
                        </div>
                    </div>
                </div>

<div class="boite1">

    <center>
        <p class="contenu"> <br> <strong>Informations personnelles</strong> <br> <br>
        </p>
         <a href="infosPersonnelles.php"><img src="man (2).png" alt="Description de l'image" class="icon"></a>
    </center>
       
</div>

<div class="boite1">
    <center><p class="contenu"> <br> <strong>COURS</strong> <br> <br>
        </p>
         <a href="https://www.php.net/manual/en/pdostatement.fetchall.php"><img src="book.png" alt="Description de l'image" class="icon"></a>
    </center>
        
</div>

<div class="boite1">
    <center><p class="contenu"> <br> <strong> PLANNING </strong> <br><br>
        </p>
        <a href="planning.php"><img src="planning.png" alt="Description de l'image" class="icon"></a>
    </center>    
</div>

<div class="boite2">
    <a href="examen.php">
        <center>
            <p class="contenu"> <br> <strong> Examen </strong> <br><br>
            </p>
            <img src="man (2).png" alt="Description de l'image" class="icon"></a>
        </center>
    </a>    
</div>

<div class="boite2">
<a href="resultats.php">
    <center><p class="contenu"> <br>  <strong> RESAULTATS </strong> <br> <br>
       <p>
            <img src="result.png" alt="Description de l'image" class="icon">
    </center>    
    </a>
</div>
