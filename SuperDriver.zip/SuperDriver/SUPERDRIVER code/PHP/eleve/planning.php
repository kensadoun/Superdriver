<?php
session_start();
if(!isset($_SESSION["id_eleve"])){
    header("location:../login/PHP/connexion.php",true);
}
else{
    ini_set('display_errors',1);
    error_reporting(E_ALL);
    require_once 'controller/planningController.php';
    planningAction();
}
?>