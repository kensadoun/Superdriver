<?php
    require_once 'model/planningModel.php';
    function planningAction(){
        [$grp,$code,$conduite]=planning();
        require_once 'view/planningView.php';
        return [$grp,$code,$conduite];
    }
?>