<?php
    require_once 'model/resultatModel.php';
    function resultatAction(){
        $resultats=resultat();
        require_once 'view/resultatsView.php';
        return $resultats;
    }
?>