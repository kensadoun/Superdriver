<?php
    require_once 'model/examenModel.php';
    function examenAction(){
        $examens=examen();
        require_once 'view/examenView.php';
        return $examens;
    }
?>