<?php
    require_once 'model/infosPersonnellesModel.php';
    function infosPersonnellesAction(){
        $infos=informationsPersonnelles();
        require_once 'view/infosPersonnellesView.php';
        return $infos;
    }
?>