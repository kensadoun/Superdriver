<?php

    $titre="Planning";
    ob_start();
?>

<?php
    if($code->rowCount()==0 ){
?>
    <centre >AUCUN RESULTAT TROUVÉ</centre>
<?php
    }
    else{
?>

<div class="container">
    <table class="table " id="masque">
        <thead>
            <tr>
                <th scope="col">code séance</th>
                <th scope="col">Date</th>
                <th scope="col">Heure</th>
                <th scope="col">Moniteur</th>
                <th scope="col">Type de lecon</th>
            </tr>
        </thead>
        <tbody>
            
            <?php
                if($conduite->rowCount()>0){
                    foreach($conduite AS $result){
                        
            ?>
            <tr>
                <th class="th1" scope="row"><?= $result["id_seance"];?></th>
                    <td class="td1"><?= $result["date"];?></td>
                    <td><?= $result["heure"];?></td>
                    <td><?= $result["nom" ];?><php echo " " ?><?= $result["prenom"]?></td>
                    <td><?=$result["type_lecon"]; ?></td>
                </th>
            <?php }}
            
            if($code->rowCount()>0){
                foreach($code AS $result){
                    
        ?>
        <tr>
            <th class="th1" scope="row"><?= $result["id_seance"];?></th>
                <td class="td1"><?= $result["date"];?></td>
                <td><?= $result["heure"];?></td>
                <td><?= $result["nom" ];?><php echo " " ?><?= $result["prenom"]?></td>
                <td>code</td>
            </th>
            
           <?php }}?>
            </tr>
        </tbody>
    </table>
    <?php }?>
</div>

<?php $contenu=ob_get_clean();?>
<?php include_once 'view/layout.php'; ?>