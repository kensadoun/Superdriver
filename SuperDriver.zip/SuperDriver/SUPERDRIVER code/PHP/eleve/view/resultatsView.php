<?php

    $titre="Resultats";
    ob_start();
?>

<?php
    if($resultats->rowCount()==0){
?>
    <centre >AUCUN RESULTAT TROUVÉ</centre>
<?php
    }
    else{
?>

<div class="container">
    <table class="table " id="masque">
        <thead>
            <tr>
                <th scope="col">code examen</th>
                <th scope="col">Date</th>
                <th scope="col">Type</th>
                <th scope="col">Résultat</th>
            </tr>
        </thead>
        <tbody>
           
            <?php
                
                    foreach($resultats AS $result){
                        if($result["etat"]==1){
                            $etat="Réussi";
                            $couleur="green";
                        }
                        elseif($result["etat"]==0){
                            $etat="Echoué";
                            $couleur="red";
                        }
                        else{
                            $etat="pas encore";
                            $couleu="orange";
                        }
            ?>
            <tr>
                <th class="th1" scope="row"><?= $result["id_examen"];?></th>
                    <td class="td1" ><?= $result["date"];?></td>
                    <td class="td1"  ><?= $result["type"];?></td>
                    <td style="color:<?=$couleur?>"  ?><?=$etat;?></td>
                </th>
            <?php } ?>
            </tr>
        </tbody>
    </table>
    <?php }?>
</div>

<?php $contenu=ob_get_clean();?>
<?php include_once 'view/layout.php'; ?>