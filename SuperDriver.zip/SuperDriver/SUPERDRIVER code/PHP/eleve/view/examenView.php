<?php

    $titre="Examens";
    ob_start();
?>

<?php
    if($examens->rowCount()==0){
?>
    <centre >AUCUN RESULTAT TROUVÉ</centre>
<?php
    }
    else{
?>

<div class="container">
    <table class="table " id="masque">
        <thead>
            <tr>
                <th scope="col">code examen</th>
                <th scope="col">Date</th>
                <th scope="col">Catégorie</th>
                <th scope="col">Type</th>
            </tr>
        </thead>
        <tbody>
           
            <?php
                
                    foreach($examens AS $result){
                        if($result["etat"]==1){
                            $etat="Réussi";
                        }
                        elseif($result["etat"]==0){
                            $etat="Echoué";
                        }
                        else{
                            $etat="Pas encore";
                        }
            ?>
            <tr>
                <th class="th1" scope="row"><?= $result["id"];?></th>
                    <td class="td1"><?= $result["date"];?></td>
                    <td><?= $result["categorie"];?></td>
                    <td><?=$result["type"]; ?></td>
                </th>
            <?php } ?>
            </tr>
        </tbody>
    </table>
    <?php }?>
</div>

<?php $contenu=ob_get_clean();?>
<?php include_once 'view/layout.php'; ?>