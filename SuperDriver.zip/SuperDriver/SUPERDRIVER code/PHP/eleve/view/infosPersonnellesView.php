<?php

    $titre="Informations personnelles";
    ob_start();
?>
 <head>
        <link rel="stylesheet" href="../../login/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link href="../../login/css/select2.min.css" rel="stylesheet" />
            
             <link rel="stylesheet" type="text/css" media="screen" href="infosPersonnelles.css">
             <script src="main.js"></script>
                <title>Interface eleves</title>
            
            </head>
<?php
    if($infos->rowCount()==0){
?>
    <centre >AUCUN RESULTAT TROUVÉ</centre>


                    <?php

                        }
                        else{ 
                    ?>                 
                            <div class="infos">
                                <table class="table">  
                                <?php
                                    foreach($infos AS $result){       
                                ?>
                                <tr>
                                    <td class="critere">Nom</td>   
                                    <td><?=$result["nom"] ?></td>  
                                </tr>

                                <tr>
                                    <td class="critere">Prénom</td>   
                                    <td><?=$result["prenom"] ?></td>  
                                </tr>

                                <tr>
                                    <td class="critere">Date de naissance</td>   
                                    <td><?=$result["date_naissance"] ?></td>  
                                </tr>

                                <tr>
                                    <td class="critere">Nationalité</td>   
                                    <td><?=$result["nationalite"] ?></td>  
                                </tr>

                                <tr>
                                    <td class="critere">Adresse</td>   
                                    <td><?=$result["adresse"] ?></td>  
                                </tr>

                                <tr>
                                    <td class="critere">Numero de télephone </td>   
                                    <td><?=$result["telephone"] ?></td>  
                                </tr>

                                <tr>
                                    <td class="critere">Catégorie de permis demandée</td>   
                                    <td><?= $result["catégorie_permis_demandee"] ?></td>  
                                </tr>

                                <tr>
                                    <td class="critere">Groupe</td>   
                                    <td><?= $result["groupe"] ?></td>  
                                </tr>
                            <?php } ?>
                    </table>

                </div>
        <tbody>
           
           
            
    <?php }?>
</div>

<?php $contenu=ob_get_clean();?>
<?php include_once 'view/layout.php'; ?>