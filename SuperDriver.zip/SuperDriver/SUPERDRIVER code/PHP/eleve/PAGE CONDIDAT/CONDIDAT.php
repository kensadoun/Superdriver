<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title>Auto-ecole</title>
    <link rel="stylesheet" type="text/css" href="stylecondidat.css">

    
</head>
<header class="mainhead">
    <nav>
        <img src="logo.png" alt="Description de l'image" class="logo">
        
    </nav>

</header>
<body >
    
   
 <CEnter><p id="titre">  <STrong> bienvenue [ID]</STrong>  </p></CEnter>


<div class="boite1">
   <center> <p class="contenu"> <br>  <strong>  MES INFORMATION </strong> 
            </br><br>
            </p>
            <img src="man (2).png" alt="Description de l'image" class="icon">        
    </center>
</div>

<div class="boite1">
    <center><p class="contenu"> <br> <strong>COURS</strong> <br> <br>
        </p>
         <a href=""><img src="book.png" alt="Description de l'image" class="icon"></a>
    </center>
        
</div>

<div class="boite1">
    <center><p class="contenu"> <br> <strong> PLANNING </strong> <br><br>
        </p>
        <a href="eleve.html"><img src="planning.png" alt="Description de l'image" class="icon"></a>
    </center>    
</div>

<div class="boite2">
    <center><p class="contenu"> <br> <strong> EXAMENS  </strong>  <br><br>
        </p>
        <a href=""><img src="exam.png" alt="Description de l'image" class="icon"></a>
    </center>    
</div>

<div class="boite2">
    <center><p class="contenu"> <br>  <strong> RESAULTATS </strong> <br> <br>
       <p>
        <a href=""><img src="result.png" alt="Description de l'image" class="icon"></a>
    </center>    
</div>
