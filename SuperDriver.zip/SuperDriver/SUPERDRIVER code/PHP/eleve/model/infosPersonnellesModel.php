<?php
    function connexion(){
        $username="user1";
        $passeword="user1";
        return new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);
    }

    function informationsPersonnelles(){
        $BDD=connexion();
        $infos=$BDD->prepare("SELECT * from  eleves  where id_eleve=:id");
        $infos->bindParam("id",$_SESSION["id_eleve"]);
        $infos->execute();
        return $infos;
    }
?>