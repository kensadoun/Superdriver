<?php
    function connexion(){
        $username="user1";
        $passeword="user1";
        return new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);
    }

    function planning(){
        $BDD=connexion();
        $groupe=$BDD->prepare("SELECT e.groupe as id_groupe,g.nom as nom from groupe g,eleves e where g.id_groupe=e.groupe and e.id_eleve=:id");
        $groupe->bindParam("id",$_SESSION["id_eleve"]);
        $groupe->execute();

        $grp=$groupe->fetchObject();
        $code=$BDD->prepare("SELECT c.id_seance as id_seance ,c.date as date,c.heure as heure,c.id_moniteur as id_moniteur,m.nom as nom,m.prenom as prenom from cours_code c,moniteur m where c.id_moniteur=m.id_moniteur and c.id_groupe=:id  ORDER BY c.date DESC;");
        $code->bindParam("id",$grp->id_groupe);
        $code->execute();

        $conduite=$BDD->prepare("SELECT c.id_seance as id_seance,c.date as date ,c.heure as heure,c.type_lecon_conduite as type_lecon,m.id_moniteur as id_moniteur,m.nom as nom ,m.prenom  as prenom from lecons_conduite c ,moniteur m where m.id_moniteur=c.id_moniteur and c.id_eleve=:id ORDER BY c.date DESC");
        $conduite->bindParam("id",$_SESSION["id_eleve"]);
        $conduite->execute();
        return [$grp->nom,$code,$conduite];
    }
?>