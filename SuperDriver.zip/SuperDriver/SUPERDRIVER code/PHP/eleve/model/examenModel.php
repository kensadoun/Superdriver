<?php
    function connexion(){
        $username="user1";
        $passeword="user1";
        return new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);
    }

    function examen(){
        $BDD=connexion();
        $examen=$BDD->prepare("SELECT ex.id_examen as id ,ex.date as date ,ex.categorie as categorie,ex.type as type ,p.etat as etat from examen ex,passer p,eleves e where ex.id_examen=p.id_examen and e.id_eleve=p.id_eleve and p.id_eleve=:id");
        $examen->bindParam("id",$_SESSION["id_eleve"]);
        $examen->execute();
        return $examen;
    }
?>