<?php
    function connexion(){
        $username="user1";
        $passeword="user1";
        return new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);
    }

    function resultat(){
        $BDD=connexion();
        $results=$BDD->prepare("SELECT ex.id_examen,ex.date as date ,ex.type as type ,p.etat as etat from examen ex,passer p,eleves e where ex.id_examen=p.id_examen and e.id_eleve=p.id_eleve and p.id_eleve=:id");
        $results->bindParam("id",$_SESSION["id_eleve"]);
        $results->execute();
        return $results;
    }
?>