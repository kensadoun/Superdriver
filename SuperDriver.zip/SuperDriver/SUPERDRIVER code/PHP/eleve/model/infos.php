<!DOCTYPE html>
    <head>
        <link rel="stylesheet" href="../../login/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link href="../../login/cc/select2.min.css" rel="stylesheet" />
            
             <link rel="stylesheet" type="text/css" media="screen" href="../../login/css/admin2.css">
             <script src="main.js"></script>
                <title>Interface eleves</title>
            
            </head>
            <body>
                <div class="posP">
                    <div class="posF nav-item dropdown">
                        <a href="#" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action">
                            <img src="../image/person.svg" class="person">
                            <b> Secrétaire</b>
                        </a>
                        <div class="dropdown-menu">
                            <a href="#" class="dropdown-item"> <img src="../image/person-gear.svg" /> <i class="fa fa-user-o"></i> Profile</a>
                            <div class="divider dropdown-divider"></div>
                            <a href="../deconnexion.php" class="dropdown-item"><i class="material-icons"><img src="../image/box-arrow-right.svg" /></i> Déconnexion</a>
                        </div>
                    </div>
                </div>
                

                <p class="titre"><?= $titre ?></p>

                <div><?= $contenu ?></div>
            </body>
</html>