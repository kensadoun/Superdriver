<?php
ob_start();
ini_set('display_errors',1);
$username="user1";
$passeword="user1";
$BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);
ob_end_flush();
?>
