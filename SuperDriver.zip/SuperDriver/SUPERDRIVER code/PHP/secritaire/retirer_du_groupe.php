<?php

use LDAP\Result;

ob_start();
    session_start();
    if(!isset($_SESSION['nom'])){
        header("location:../../connexion.php",true);
    }
    else{
        $username="user1";
        $passeword="user1";
        $BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);
        if(isset($_GET["retirer"]) && isset($_GET["groupe"])){
      
            $_SESSION['groupe']=$_GET["groupe"];
            $eleve=$BDD->prepare("UPDATE eleves set groupe=NULL where id_eleve=:id");
            $eleve->bindParam("id",$_GET["retirer"]);
            $eleve->execute();
            header("location: eleve_par_groupe.php",true);
        }
    }