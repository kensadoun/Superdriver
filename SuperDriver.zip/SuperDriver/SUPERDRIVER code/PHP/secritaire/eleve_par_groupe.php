<?php
ob_start();
session_start();
if(!isset($_SESSION['nom'])){
    header("location:../../connexion.php",true);
}
else{
    if(isset($_SESSION['groupe']) && !isset($_GET['groupe'])){
        $id=$_SESSION['groupe'];
    }
    else{
        $id=$_GET['groupe'];
    }

    require_once "../connexionBDD.php";
    /*$username="user1";
    $passeword="user1";
    $BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);*/
    echo '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <title>Page Title</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

            <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
            <link rel="stylesheet" type="text/css" media="screen" href="../../css/admin2.css">
            <script src="main.js"></script>
        </head>
        <body>
            <div class="posP">
                <div class="posF nav-item dropdown">
                    <a href="#" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action">
                        <img src="../image/person.svg" class="person">
                       <b> Secrétaire</b>
                    </a>
                    <div class="dropdown-menu">
                        <a href="#" class="dropdown-item"> <img src="../image/person-gear.svg" /> <i class="fa fa-user-o"></i> Profile</a>
                        <div class="divider dropdown-divider"></div>
                        <a href="../deconnexion.php" class="dropdown-item"><i class="material-icons"><img src="../image/box-arrow-right.svg" /></i> Déconnexion</a>
                    </div>
                </div>
            </div>
        <div class="container1">
            <p class="titre">Liste des Eléves </p>
            
        </div>

        <div class="container">
            <div class="search-container">
                <form method="POST" id="rechercher" >
                    <input type="text" placeholder="Recherche..." name="search">
                    <form method="POST"><button type="submit" name="recherche"  >Rechercher</button></form>
                </form>
            </div>
                        <table class="table " id="masque">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nom</th>
                                    <th scope="col">Prenom</th>
                                    <th scope="col">Catégorie</th>
                                    <th scope="col">Date de naissance</th>
                                    <th scope="col">Nationalité</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>';

                            if(isset($_POST["recherche"])){
            
                                if(!empty($_POST["search"])){
                                    ini_set('display_errors',1);
                                    error_reporting(E_ALL);
                                    $e=$_POST["search"];
                                    $p=strpos($e," ");
                                    if($p===FALSE){
                                        $eleves=$BDD->prepare("SELECT * from eleves where existe=1 and groupe=:id and nom LIKE '%$e%' or prenom LIKE '%$e%' ORDER BY date DESC  ");
                                    
                                        $eleves->bindParam("id",$id);
                                        $eleves->execute();
                                    }
                                    else{
                                        $m=explode(" ",$e);
                                        $eleves=$BDD->prepare("SELECT * from eleves where existe=1 and groupe=:id and (nom LIKE '%$m[0]%' and prenom  LIKE '%$m[1]%') or (nom LIKE '%$m[1]%' and prenom LIKE '%$m[0]%') ");
                                        $eleves->bindParam("id",$id);
                                        $eleves->execute();
                                    }
                                }
                            }

                            else{
                                ini_set('display_errors',1);
                                error_reporting(E_ALL);
                                $eleves=$BDD->prepare("SELECT * from eleves where existe=1 and groupe=:id ");
                                $eleves->bindParam("id",$id);
                                $eleves->execute();
                            }

                            
                            foreach($eleves AS $result){
                                $id_eleve=$result["id_eleve"];
                                $nom=$result["nom"];
                                $prenom=$result["prenom"];
                                $groupe=$result["groupe"];
                                $telephone=$result["telephone"];
                                $date_naissance=$result["date_naissance"];
                                $nationalite=$result["nationalite"];
                                $adresse=$result["adresse"];
                                $catégorie_permis_demandee=$result["catégorie_permis_demandee"];

                                echo '          
                                <tr>
                                <th class="th1" scope="row">'.$id_eleve.'</th>
                                    <td class="td1">'.$nom.'</td>
                                    <td>'.$prenom.'</td>
                                    <td>'.$catégorie_permis_demandee.'</td>
                                    <td>'.$date_naissance.'</td>
                                    <td>'.$nationalite.'</td>
                                    <td><button class="btn btn-danger"><a class="text-light" href="retirer_du_groupe.php? retirer='.$id_eleve.'&groupe='.$id.'" >Retirer</a></button></td>

                                    ';
                                    
                                echo'
                                </th>
                                </tr>
                                </tbody>'; 
                            }

                            echo'
                            </table>
                            </div>
                            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
                                           <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
                                           <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
                                           <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
                                           <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script> 
                                           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
                               <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
                               <script src="../../javascript/planning.js"></script>';
                            
                            
                
}