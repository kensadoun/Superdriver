<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='../../css/admin.css'>
    <script src='main.js'></script>
</head>
<body>
    <div class="side-menu">
        <div class="brand-name">
             <h1>Brand</h1>
        </div>
        <ul>
            <a href="compte.php"><img src="../image/school.png">&nbsp;Compte</a>
            <a href="index.php"><img src="../image/reading-book (1).png">&nbsp;Eleve</a>
            <a href="moniteur.php"><img src="../image/teacher2.png">&nbsp;Moniteur</a>
            <a href="vehicule.php"><img src="../image/car2.png  ">&nbsp;Vehicules</a>
            <div id="planning">
                <a href="#"><img src="../image/school.png">&nbsp;Planning</a>
                <a class="seance" href="code.php"><img src="../image/school.png">&nbsp;Planning cours de code</a>
                <a class="seance" href="#"><img src="../image/school.png">&nbsp;Planning lecons de conduite</a>
            </div>
            <a href="examen.php"><img src="../image/school.png">&nbsp;Examens</a>
            <a href="payement.php"><img src="../image/payment.png">&nbsp;Paiment</a>
            <a href="attestation.php"><img src="../image/school.png">&nbsp;Attestation Provisoire</a>
            <a href="recipice.php"><img src="../image/school.png">&nbsp;Recipise de paiment</a>
        </ul>
    </div>

    <script src="../javascript/admin.js"></script>
</body>
</html>