<?php
ob_start();
    session_start();
    if(!isset($_SESSION['nom'])){
        header("location:../../connexion.php",true);
    }
    else{
        require_once "../connexionBDD.php";
        /*$username="user1";
        $passeword="user1";
        $BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);*/
        echo'
            <!DOCTYPE html>
            <html>
                <head>
                <!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"> -->
                <link rel="stylesheet" href="../../css/bootstrap.min.css" />
                <link rel="stylesheet" href="../../css/admin2.css">
                </head>

                <body>
                    <div class="posP">
                        <div class="posF nav-item dropdown">
                            <a href="#" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action">
                                <img src="../image/person.svg" class="person">
                                <b> Secrétaire</b>
                            </a>
                            <div class="dropdown-menu">
                                <a href="../profile.php" class="dropdown-item"> <img src="../image/person-gear.svg" /> <i class="fa fa-user-o"></i> Profile</a>
                                <div class="divider dropdown-divider"></div>
                                <a href="../deconnexion.php" class="dropdown-item"><i class="material-icons"><img src="../image/box-arrow-right.svg" /></i> Déconnexion</a>
                            </div>
                        </div>
                    </div>
                    <span id="toggler"  ><img onclick="toggleModal2()" src="../image/hamburger_menu_navbar_options_icon_196495.svg"></span>

                    <div class="side-menu fermer">
                        <div class="brand-name">
                            <h1>Brand</h1>
                        </div>
                        <ul>
                            <a href="compte.php"><img src="../image/school.png">&nbsp;Compte</a>
                            <a href="groupe.php"><img src="../image/reading-book (1).png">&nbsp;Groupes</a>

                            <a href="index.php"><img src="../image/reading-book (1).png">&nbsp;Eleve</a>
                            <a href="moniteur.php"><img src="../image/teacher2.png">&nbsp;Moniteur</a>
                            <a href="vehicule.php"><img src="../image/car2.png  ">&nbsp;Vehicules</a>
                            <div id="planning">
                                <a href="#"><img src="../image/school.png">&nbsp;Planning</a>
                                <a class="seance" href="code.php"><img src="../image/school.png">&nbsp;Planning cours de code</a>
                                <a class="seance" href="conduite.php"><img src="../image/school.png">&nbsp;Planning lecons de conduite</a>
                            </div>
                            <a href="examen.php"><img src="../image/school.png">&nbsp;Examens</a>
                            <div id="paiement">
                                <a href="#"><img src="../image/payment.png">&nbsp;Paiment</a>
                                <a class="gestion_paiement" href="paiement_forfaitaire.php">&nbsp;Paiement Forfaitaire</a>
                                <a class="gestion_paiement" href="payement.php">&nbsp;Paiement Échelonné</a>
                            </div>
                            <a href="attestation.php"><img src="../image/school.png">&nbsp;Nouveaux conducteurs</a>
                            <a href="recipice.php"><img src="../image/school.png">&nbsp;Recipise de paiment</a>
                        </ul>
                    </div>
                    <div class="container1">
                    <p class="titre">Gestion des véhicules</p>
                   
                    <button onclick="toggleModal()" class="ajouter bt" name="ajouter">Ajouter</button>
                    
                      
                    <div class="modal1" id="user-modal">
                        <div class="modal1-header">
                            <h2>Ajouter un vehicule</h2>   
                        </div>

                        <form method="POST" id="user-form-1"  >
                            <label for="nom">Matricule :</label>
                            <input type="text" id="matricule_aj" name="matricule" required>
      
                            <label for="prenom">Marque:</label>
                            <input type="text" id="marque_aj" name="marque" required>
      
                            <label for="categorie"  >Catégorie  :</label>
                            <select id="categorie_aj" name="categorie"  >
                                <option hidden disable>Sélectionnez une catégorie</option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="E">E</option>
                            </select>

                            <label for="Adresse">Nombre de place :</label>
                            <input type="number" id="place_aj" name="place" required>

                            <label for="poids">Poids Total :</label>
                            <input type="number" id="poids_aj" name="poids" step="any" required>

                            <div >
                                <button class="modal1-close" onclick="toggleModal()">Fermer</button>
                                <input type="submit"  value="Ajouter" name="ajouter2" /> 
                            </div>
                
                        </form>

                        
                    </div>
                </div>

                <div class="container">
                    <div class="search-container">
                        <form method="POST" id="rechercher" >
                            <input type="text" placeholder="Recherche..." name="search">
                            <form method="POST"><button type="submit" name="recherche"  >Rechercher</button></form>
                        </form>
                    </div>
                    <table class="table " id="masque">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Marque</th>
                                <th scope="col">Catégorie</th>
                                <th scope="col">Nombre de place </th>
                                <th scope="col">Poids total</th>
                                <th scope="col" style="text-align:center">action</th>
                            </tr>
                        </thead>';

                        if(isset($_POST["recherche"])){
                            if(!empty($_POST["search"])){
                                ini_set('display_errors',1);
                                error_reporting(E_ALL);
                                $e=$_POST["search"];
                                $p=strpos($e," ");
                                if($p===FALSE){
                                    $vehicules=$BDD->prepare("SELECT * from vehicule where en_fonction=1 and matricule LIKE '%$e%' or marque LIKE '%$e%' or categorie LIKE '%$e%'  order by matricule");
                                    $vehicules->execute();
                                }
                                else{
                                    $m=explode(" ",$e);
                                    $vehicules=$BDD->prepare("SELECT * from moniteur where en_fonction=1 and (matricule LIKE '%$m[0]%' and marque  LIKE '%$m[1]%') or (matricule LIKE '%$m[1]%' and marque LIKE '%$m[0]%') order by matricule ");
                                    $vehicules->execute();
                                }
                            }     
                        }
                        else{
                            $vehicules=$BDD->prepare("SELECT * FROM vehicule where en_fonction=1  ORDER BY matricule DESC ");
                            $vehicules->execute();
                        }
                        foreach($vehicules AS $result){
                            $matricule=$result["matricule"];
                            $marque=$result["marque"];
                            $categorie=$result["categorie"];
                            $nombre_de_places=$result["nombre_de_places"];
                            $poids_total=$result["poids_total"];
                            $t="vehicule";
                            echo ' <tr>
                                        <th class="th1" scope="row">'.$matricule.'</th>
                                            <td ">'.$marque.'</td>
                                            <td>'.$categorie.'</td> 
                                            <td >'.$nombre_de_places.'</td>
                                            <td>'.$poids_total.'</td> 
                                                <td><button class="btn btn-danger"><a class="text-light" href="../supprimer.php? supp='.$matricule.'&type='.$t.'" >supprimer</a></button></td>
                                                <td>
                                                <div class="container ">
                                                    <button  class="btn btn-primary btn1" data-bs-toggle="modal" data-bs-target="#myModal" name="modifier">modifier</button>
                                                    <form method="POST">
                    
                                                        <input type="hidden"  name="idA" class="form-control ina1" value="'.$matricule.'" >
                                                        <input type="hidden"  name="nomA" class="form-control ina2" value="'.$marque.'" >
                                                        <input type="hidden"  name="prenomA" class="form-control ina3" value="'.$categorie.'" >
                                                        <input type="hidden"  name="prenomA" class="form-control ina4" value="'.$nombre_de_places.'" >
                                                        <input type="hidden"  name="prenomA" class="form-control ina5" value="'.$poids_total.'" >
                                                        <div class="modal" id="myModal">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title">Modifier les informations du véhicule</h5>
                                                                        <button type="button" class="btn-close bt1" data-bs-dismiss="modal">x</button>
                                                                    </div>
                                                                    <div class="modal-body">
                        
                                                                        <div class="mb-3">
                                                                            <input type="hidden" id="i1" name="matricule" class="form-control in" required   >
                                                                        </div>

                                                                        <div class="mb-3">
                                                                            <label class="form-label required">Marque</label>
                                                                            <input type="text" name="marque" class="form-control in" required  >
                                                                        </div>

                                                                        <div class="mb-3">
                                                                            <label class="form-label required ">Catégorie </label>
                                                                            <select class="in" name="categorie">
                                                                            </select>
                                                                        </div>
                                                                        
                                                                        <div class="mb-3">
                                                                            <label class="form-label required ">Nombre de places</label>
                                                                            <input type="text" name="nombre_place"  class="form-control in" required "></input>
                                                                        </div>

                                                                        <div class="mb-3">
                                                                            <label class="form-label required ">Poids total</label>
                                                                            <input type="number" name="poids" class="form-control in " step="any" required >
                                                                        </div>


                                                                    </div>

                                                                    <div class="modal-footer">
                                                                        <button type="submit" class="btn btn-primary btn2" name="confirmer">confirmer</button>
                                                                        <button type="submit" class="btn btn-danger">Cancel</button>
                                                                    </div>
                                                                </div>
                                                              
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                                
                                                
                                                
                                                </td>
                                            
                                        </th>
                                    </tr>
                                </tbody>';
                        }
                                
                    echo "
                    </table>
                    <script src='../../javascript/slim.min.js' ></script>
                    <script src='../../javascript/popper.min.js'' ></script>
                    <script src='../../javascript/bootstrap.min.js'' ></script>
                    <script src='../../javascript/bootstrap.bundle.min.js'' ></script>
                    <script src='../../javascript/vehicule.js'></script>
                    <!--<script src='https://code.jquery.com/jquery-3.3.1.slim.min.js' integrity='sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo' crossorigin='anonymous'></script>-->
                    <!-- <script src='https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js' integrity='sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49' crossorigin='anonymous'></script> -->
                    <!--<script src='https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js' integrity='sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy' crossorigin='anonymous'></script> -->
                    <!-- <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js' integrity='sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW' crossorigin='anonymous'></script> -->
                    
                </body>
            </html>";

            if(isset($_POST["confirmer"])){
                ini_set('display_errors',1);
                error_reporting(E_ALL);
                $vehicule=$BDD->prepare("UPDATE vehicule set marque=:marque,categorie=:categorie ,nombre_de_places=:nombre_place,poids_total=:poids_total where matricule=:matricule");
                $vehicule->bindParam("marque",$_POST["marque"]);
                $vehicule->bindParam("categorie",$_POST["categorie"]);
                $vehicule->bindParam("nombre_place",$_POST["nombre_place"]);
                $vehicule->bindParam("poids_total",$_POST["poids"]);
                $vehicule->bindParam("matricule",$_POST["matricule"]);
                $vehicule->execute();
                header("location: vehicule.php",true);
            }

            if(isset($_POST["ajouter2"])){
                if(isset($_POST["matricule"]) && isset($_POST["marque"]) && isset($_POST["categorie"]) && isset($_POST["place"])  && isset($_POST["poids"])){
                    ini_set('display_errors',1);
                    error_reporting(E_ALL);
                    $vehicule=$BDD->prepare("INSERT INTO vehicule VALUES(:matricule,:marque,:categorie,:nombre_de_places,:poids_total,1)");
                    $vehicule->bindParam("matricule",$_POST["matricule"]);
                    $vehicule->bindParam("marque",$_POST["marque"]);
                    $vehicule->bindParam("categorie",$_POST["categorie"]);
                    $vehicule->bindParam("nombre_de_places",$_POST["place"]);
                    $vehicule->bindParam("poids_total",$_POST["poids"]);
                    $vehicule->execute();
                    header("location: vehicule.php",true);

                }
            }
    }
?>