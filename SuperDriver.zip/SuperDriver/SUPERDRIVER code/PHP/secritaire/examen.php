<?php
ob_start();
session_start();
if(!isset($_SESSION['nom'])){
    header("location:../../connexion.php",true);
}
else{
    require_once "../connexionBDD.php";
    /*$username="user1";
    $passeword="user1";
    $BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);*/
    if(isset($_POST["type"]) && isset($_POST["cat"])){

        ini_set('display_errors',1);
        error_reporting(E_ALL);
        $type=$_POST["type"];
        $categorie=$_POST["cat"];
        if($type =="circulation"){
            $eleves=$BDD->prepare("SELECT e.nom as ne,e.prenom as pe FROM eleves e where e.catégorie_permis_demandee =:categorie and  e.id_eleve   IN(SELECT p.id_eleve FROM passer p where p.etat=1 and p.id_examen IN(SELECT exam.id_examen from examen exam where exam.type='créneau')) and e.id_eleve NOT IN(SELECT p.id_eleve FROM passer p where p.etat=1 and p.id_examen IN(SELECT ex.id_examen from examen ex where ex.type=:type))");
            $eleves->bindParam("categorie",$categorie);
            $eleves->bindParam("type",$type);
            $eleves->execute(); 
            foreach($eleves as $result){
               echo '<option>'.$result['ne'].' '.$result['pe'].'</option>'; 
            }
        }
        elseif($type=="code"){
            $eleves=$BDD->prepare("SELECT e.nom as ne,e.prenom as pe FROM eleves e where e.catégorie_permis_demandee =:categorie and  e.id_eleve  NOT IN(SELECT p.id_eleve FROM passer p where p.etat=1 or p.etat is NULL)");
            $eleves->bindParam("categorie",$categorie);
            $eleves->execute();
            foreach($eleves as $result){
               echo '<option>'.$result['ne'].' '.$result['pe'].'</option>'; 
            }      
        }
        elseif($type=="créneau"){
            $eleves=$BDD->prepare("SELECT e.nom as ne,e.prenom as pe FROM eleves e where e.catégorie_permis_demandee =:categorie  and  e.id_eleve NOT IN(SELECT p.id_eleve FROM passer p where p.etat=1 and p.id_examen IN(SELECT ex.id_examen from examen ex where ex.type=:type)) and  e.id_eleve   IN(SELECT p.id_eleve FROM passer p where p.etat=1 or p.etat is not null)");
            $eleves->bindParam("categorie",$categorie);
            $eleves->bindParam("type",$type);
            $eleves->execute();
            foreach($eleves as $result){
                echo '<option>'.$result['ne'].' '.$result['pe'].'</option>'; 
            }  
        }
        exit;
    }
    echo '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <title>Page Title</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="../../css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
            <link href="../../css/select2.min.css" rel="stylesheet" />
            <link rel="stylesheet" type="text/css" media="screen" href="../../css/admin2.css">
            <script src="main.js"></script> 
        </head>
        <body>
            <div class="posP">
                <div class="posF nav-item dropdown">
                    <a href="#" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action">
                        <img src="../image/person.svg" class="person">
                        <b> Secrétaire</b>
                    </a>
                    <div class="dropdown-menu">
                        <a href="../profile.php" class="dropdown-item"> <img src="../image/person-gear.svg" /> <i class="fa fa-user-o"></i> Profile</a>
                        <div class="divider dropdown-divider"></div>
                        <a href="../deconnexion.php" class="dropdown-item"><i class="material-icons"><img src="../image/box-arrow-right.svg" /></i> Déconnexion</a>
                    </div>
                </div>
            </div>
            <span id="toggler"  ><img onclick="toggleModal2()" src="../image/hamburger_menu_navbar_options_icon_196495.svg"></span>

            <div class="side-menu fermer">
                <div class="brand-name">
                    <h1>Brand</h1>
                </div>
                <ul>
                    <a href="compte.php"><img src="../image/school.png">&nbsp;Compte</a>
                    <a href="groupe.php"><img src="../image/reading-book (1).png">&nbsp;Groupes</a>
                    <a href="index.php"><img src="../image/reading-book (1).png">&nbsp;Eleve</a>
                    <a href="moniteur.php"><img src="../image/teacher2.png">&nbsp;Moniteur</a>
                    <a href="vehicule.php"><img src="../image/car2.png  ">&nbsp;Vehicules</a>
                    <div id="planning">
                        <a href="#"><img src="../image/school.png">&nbsp;Planning</a>
                        <a class="seance" href="code.php"><img src="../image/school.png">&nbsp;Planning cours de code</a>
                        <a class="seance" href="conduite.php"><img src="../image/school.png">&nbsp;Planning lecons de conduite</a>
                    </div>
                    <a href="examen.php"><img src="../image/school.png">&nbsp;Examens</a>
                    <div id="paiement">
                        <a href="#"><img src="../image/payment.png">&nbsp;Paiment</a>
                        <a class="gestion_paiement" href="paiement_forfaitaire.php">&nbsp;Paiement Forfaitaire</a>
                        <a class="gestion_paiement" href="payement.php">&nbsp;Paiement Échelonné</a>
                    </div>
                    <a href="attestation.php"><img src="../image/school.png">&nbsp;Nouveaux conducteurs</a>
                    <a href="recipice.php"><img src="../image/school.png">&nbsp;Recipise de paiment</a>
                </ul>
            </div>
            <div class="container1">
                    <p class="titre">Gestion des Examens</p>
                    <button onclick="toggleModal()" class="ajouter bt" name="ajouter">Ajouter</button>
                    <div class="modal1" id="user-modal">
                        <div class="modal1-header">
                            <h2>Ajouter un Eleve</h2>   
                        </div> 
                        <form  method="GET"  >
                            <label for="categoriePermis">Catégorie  :</label>
                            <select name="categorie" id="categorie" class="form-control multiple-select"  required>
                                <option value=""></option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="E">E</option>
                            </select>

                            <label for="date">Date :</label>
                            <input type="date" id="date" name="date" required>
      
                            <label for="Type">Type :</label>
                            <select name="type" id="type" class=" multiple-select" required >
                                <option value=""></option>
                                <option value="code">code</option>
                                <option value="créneau">créneau</option>
                                <option value="circulation">circulation</option>
                            </select>
                                  
                            <label for="eleves">Eleves :</label>
                            <select name="eleve[]" id="eleves" class="multiple-select " multiple required>
                            </select>  
                            <div>
                                <input type="submit"  value="Ajouter" name="ajouter2" /> 
                                <button class="modal1-close" onclick="toggleModal()">Fermer</button> 
                           </div>
                        </form>
                    </div>
            </div>
            <div class="container">
                        <div class="search-container">
                            <form method="POST" id="rechercher" >
                                <input type="text" placeholder="Recherche..." name="search">
                                <form method="POST"><button type="submit" name="recherche"  >Rechercher</button></form>
                            </form>
                        </div>
                        <table class="table " id="masque">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Catégorie</th>
                                    <th scope="col">Type</th>
                                    <th scope="col">Eleves</th>
                                </tr>
                            </thead>
                            <tbody>';
                            if(isset($_POST["recherche"])){
                                if(!empty($_POST["search"])){
                                    ini_set('display_errors',1);
                                    error_reporting(E_ALL);
                                    $e=$_POST["search"];
                                    $p=strpos($e," ");
                                    if($p===FALSE){
                                        $examen=$BDD->prepare("SELECT * from examen  where id_examen LIKE '%$e%' or date LIKE '%$e%' or categorie LIKE '%$e%' or type LIKE '%$e%'  ORDER BY date DESC  ");
                                        $examen->execute();
                                    }
                                    else{
                                        $m=explode(" ",$e);
                                        $examen=$BDD->prepare("SELECT * from examen  where (date LIKE '%$m[0]%' and categorie  LIKE '%$m[1]%') or (date LIKE '%$m[1]%' and categorie LIKE '%$m[0]%') or (date LIKE '%$m[1]%' and type LIKE '%$m[0]%') or (date LIKE '%$m[0]%' and type LIKE '%$m[1]%') or (categorie LIKE '%$m[1]%' and type LIKE '%$m[0]%') or (categorie LIKE '%$m[0]%' and type LIKE '%$m[1]%') ORDER BY date DESC  ");
                                        $examen->execute();
                                    }
                                }
                            }
                            else{
                                $examen=$BDD->prepare("SELECT * from examen    ORDER BY date DESC ");
                                $examen->execute();
                            }
                            foreach($examen AS $result){
                                $id=$result["id_examen"];
                                $date=$result["date"];
                                $categorie=$result["categorie"];
                                $type=$result["type"];
                                $c="examen";
                                echo '          
                                <tr>
                                <th class="th1" scope="row">'.$id.'</th>
                                    <td class="td1">'.$date.'</td>
                                    <td>'.$categorie.'</td>
                                    <td>'.$type.'</td>
                                    <td><button class="btn btn-danger"><a class="text-light" href="eleve_examen.php? examen='.$id. '" >Voir la liste</a></button></td>
                                </th>
                                </tr>
                                </tbody>'; 
                            }
        echo'
        </table>
        </div>
        <script src="../../javascript/planning.js"></script>
        <script src="../../javascript/jquery.min.js"></script>
        <script src="../../javascript/popper.min.js"></script>
        <script src="../../javascript/bootstrap.min.js"></script>
        <script src="../../javascript/bootstrap.bundle.min.js"></script>
        <script src="../../javascript/select2.min.js"></script>
        <script>
                $(".multiple-select").select2({
                    placeholder: "eleves",
                    allowClear: true,
                });

                $("#categorie").select2({
                    minimumResultsForSearch: -1,
                    placeholder: {
                        id:"",
                        text:"categorie"},
                    allowClear: true
                });

                $("#eleves").select2({
                    placeholder:"selectionner les eleves",
                    allowClear: true,
                    multiple: true
                });
                $("#type").select2({
                    placeholder: "Type",
                    allowClear: true,
                    minimumResultsForSearch: -1,
                })
                $(document).ready(function(){
                    $("#categorie").change(function(){
                        var typeSel=$("#type").val();
                        var catSel=$("#categorie").val();
                            $.ajax({
                                type: "post",
                                data: {type: typeSel,cat: catSel},
                                success: function(response1){
                                    $("#eleves").select2().val( null ).trigger ( "change" )
                                    $("#eleves").select2({

                                        placeholder:"Selectionner les eleves",
                                        allowClear:true,
                                        multiple:true,
                                    });
                                    $("#eleves").html(response1);                                    
                                }   
                            });
                    });
                    $("#type").change(function(){
                        var typeSel=$("#type").val();
                        var catSel=$("#categorie").val();
                            $.ajax({
                                type: "post",
                                data: {type: typeSel,cat: catSel},
                                success: function(response1){
                                    $("#eleves").select2().val( null).trigger ( "change" )
                                    $("#eleves").html(response1);
                                }   
                            });
                    });
                });
;           
            </script>
</body>
</html>';
            if(isset($_GET["ajouter2"])){
                if(isset($_GET["categorie"]) && isset($_GET["date"]) && isset($_GET["type"]) && isset($_GET["eleve"])){
                    ini_set('display_errors',1);
                    error_reporting(E_ALL);
                    $eleves=array("nom"=>"","prenom"=>"");
                    $id_examen=0;
                    $nbr=$BDD->prepare("SELECT count(id_examen) as nbr from examen");
                    $nbr->execute();
                    $nbrR=$nbr->fetchObject();
                    if($nbrR->nbr==0){
                        $id_examen=1;
                    }
                    else{
                        $nbr=$BDD->prepare("SELECT max(id_examen) as max from examen");
                        $nbr->execute();
                        $nbrR=$nbr->fetchObject();
                        $id_examen=$nbrR->max+1;
                    }
                    $examen=$BDD->prepare("INSERT INTO examen values(:id,:date,:categorie,:type)");
                    $examen->bindParam("id",$id_examen);
                    $examen->bindParam("date",$_GET["date"]);
                    $examen->bindParam("categorie",$_GET["categorie"]);
                    $examen->bindParam("type",$_GET["type"]);
                    $examen->execute();
                    foreach($_GET["eleve"] as $res){
                        $r=explode(" ",$res);
                        $eleves["nom"]=$r[0];
                        $eleves["prenom"]=$r[1];
                        $id=$BDD->prepare("SELECT id_eleve from eleves where nom=:nom and prenom=:prenom");
                        $id->bindParam("nom",$eleves["nom"]);
                        $id->bindParam("prenom",$eleves["prenom"]);
                        $id->execute();
                        $id_eleve=$id->fetchObject();
                        $passer=$BDD->prepare("INSERT INTO passer VALUES(:id_eleve,:id_examen,NULL)");
                        $passer->bindParam("id_eleve",$id_eleve->id_eleve);
                        $passer->bindParam("id_examen",$id_examen);
                        $passer->execute();
                    }
                    header("location: examen.php",true);
                }
            }
ob_end_flush();
}
?>