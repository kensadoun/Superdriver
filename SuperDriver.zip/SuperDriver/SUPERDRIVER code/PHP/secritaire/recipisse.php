<?php
USE Dompdf\Dompdf;
//require_once  '../vendor/autoload.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
if(!isset($_SESSION['nom'])){
  header("location:../../connexion.php",true);
}

else{
    ob_start();
    if(isset($_SESSION["type"]) && isset($_SESSION["somme"]) && isset($_SESSION["categorie"]) && isset($_SESSION["type"]) && isset($_SESSION["date_paiement"]) && isset($_SESSION["nom_etud"]) && isset($_SESSION["prenom_etud"]) && $_SESSION["type"]=="Forfaitaire"){
        echo'<div style="width:90%; height:50px;position:relative;left:5%">
                    <h1 style="text-align:center;height:50px;border:double">RÉCÉPISSÉ DE PAIEMENT</h1>
                </div>
                <div style="width:90%;position:relative;left:5%;border:solid;height:300px;">
                    <p>Nom:                '.$_SESSION["nom_etud"].'</p>
                    <p>Prénom:             '.$_SESSION["prenom_etud"].'</p>
                    <p>Somme:              '.$_SESSION["somme"].'DA</p>
                    <p>Type de paiement:   :Forfaitaire</p>
                    <p>Date de paiement:   '.$_SESSION["date_paiement"].'</p>
                    <p>Catégorie:          '.$_SESSION["categorie"].'</p>
                </div>';
    }
    elseif($_SESSION["type"]=="Échelonné"){
        if(isset($_SESSION["examen"]) && isset($_SESSION["eleve"]) && isset($_SESSION["type_examen"])  ){
            $eleve=$_SESSION["eleve"];
      
            echo'<div style="width:90%; height:50px;position:relative;left:5%">
                    <h1 style="text-align:center;height:50px;border:double">RÉCÉPISSÉ DE PAIEMENT</h1>
                </div>
                <div style="width:90%;position:relative;left:5%;border:solid;height:300px;">
                    <p>Nom:                '.$eleve[0].'</p>
                    <p>Prénom:             '.$eleve[1].'</p>
                    <p>Somme:              '.$_SESSION["somme"].'DA</p>
                    <p>Type de paiement:   :Échelonné</p>
                    <p>Date de paiement:   '.$_SESSION["date_paiement"].'</p>
                    <p>Date d examen:      '.$_SESSION["examen"].'</p>
                    <p>Catégorie:          '.$_SESSION["categorie"].'</p>
                    <p>Type d examen:      '.$_SESSION["type_examen"].'</p>
                </div>';
        }
    }
    error_reporting(E_ALL);
    ini_set('display_errors','On');
    $html=ob_get_contents();
    ob_end_clean();

    require_once 'dompdf2/dompdf/autoload.inc.php';
    $dompdf=new Dompdf();
    $dompdf->loadHTML($html);
    $dompdf->setPaper('A4','portrait');
    $dompdf->render();
    $titre="RÉCÉPISSÉ DE PAIEMENT";
    $dompdf->stream($titre,["Attachement"=>0]);
}


?>