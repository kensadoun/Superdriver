<?php
USE Dompdf\Dompdf;
//require_once  '../vendor/autoload.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
if(!isset($_SESSION['nom'])){
  header("location:../../connexion.php",true);
}
else{
    ob_start();
    if(isset($_GET["impr"])){
        //$username="user1";
        //$passeword="user1";
        //$BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);
        error_reporting(E_ALL);
        ini_set('display_errors','On');


        //$eleves=$BDD->prepare("SELECT  e.id_eleve ,e.nom as nom,e.prenom as prenom,e.telephone,e.date_naissance as date_naissance,e.nationalite,e.adresse as  adresse,e.catégorie_permis_demandee as categorie,ex.date as  date FROM eleves e,passer p,examen ex where e.id_eleve=p.id_eleve and ex.id_examen=p.id_examen and p.etat=1 and e.id_eleve=:id ORDER BY e.id_eleve DESC");
        //$eleves->bindParam("id",$_GET["impr"]);
        ///$eleves->execute();
        //$result=$eleves->fetchObject();
        //foreach($eleves AS $result){
            echo'<div style="width:90%; height:50px;position:relative;left:5%">
                    <h1 style="text-align:center;height:50px;border:double">RÉCÉPISSÉ DU PERMIS DE CONDUIRE</h1>
                </div>
                <div style="width:90%;position:relative;left:5%;border:solid;height:250px;">
                    <p><label style="text:solide">Nom</label>:'.$_GET["nom"].'</p>
                    <p>Prénom:'.$_GET["prenom"].'</p>
                    <p>Date de naissance:'.$_GET["date_naissance"].'</p>
                    <p>Adresse:'.$_GET["adresse"].'</p>
                    <p>Catégorie:'.$_GET["categorie"].'</p>
                    <p>Date de réussite:'.$_GET["examen"].'</p>
                    <p>Centre d examen:'.$_GET["centre"].'</p>
                </div>';
        //}
    }
$html=ob_get_contents();
ob_end_clean();

require_once 'dompdf2/dompdf/autoload.inc.php';
$dompdf=new Dompdf();
$dompdf->loadHTML($html);
$dompdf->setPaper('A4','portrait');
$dompdf->render();
$titre="RÉCÉPISSÉ DU PERMIS DE CONDUIRE";
$dompdf->stream($titre);
}

?>