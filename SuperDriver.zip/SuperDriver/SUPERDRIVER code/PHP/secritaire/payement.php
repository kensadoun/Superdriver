<?php
ob_start();
session_start();
if(!isset($_SESSION["nom"])){
    header("location:../../connexion.php",true);
}

else{
    require_once "../connexionBDD.php";
    /*$username="user1";
    $passeword="user1";
    $BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);*/
   if(isset($_POST["date"]) && isset($_POST["type"]) && isset($_POST["categorie"])){
        $date=$_POST["date"];
        $type=$_POST["type"];
        $categorie=$_POST["categorie"];
        $eleve=$BDD->prepare("SELECT e.nom as nom,e.prenom as prenom from eleves e ,passer p,examen exam where p.id_eleve=e.id_eleve and p.id_examen=exam.id_examen and e.catégorie_permis_demandee=:categorie and exam.id_examen IN(select exm.id_examen from examen exm where exm.date=:date and exm.type=:type) and e.id_eleve NOT IN(SELECT pai.eleve from paiement_echelonne pai where examen IN(select exmn.id_examen from examen exmn where exmn.date=:date )) and e.id_eleve NOT IN(SELECT pf.id_eleve from paiement_forfaitaire  pf) ");
        $eleve->bindParam("date",$date);
        $eleve->bindParam("type",$type);
        $eleve->bindParam("categorie",$categorie);
        $eleve->execute();
        echo '<option disable></option>';
        foreach($eleve as  $result){
            echo '<option>'.$result['nom'].' '.$result['prenom'].'</option>';
        }
        exit;
    }
    echo'
            <!DOCTYPE html>
            <html>
                <head>
                    <meta charset="utf-8">
                    <meta http-equiv="X-UA-Compatible" content="IE=edge">
                    <title>Page Title</title>
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
                    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
                    <link rel="stylesheet" type="text/css" media="screen" href="../../css/admin2.css">
                    <script src="main.js"></script>
                </head>
                <body>
                    <div class="posP">
                        <div class="posF nav-item dropdown">
                            <a href="payement.php" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action">
                                <img src="../image/person.svg" class="person">
                                <b> Secrétaire</b>
                            </a>
                            <div class="dropdown-menu">
                                <a href="../profile.php" class="dropdown-item"> <img src="../image/person-gear.svg" /> <i class="fa fa-user-o"></i> Profile</a>
                                <div class="divider dropdown-divider"></div>
                                <a href="../deconnexion.php" class="dropdown-item"><i class="material-icons"><img src="../image/box-arrow-right.svg" /></i> Déconnexion</a>
                            </div>
                        </div>
                    </div>
                    <span id="toggler"  ><img onclick="toggleModal2()" src="../image/hamburger_menu_navbar_options_icon_196495.svg"></span>

                    <div class="side-menu fermer">
                        <div class="brand-name">
                            <h1>Brand</h1>
                        </div>
                        <ul>
                            <a href="compte.php"><img src="../image/school.png">&nbsp;Compte</a>
                            <a href="groupe.php"><img src="../image/reading-book (1).png">&nbsp;Groupes</a>
                            <a href="index.php"><img src="../image/reading-book (1).png">&nbsp;Eleve</a>
                            <a href="moniteur.php"><img src="../image/teacher2.png">&nbsp;Moniteur</a>
                            <a href="vehicule.php"><img src="../image/car2.png  ">&nbsp;Vehicules</a>
                            <div id="planning">
                                <a href="#"><img src="../image/school.png">&nbsp;Planning</a>
                                <a class="seance" href="code.php"><img src="../image/school.png">&nbsp;Planning cours de code</a>
                                <a class="seance" href="#"><img src="../image/school.png">&nbsp;Planning lecons de conduite</a>
                            </div>
                            <a href="examen.php"><img src="../image/school.png">&nbsp;Examens</a>
                            <div id="paiement">
                                <a href="#"><img src="../image/payment.png">&nbsp;Paiment</a>
                                <a class="gestion_paiement" href="paiement_forfaitaire.php">&nbsp;Paiement Forfaitaire</a>
                                <a class="gestion_paiement" href="payement.php">&nbsp;Paiement Échelonné</a>
                            </div>
                            <a href="attestation.php"><img src="../image/school.png">&nbsp;Nouveaux conducteurs</a>
                            <a href="recipice.php"><img src="../image/school.png">&nbsp;Recipise de paiment</a>

                        </ul>
                    </div>

                    <div class="container1">
                        <p class="titre">Gestion des paiements</p>
                       
                        <button onclick="toggleModal()" class="ajouter bt" name="ajouter">Ajouter</button>
                      
                        <div class="modal1" id="user-modal">
                            <div class="modal1-header">
                                <h2>Ajouter un paiement</h2>   
                            </div>

                            <form method="POST"  id="user-form-1"  >
                                <label for="Examen">Date d examen :</label>
                                <input type="date" id="date_aj" name="examen" required>

                                
                                <label for="paiement">Catégorie :</label>
                                <select id="categorie" name="categorie" class="multiple-select" required>
                                    <option value=""></option>
                                    <option value="A">A</option>
                                    <option value="B">B </option>
                                    <option value="C">C</option>
                                    <option value="D">D</option>
                                    <option value="E">E</option>

                                </select>

                                <label for="type_examen">Type d examen :</label>
                                <select name="type_examen" id="type_examen" class="form-control multiple-select" >
                                    <option selected hidden ></option>
                                    <option>code</option>
                                    <option>créneau</option>
                                    <option>circulation</option>
                                </select>

                                <label for="eleve">Eleve :</label>
                                <select name="eleve" id="eleve" class="form-control multiple-select" >

                                </select>


                                <label for="date_p">Date de paiement :</label>
                                <input type="date" id="date_p_aj" name="date_paiement" required>



                                <label for="somme">Somme :</label>
                                <input type="text" id="somme_aj" name="somme" required>

                                <input type="submit"  value="Ajouter" name="ajouter2" /> 
                                <button class="modal1-close" onclick="toggleModal()">Fermer</button>
                            </form>
                        </div>
                        
                    </div>

                    <div class="container">
                        <div class="search-container">
                            <form method="POST" id="rechercher" >
                                <input type="text" placeholder="Recherche..." name="search">
                                <form method="POST"><button type="submit" name="recherche"  >Rechercher</button></form>
                            </form>
                        </div>
                        <table class="table " id="masque">
                            <thead>
                                <tr>
                                    
                                    <th scope="col">#</th>
                                    <th scope="col">Eleve</th>
                                    <th scope="col">Somme</th>
                                    <th scope="col">Type de paiement </th>
                                    <th scope="col">Date de paiement </th>
                                    <th scope="col">Date d examen</th>
                                    <th scope="col">Catégorie</th>
                                    <th scope="col">Type d examen</th>
                                    <th scope="col">Action</th>
                                    
                                </tr>
                            </thead>
                            <tbody>';

                            if(isset($_POST["recherche"])){
            
                                if(!empty($_POST["search"])){
                                    ini_set('display_errors',1);
                                    error_reporting(E_ALL);
                                    $e=$_POST["search"];
                                    $p=strpos($e," ");
                                    if($p===FALSE){
                                        $paiement=$BDD->prepare("SELECT p.id_paiement as id ,p.somme as somme  ,exam.categorie as categorie ,exam.type as type, exam.date as date, e.nom as nom,e.prenom as prenom, p.date_paiement as date_paiement from eleves e,paiement_echelonne p,examen exam  where p.eleve=e.id_eleve and p.examen=exam.id_examen  and e.nom LIKE '%$e%' or e.prenom LIKE '%$e%'   ORDER BY p.date_paiement DESC  ");
                                        $paiement->execute();
                                    }
                                    else{
                                        $m=explode(" ",$e);
                                        $paiement=$BDD->prepare("SELECT p.id_paiement as id ,p.somme as somme  ,exam.categorie as categorie ,exam.type as type, exam.date as date, e.nom as nom,e.prenom as prenom, p.date_paiement as date_paiement from eleves e,paiement_echelonne p,examen exam  where p.eleve=e.id_eleve and p.examen=exam.id_examen  and (e.nom LIKE '%$m[0]%' and e.prenom  LIKE '%$m[1]%') or (e.nom LIKE '%$m[1]%' and e.prenom LIKE '%$m[0]%')  ORDER BY p.date_paiement DESC  ");
                                        $paiement->execute();
                                    }
                                }
                            }

                            else{

                                $paiement=$BDD->prepare("SELECT p.id_paiement as id ,p.somme as somme ,exam.categorie as categorie ,exam.type as type, exam.date as date, e.nom as nom,e.prenom as prenom, p.date_paiement as date_paiement from eleves e,paiement_echelonne p,examen exam  where p.eleve=e.id_eleve and p.examen=exam.id_examen     ORDER BY p.date_paiement DESC ");
                                $paiement->execute();
                            }
           

                            foreach($paiement AS $result){
                                $id=$result["id"];
                                $somme=$result["somme"];
                               
                                $categorie=$result["categorie"];
                                $date=$result["date"];
                                $nom=$result["nom"];
                                $prenom=$result["prenom"];
                                $type_exam=$result["type"];
                                $date_paiement=$result["date_paiement"];
                                $c="paiement";
                            echo'
                            <tr>
                                <th class="th1" scope="row">'.$id.'</th>
                                    <td class="td1">'.$nom.' '.$prenom.'</td>
                                    <td>'.$somme.'DA</td>
                                    <td>Échelonné</td>
                                    <td>'.$date_paiement.'</td>
                                    <td>'.$date.'</td>
                                    <td>'.$categorie.'</td>
                                    <td>'.$type_exam.'</td>
                                    <td><button class="btn btn-danger"><a class="text-light" href="../supprimer.php? supp='.$id.'&type='.$c.'" >Supprimer</a></button></td>

                                </th>
                                </tr>
                                </tbody>
                                ';
                            }
                            echo'
                        </table>
                    </div>
                    
                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
                    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
                    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
                    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script> 
                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
                    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
                    <script src="../../javascript/planning.js"></script>
                    <script>

                    $("#categorie").select2({
                        placeholder:"catégorie",
                        minimumResultsForSearch: -1
                           
                    });
                    $("#eleve").select2({
                        placeholder:"Eleve"
                           
                    });

                    $("#type_examen").select2({
                        placeholder:"Type d examen",
                        minimumResultsForSearch: -1

                           
                    });

                    $(document).ready(function(){
                        $("#date_aj").change(function(){
                            var dateSel=$("#date_aj").val();
                            var typeSel=$("#type_examen").val();
                            var categorieSel=$("#categorie").val();
                            $.ajax({
                                type: "post",
                                data: {date: dateSel,type: typeSel,categorie: categorieSel},
                                success: function(response1){
                                    $("#eleve").select2({  
                                        placeholder:"Eleve"     
                                    })
                                    $("#eleve").html(response1);
                                }   
                            });
                        });
                        
                        $("#categorie").change(function(){
                            var dateSel=$("#date_aj").val();
                            var typeSel=$("#type_examen").val();
                            var categorieSel=$("#categorie").val();
                            $.ajax({
                                type: "post",
                                data: {date: dateSel,type: typeSel,categorie: categorieSel},
                                success: function(response1){
                                    $("#eleve").select2({  
                                        placeholder:"Eleve"     
                                    })
                                    $("#eleve").html(response1);
                                }   
                            });
                        });

                        $("#type_examen").change(function(){
                            var dateSel=$("#date_aj").val();
                            var typeSel=$("#type_examen").val();
                            var categorieSel=$("#categorie").val();
                            //alert("dateSel="+dateSel);
                            //alert("typeSel="+typeSel);
                            //alert("categorieSel="+categorieSel);
                            $.ajax({
                                type: "post",
                                data: {date: dateSel,type: typeSel,categorie: categorieSel},
                                success: function(response1){
                                    $("#eleve").select2({  
                                        placeholder:"Eleve"     
                                    })
                                    $("#eleve").html(response1);
                                }   
                            });
                        });
                        });
                    </script>
                </body>
            </html>';

            if(isset($_POST["ajouter2"])){
                if(isset($_POST["examen"]) && isset($_POST["eleve"]) && isset($_POST["somme"]) && isset($_POST["date_paiement"]) && isset($_POST["type_examen"]) && isset($_POST["categorie"])){
                    ini_set('display_errors',1);
                    error_reporting(E_ALL);
                    $examens=$_POST["examen"];
                    $somme=$_POST["somme"];
                    $type=$_POST["type"];
                    $date_paiement=$_POST["date_paiement"];
                    $eleves=explode(' ',$_POST["eleve"]);

                    $type_examen=$_POST["type_examen"];

                    $eleve =$BDD->prepare("SELECT id_eleve from eleves where nom=:nom and prenom=:prenom");
                    $eleve->bindParam("nom",$eleves[0]);
                    $eleve->bindParam("prenom",$eleves[1]);
                    $eleve->execute();

                    foreach($eleve as $result){
                        $result["id_eleve"];
                    }
     
                    $examen =$BDD->prepare("SELECT id_examen from examen where date=:date and type=:type");
                    $examen->bindParam("date",$examens);
                    $examen->bindParam("type",$type_examen);
                    $examen->execute();

                    $id_examen=$examen->fetchObject();
                    $paiment=$BDD->prepare("INSERT INTO paiement_echelonne values(NULL,:somme,:id_eleve,:id_examen,NULL,:date_p)");
                    $paiment->bindParam("somme",$somme);
                    $paiment->bindParam("id_eleve",$result["id_eleve"]);
                    $paiment->bindParam("id_examen",$id_examen->id_examen);
                    $paiment->bindParam("date_p",$date_paiement);
                    $paiment->execute();

                    $_SESSION["examen"]=$_POST["examen"];
                    $_SESSION["somme"]=$_POST["somme"];
                    $_SESSION["type"]="Échelonné";
                    $_SESSION["date_paiement"]=$_POST["date_paiement"];
                    $_SESSION["eleve"]=$eleves;
                    $_SESSION["type_examen"]=$_POST["type_examen"];
                    $_SESSION["categorie"]=$_POST["categorie"];
                    header("location: recipisse.php",true);
                    
                }
            }

}
?>