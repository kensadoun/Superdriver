<?php
ob_start();
    session_start();
    if(!isset($_SESSION['nom'])){
        header("location:../../connexion.php",true);
    }
    else{
        require_once "../connexionBDD.php";
        /*$username="user1";
        $passeword="user1";
        $BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);*/
        echo'
            <!DOCTYPE html>
            <html>
                <head>
                    <meta charset="utf-8">
                    <meta http-equiv="X-UA-Compatible" content="IE=edge">
                    <title>Page Title</title>
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
                    <link rel="stylesheet" type="text/css" media="screen" href="../../css/admin2.css">
                    <link rel="stylesheet" href="../../css/attestation.css">
                    <script src="main.js"></script>
                </head>
                <body>
                    <div class="posP">
                        <div class="posF nav-item dropdown">
                            <a href="#" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action">
                                <img src="../image/person.svg" class="person">
                                <b> Secrétaire</b>
                            </a>
                            <div class="dropdown-menu">
                                <a href="../profile.php" class="dropdown-item"> <img src="../image/person-gear.svg" /> <i class="fa fa-user-o"></i> Profile</a>
                                <div class="divider dropdown-divider"></div>
                                 <a href="../deconnexion.php" class="dropdown-item"><i class="material-icons"><img src="../image/box-arrow-right.svg" /></i> Déconnexion</a>
                            </div>
                        </div>
                    </div>
                    <span id="toggler"  ><img onclick="toggleModal2()" src="../image/hamburger_menu_navbar_options_icon_196495.svg"></span>

                    <div class="side-menu fermer">
                        <div class="brand-name">
                            <h1>Brand</h1>
                        </div>
                        <ul>
                            <a href="compte.php"><img src="../image/school.png">&nbsp;Compte</a>
                            <a href="groupe.php"><img src="../image/reading-book (1).png">&nbsp;Groupes</a>
                            <a href="index.php"><img src="../image/reading-book (1).png">&nbsp;Eleve</a>
                            <a href="moniteur.php"><img src="../image/teacher2.png">&nbsp;Moniteur</a>
                            <a href="vehicule.php"><img src="../image/car2.png  ">&nbsp;Vehicules</a>
                            <div id="planning">
                                <a href="#"><img src="../image/school.png">&nbsp;Planning</a>
                                <a class="seance" href="code.php"><img src="../image/school.png">&nbsp;Planning cours de code</a>
                                <a class="seance" href="conduite.php"><img src="../image/school.png">&nbsp;Planning lecons de conduite</a>
                            </div>
                            <a href="examen.php"><img src="../image/school.png">&nbsp;Examens</a>
                            <div id="paiement">
                                <a href="#"><img src="../image/payment.png">&nbsp;Paiment</a>
                                <a class="gestion_paiement" href="paiement_forfaitaire.php">&nbsp;Paiement Forfaitaire</a>
                                <a class="gestion_paiement" href="payement.php">&nbsp;Paiement Échelonné</a>
                            </div>
                            <a href="attestation.php"><img src="../image/school.png">&nbsp;Nouveaux conducteurs</a>
                            <a href="recipice.php"><img src="../image/school.png">&nbsp;Recipise de paiment</a>
                        </ul>
                    </div>

                    <div class="container1">
                        <p class="titre">Nouveaux conducteurs</p>
                    </div>
                        

    
                    <div class="container">
                        <div class="search-container">
                            <form method="POST" id="rechercher" >
                                <input type="text" placeholder="Recherche..." name="search">
                                <form method="POST"><button type="submit" name="recherche"  >Rechercher</button></form>
                            </form>
                        </div>
                        <table class="table " id="masque">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">nom</th>
                                    <th scope="col">prénom</th>
                                    <th scope="col">Téléphone</th>
                                    <th scope="col">date_naissance</th>
                                    <th scope="col">nationalité</th>
                                    <th scope="col">adresse</th>
                                    <th scope="col">catégorie </th>
                                    <th scope="col">Attestation</th>
                                </tr>
                            </thead>

                        <tbody>';
                            if(isset($_POST["recherche"])){
                                if(!empty($_POST["search"])){
                                    ini_set('display_errors',1);
                                    error_reporting(E_ALL);
                                    $e=$_POST["search"];
                                    $p=strpos($e," ");
                                    if($p===FALSE){
                                        $eleves=$BDD->prepare("SELECT  e.id_eleve,e.nom,e.prenom,e.telephone,e.date_naissance,e.nationalite,e.adresse,e.catégorie_permis_demandee ,exam.date as examen FROM eleves e,passer p ,examen exam where e.id_eleve=p.id_eleve and p.id_examen=exam.id_examen and  p.etat=1 and p.id_examen IN(SELECT ex.id_examen FROM examen ex where ex.type='circulation') and (e.nom LIKE '%$e%' or e.prenom LIKE '%$e%') ORDER BY exam.date DESC  ");
                                        $eleves->execute();
                                    }
                                    else{
                                        $m=explode(" ",$e);
                                        $eleves=$BDD->prepare("SELECT  e.id_eleve,e.nom,e.prenom,e.telephone,e.date_naissance,e.nationalite,e.adresse,e.catégorie_permis_demandee ,exam.date as examen FROM eleves e,passer p ,examen exam where e.id_eleve=p.id_eleve and p.id_examen=exam.id_examen and  p.etat=1 and p.id_examen IN(SELECT ex.id_examen FROM examen ex where ex.type='circulation') and (e.nom LIKE '%$m[0]%' and e.prenom LIKE '%$m[1]%') or (e.nom LIKE '%$m[1]%' and e.prenom LIKE '%$m[0]%')  ORDER BY exam.date DESC ");
                                        $eleves->execute();
                                    }
                                }
                                
                            }
                            else{
                                $eleves=$BDD->prepare("SELECT  e.id_eleve,e.nom,e.prenom,e.telephone,e.date_naissance,e.nationalite,e.adresse,e.catégorie_permis_demandee ,exam.date as examen FROM eleves e,passer p ,examen exam where e.id_eleve=p.id_eleve and p.id_examen=exam.id_examen and  p.etat=1 and p.id_examen IN(SELECT ex.id_examen FROM examen ex where ex.type='circulation') ORDER BY exam.date DESC ");
                                $eleves->execute();
                            }
                            foreach($eleves AS $result){
                                $id=$result["id_eleve"];
                                $nom=$result["nom"];
                                $prenom=$result["prenom"];
                                $telephone=$result["telephone"];
                                $date_naissance=$result["date_naissance"];
                                $nationalite=$result["nationalite"];
                                $adresse=$result["adresse"];
                                $catégorie_permis_demandee=$result["catégorie_permis_demandee"];
                                $examen=$result["examen"];
                                $centre="El_Kseur";
                                echo ' <tr>
                                            <th class="th1" scope="row">'.$id.'</th>
                                                <td class="td1">'.$nom.'</td>
                                                <td>'.$prenom.'</td>
                                                <td>'.$telephone.'</td>
                                                <td>'.$date_naissance.'</td>
                                                <td>'.$nationalite.'</td>
                                                <td>'.$adresse.'</td>
                                                <td>'.$catégorie_permis_demandee.'</td>
                                                <td><button class="btn btn-danger"><a class="text-light" href="imprimer_attestation.php? impr='.$id.'&nom='.$nom.'&prenom='.$prenom.'&date_naissance='.$date_naissance.'&nationalite='.$nationalite.'&adresse='.$adresse.'&categorie='.$catégorie_permis_demandee.'&examen='.$examen.'&centre='.$centre.' ">imprimer</a></button></td>
                                                <td> 
                                                    <div class="container ">
                                                        <button  class="btn btn-primary btn1" data-bs-toggle="modal" data-bs-target="#myModal" name="modifier">modifier</button>
                                                        <form method="POST">
                                                            <input type="hidden"  name="idA" class="form-control ina1" value="'.$id.'" >
                                                            <input type="hidden"  name="nomA" class="form-control ina2" value="'.$nom.'" >
                                                            <input type="hidden"  name="prenomA" class="form-control ina3" value="'.$prenom.'" >
                                                            <input type="hidden"  name="prenomA" class="form-control ina8" value="'.$telephone.'" >
                                                            <input type="hidden"  name="date_naissanceA" class="form-control ina4" value="'.$date_naissance.'" >
                                                            <input type="hidden"  name="nationaliteA" class="form-control ina5" value="'.$nationalite.'" >
                                                            <input type="hidden"  name="adresseA" class="form-control ina6" value="'.$adresse.'" >
                                                            <input type="hidden"  name="catégorie_permis_demandeeA" class="form-control ina7" value="'.$catégorie_permis_demandee.'" >
                                                            <div class="modal" id="myModal">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title">Modifier les informations de l éléve</h5>
                                                                            <button type="button" class="btn-close bt1" data-bs-dismiss="modal">x</button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <div class="mb-3">
                                                                                <input type="hidden" id="i1" name="id" class="form-control in" required   >
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required">Nom</label>
                                                                                <input type="text" name="nom" class="form-control in" required  >
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required">prénom</label>
                                                                                <input type="text" name="prenom" class="form-control in " required >
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required">Téléphone</label>
                                                                                <input type="text" name="telephone" class="form-control in " required >
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required">Date de naissance</label>
                                                                                <input type="date" name="date_naissance" class="form-control in" required "></input>
                                                                            </div>

                                                                            <div class="mb-3 b">
                                                                                <label class="form-label required">Nationalité</label>
                                                                                <input type="text"  name="nationalite" class="form-control in" required "></input>
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required">adresse</label>
                                                                                <input type="text" name="adresse"  class="form-control in" required "></input>
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required ">catégorie</label>
                                                                                <input type="text" name="catégorie_permis_demandee" class="form-control in"></input>
                                                                            </div>
  
                                                                        </div>

                                                                        <div class="modal-footer">
                                                                            <button type="submit" class="btn btn-primary btn2" name="confirmer">confirmer</button>
                                                                            <button type="submit" class="btn btn-danger">Cancel</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </td>
                                            </th>

                                        </tr>
                        </tbody>
              ';
            }
            echo"</table>
            </div> 
                    <script src='https://code.jquery.com/jquery-3.3.1.slim.min.js' integrity='sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo' crossorigin='anonymous'></script>
                    <script src='https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js' integrity='sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49' crossorigin='anonymous'></script>
                    <script src='https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js' integrity='sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy' crossorigin='anonymous'></script>
                    <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js' integrity='sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW' crossorigin='anonymous'></script>
                    <script src='../../javascript/admin.js'></script> 
                
                </body>
                </html>
            ";
      
    }
?>
    
 