<?php
ob_start();
    session_start();
    if(!isset($_SESSION['nom'])){
        header("location:../../connexion.php",true);
    }
    else{
        require_once "../connexionBDD.php";
        /*$username="user1";
        $passeword="user1";
        $BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);*/
        echo '<!DOCTYPE html>
            <head>
            <link rel="stylesheet" href="../../css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

            <link href="../../css/select2.min.css" rel="stylesheet" />
            
             <link rel="stylesheet" type="text/css" media="screen" href="../../css/admin2.css">
             <script src="main.js"></script>
                <title>Interface d administration</title>
            
            </head>
            <body>
                <div class="posP">
                    <div class="posF nav-item dropdown">
                        <a href="#" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action">
                            <img src="../image/person.svg" class="person">
                            <b> Secrétaire</b>
                        </a>
                        <div class="dropdown-menu">
                            <a href="../profile.php" class="dropdown-item"> <img src="../image/person-gear.svg" /> <i class="fa fa-user-o"></i> Profile</a>
                            <div class="divider dropdown-divider"></div>
                            <a href="../deconnexion.php" class="dropdown-item"><i class="material-icons"><img src="../image/box-arrow-right.svg" /></i> Déconnexion</a>
                        </div>
                    </div>
                </div>
                <span id="toggler"  ><img onclick="toggleModal2()" src="../image/hamburger_menu_navbar_options_icon_196495.svg"></span>
                <div class="side-menu fermer">
                    <div class="brand-name">
                        <h1>Brand</h1>
                    </div>
                    <ul>
                        <a href="compte.php"><img src="../image/school.png">&nbsp;Compte</a>
                        <a href="groupe.php"><img src="../image/reading-book (1).png">&nbsp;Groupes</a>
                        <a href="index.php"><img src="../image/reading-book (1).png">&nbsp;Eleve</a>
                        <a href="moniteur.php"><img src="../image/teacher2.png">&nbsp;Moniteur</a>
                        <a href="vehicule.php"><img src="../image/car2.png  ">&nbsp;Vehicules</a>
                        <div id="planning">
                            <a href="#"><img src="../image/school.png">&nbsp;Planning</a>
                            <a class="seance" href="code.php"><img src="../image/school.png">&nbsp;Planning cours de code</a>
                            <a class="seance" href="conduite.php"><img src="../image/school.png">&nbsp;Planning lecons de conduite</a>
                        </div>
                        <a href="examen.php"><img src="../image/school.png">&nbsp;Examens</a>
                        <div id="paiement">
                            <a href="#"><img src="../image/payment.png">&nbsp;Paiment</a>
                            <a class="gestion_paiement" href="paiement_forfaitaire.php">&nbsp;Paiement Forfaitaire</a>
                            <a class="gestion_paiement" href="payement.php">&nbsp;Paiement Échelonné</a>
                        </div>
                        <a href="attestation.php"><img src="../image/school.png">&nbsp;Nouveaux conducteurs</a>
                        <a href="recipice.php"><img src="../image/school.png">&nbsp;Recipise de paiment</a>
                    </ul>
                </div>

                <div class="container1">
                    <p class="titre">Gestion des moniteurs</p>
                   
                    <button onclick="toggleModal()" class="ajouter bt" name="ajouter">Ajouter</button>
                    
                      
                    <div class="modal1" id="user-modal">
                        <div class="modal1-header">
                            <h2>Ajouter un moniteur</h2>   
                        </div>

                        <form  id="user-form-1"  >
                            <div class="form-group position-relative">
                                <label class="required" for="nom_aj" class="form-label">Nom </label>
                                <input type="text" class="form-control " id="nom_aj" name="nom" required <i class="fa fa-times" id="verif_icone"></i> 
                                <div class="valid-feedback feedback-icone ">
                                    <i class="verif_icone fa fa-check"> </i>
                                </div>
                                <span id="error_nom"></span>
                            </div>

                            <div class="form-group position-relative">
                                <label class="required" for="prenom">Prénom </label>
                                <input  type="text" id="prenom_aj" class="form-control " name="prenom" required>
                                <div class="valid-feedback feedback-icon">
                                    <i class="verif_icone" class="fa fa-check"></i>
                                </div>
                                <span id="error_prenom"></span>
                            </div>
                  

                            <label for="Adresse">Adresse :</label>
                            <input type="text" id="adresse_aj" name="adresse_aj" class="form-control" required>

                            <div class="form-group position-relative">
                                <label class="required"class="required" for="telephone">telephone </label>
                                <div class="input-group">
                                    <span class="input-group-text" id="inputGroupPrepend2">0</span><input type="tel" class="form-control" id="telephone_aj" name="telephone_aj" max="10" class="form-control" required>
                                </div>
                            
                                <div class="valid-feedback feedback-icone ">
                                    <i class="verif_icone fa fa-check"> </i>
                                </div>
                                <span id="error-Tel" ></span>
                            </div>

                            <label class="form-label">Type de lecons enseignées</label>
                            <select id="type_lecon" name="type_lecons" >
                                <option hidden disable>Séléctionner un type</option>
                                <option>Théorique</option>
                                <option>Pratique</option>
                                <option>Théorique et Pratique </option>
                            </select>

                            <label for="categoriePermis" id="label_c" style="display:none" >Catégorie de permis enseignée :</label>
                            <select id="categoriePermis_aj" name="categoriePermis" hidden >
                                <option hidden disable>Sélectionnez une catégorie</option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="E">E</option>
                            </select>

                            <input type="submit"  value="Suivant" >
                            <button class="modal1-close" onclick="toggleModal()">Fermer</button>
                
                        </form>
           
                        <form id="user-form-2" style="display: none;" method="POST" >
                            <!--<div >-->
                            <div  class="form-group position-relative">
                            <label class="required" for="Identifiant">N de carte nationale d identite </label>
                            <input type="number" id="Identifiant" name="Identifiant" class="form-control" required>
                            <span id="error_identifiant"> </span>
                        </div>
                        
                        <div  class="form-group position-relative">
                            <label class="required"  for="Mot de passe">Mot de passe  </label>
                            <input type="password" id="Mot de passe" name="mot_passe" class="form-control" required>
                            <span id="error_mot_passe"></span>
                        </div>

                        <div  class="form-group position-relative">
                            <label class="required" for="Mot de passe2">Confirmer le mot de passe  </label>
                            <input type="password" id="Mot de passe2" name="mot_passe" class="form-control" required>
                            <span id="error_mot_passe2"></span>
                        </div>

                        <div  class="form-group position-relative">
                            <label class="required" for="adresseMail">Adresse mail de recuperation </label>
                            <input type="email" id="adresseMail" name="adrMail" class="form-control" required>
                            <span id="error_adresse_mail"></span>
                        </div>

                        <div>
                            <input type="button" class="btn" value="Précédent" onclick="showForm1()">
                            <input type="hidden" name="hide" id="in_hide">
                            <input type="submit" name="en" value="Enregistrer">
                        </div>
                           <!-- </div>-->
                        </form>
                    </div>
                </div>

                <div class="container">
                    <div class="search-container">
                        <form method="POST" id="rechercher" >
                            <input type="text" placeholder="Recherche..." name="search">
                            <form method="POST"><button type="submit" name="recherche"  >Rechercher</button></form>
                        </form>
                    </div>
                    <table class="table " id="masque">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">nom</th>
                                <th scope="col">prénom</th>
                                <th scope="col">Numero de téléphone</th>
                                <th scope="col">Type de lecons</th>
                                <th scope="col">Catégorie</th>
                                <th scope="col">action</th>
                            </tr>
                        </thead>

                        <tbody>';
                            if(isset($_POST["recherche"])){
                                if(!empty($_POST["search"])){
                                    ini_set('display_errors',1);
                                    error_reporting(E_ALL);
                                    $e=$_POST["search"];
                                    $p=strpos($e," ");
                                    if($p===FALSE){
                                        $moniteurs=$BDD->prepare("SELECT * from moniteur where en_fonction=1 and nom LIKE '%$e%' or prenom LIKE '%$e%' ");
                                        $moniteurs->execute();
                                    }
                                    else{
                                        $m=explode(" ",$e);
                                        $moniteurs=$BDD->prepare("SELECT * from moniteur where en_fonction=1 and (nom LIKE '%$m[0]%' and prenom  LIKE '%$m[1]%') or (nom LIKE '%$m[1]%' and prenom LIKE '%$m[0]%') ");
                                        $moniteurs->execute();
                                    }
                                }
                                
                            }
                            else{
                                $moniteurs=$BDD->prepare("SELECT * FROM moniteur where en_fonction=1  ORDER BY id_moniteur DESC ");
                                $moniteurs->execute();
                            }

                            foreach($moniteurs AS $result){
                                $id=$result["id_moniteur"];
                                $nom=$result["nom"];
                                $prenom=$result["prenom"];
                                $type_lecon=$result["type_lecon"];
                                if($type_lecon=='Pratique' || $type_lecon=="Théorique et Pratique"){
                                    $categorie=$result["categorie"];
                                }
                                else{
                                    $categorie='/';
                                }
        
                                $telephone=$result["numero_telephone"];
                                $adresse=$result["adresse"];
                                $t='moniteur';
                                echo ' <tr>
                                            <th class="th1" scope="row">'.$id.'</th>
                                                <td class="td1">'.$nom.'</td>
                                                <td>'.$prenom.'</td>
                                                <td>'.$telephone.'</td> 
                                                <td>'.$type_lecon.'</td> 
                                                <td>'.$categorie.'</td> 
                                                <td><button class="btn btn-danger"><a class="text-light" href="../supprimer.php? supp='.$id.'&type='.$t.'" >Archiver</a></button></td>
                                                <td> 
                                                    <div class="container ">
                                                        <button  class="btn btn-primary btn1" data-bs-toggle="modal" data-bs-target="#myModal" name="modifier">modifier</button>
                                                        <form method="POST">
                                                            <input type="hidden"  name="idA" class="form-control ina1" value="'.$id.'" >
                                                            <input type="hidden"  name="nomA" class="form-control ina2" value="'.$nom.'" >
                                                            <input type="hidden"  name="prenomA" class="form-control ina3" value="'.$prenom.'" >
                                                            <input type="hidden"  name="prenomA" class="form-control ina4" value="'.$adresse.'" >
                                                            <input type="hidden"  name="prenomA" class="form-control ina5" value="'.$telephone.'" >
                                                            <input type="hidden"  name="date_naissanceA" class="form-control ina6" value="'.$type_lecon.'" > 
                                                            <input type="hidden"  name="nationaliteA" class="form-control ina7" value="'.$categorie.'" >
                                                            <div class="modal" id="myModal">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title">Modifier les informations de moniteur</h5>
                                                                            <button type="button" class="btn-close bt1" data-bs-dismiss="modal">x</button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <div class="mb-3">
                                                                                <!--<label class="form-label required">id</label>-->
                                                                                <input type="hidden" id="i1" name="id" class="form-control in" required   >
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required">Nom</label>
                                                                                <input type="text" name="nom" class="form-control in" required  >
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required">prénom</label>
                                                                                <input type="text" name="prenom" class="form-control in " required >
                                                                            </div>
                                                                            
                                                                            <div class="mb-3">
                                                                                <label class="form-label required ">adresse</label>
                                                                                <input type="text" name="adresse"  class="form-control in" required "></input>
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required ">Téléphone</label>
                                                                                <input type="number" name="telephone" class="form-control in " required >
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required">Type de lecons enseignées </label>
                                                                                <select class="in" name="type_lecon">
                
                                                                                </select>
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required ">Catégorie </label>
                                                                                <select class="in" name="categorie">
             
                                                                                </select>
                                                                            </div>

                                                                        </div>

                                                                        <div class="modal-footer">
                                                                            <button type="submit" class="btn btn-primary btn2" name="confirmer">confirmer</button>
                                                                            <button type="submit" class="btn btn-danger">Cancel</button>
                                                                        </div>
                                                                    </div>
                                                                  
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </td>
                                            </th>

                                        </tr>
                        </tbody>
              ';
            }
            echo"</table>
            <script src='../../javascript/jquery.min.js'></script>
            <script src='../../javascript/popper.min.js'></script>
            <script src='../../javascript/bootstrap.min.js'></script>
            <script src='../../javascript/bootstrap.bundle.min.js'></script>
            <script src='../../javascript/select2.min.js'></script>
            <script src='../../javascript/moniteur.js'></script> 
                </div> 
    </html>";

            if(isset($_POST["confirmer"])){
                error_reporting(E_ALL);
                ini_set('display_errors','On');
                $modif=$BDD->prepare("UPDATE moniteur set nom=:nom ,prenom=:prenom, adresse=:adresse ,numero_telephone=:telephone,categorie=:categorie ,type_lecon=:type where id_moniteur=:id");
                $modif->bindParam("nom",$_POST["nom"]);
                $modif->bindParam("prenom",$_POST["prenom"]);
                $modif->bindParam("adresse",$_POST["adresse"]);
                $modif->bindParam("telephone",$_POST["telephone"]);
                $modif->bindParam("categorie",$_POST["categorie"]);
                $modif->bindParam("type",$_POST["type_lecon"]);
                $modif->bindParam("id",$_POST["id"]);
                $modif->execute();
            
                header("location: moniteur.php",true);
            }  
            
            //if(isset($_POST["en"])){
                if(isset($_POST["hide"])){
                    ini_set('display_errors', 1);
                    error_reporting(E_ALL);
                    $n=json_decode($_POST["hide"]);
                    $nbr=$BDD->prepare("SELECT COUNT(id_moniteur) as m FROM moniteur");
                    $nbr->execute();

                    $nb=$nbr->fetchObject();
                    if($nb==0){
                        $id=1;
                    }
                    else{
                        $max_id=$BDD->prepare("SELECT MAX(id_moniteur) as m FROM moniteur");
                        $max_id->execute();
                        foreach($max_id AS $max){
                            $id=$max["m"]+1;
                        }
                    }
                    $telephone=intval($n->{'telephone'});
                    if($n->{'type_lecon'}=='Pratique' || $n->{'type_lecon'}=='Théorique et Pratique'){
                        $moniteur=$BDD->prepare('INSERT INTO moniteur values(:id,:nom,:prenom,:adresse,:telephone,:categorie,:type_lecon,1 )');
                        $moniteur->bindParam("id",$id);
                        $moniteur->bindParam("nom",$n->{'nom'});
                        $moniteur->bindParam("prenom",$n->{'prenom'});
                        $moniteur->bindParam("adresse",$n->{'adresse'});
                        $moniteur->bindParam("telephone",$telephone);
                        $moniteur->bindParam("categorie",$n->{'categorie'});
                        $moniteur->bindParam("type_lecon",$n->{'type_lecon'});
                        $moniteur->execute();
                    }
                    
                    elseif($n->{'type_lecon'}=='Théorique'){
                        $moniteur=$BDD->prepare('INSERT INTO moniteur values(:id,:nom,:prenom,:adresse,:telephone,NULL,:type_lecon,1 )');
                        $moniteur->bindParam("id",$id);
                        $moniteur->bindParam("nom",$n->{'nom'});
                        $moniteur->bindParam("prenom",$n->{'prenom'});
                        $moniteur->bindParam("adresse",$n->{'adresse'});
                        $moniteur->bindParam("telephone",$telephone);
                        $moniteur->bindParam("type_lecon",$n->{'type_lecon'});
                        $moniteur->execute();
                    }

                    $type_utilisateur="moniteur";
                    $compte=$BDD->prepare('INSERT INTO compte values(:numero_utilisateur,:mot_passe,:type_utilisateur,:id_moniteur,NULL,1,:adresse)');
                    $compte->bindParam("numero_utilisateur",$_POST["Identifiant"]);
                    $mot_de_passe=password_hash($_POST["mot_passe"],PASSWORD_DEFAULT);
                    $compte->bindParam("mot_passe",$mot_de_passe);
                    $compte->bindParam("type_utilisateur",$type_utilisateur);
                    $compte->bindParam("id_moniteur",$id);
                    $compte->bindParam("adresse",$_POST["adrMail"]);
                    $compte->execute();
                    header("location: moniteur.php",true);
                }
            //}   
            ob_end_flush();
    }
?>