<?php

use LDAP\Result;

ob_start();
    session_start();
    if(!isset($_SESSION['nom'])){
        header("location:../../connexion.php",true);
    }
    else{
        require_once "../connexionBDD.php";
        /*$username="user1";
        $passeword="user1";
        $BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);*/
        echo '<!DOCTYPE html>
            <head>
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
                <link rel="stylesheet" href="../../css/admin2.css">
                <title>Interface d administration</title>
            
            </head>
            <body>
                <div class="posP">
                    <div class="posF nav-item dropdown">
                        <a href="#" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action">
                            <img src="../image/person.svg" class="person">
                            <b> Secrétaire</b>
                        </a>
                        <div class="dropdown-menu">
                            <a href="../profile.php" class="dropdown-item"> <img src="../image/person-gear.svg" /> <i class="fa fa-user-o"></i> Profile</a>
                            <div class="divider dropdown-divider"></div>
                            <a href="../deconnexion.php" class="dropdown-item"><i class="material-icons"><img src="../image/box-arrow-right.svg" /></i> Déconnexion</a>
                        </div>
                    </div>
                </div>
                <span id="toggler"  ><img onclick="toggleModal2()" src="../image/hamburger_menu_navbar_options_icon_196495.svg"></span>

                <div class="side-menu fermer">
                    <div class="brand-name">
                        <h1>Brand</h1>
                    </div>
                    <ul>
                        <a href="compte.php"><img src="../image/school.png">&nbsp;Compte</a>
                        <a href="groupe.php"><img src="../image/reading-book (1).png">&nbsp;Groupes</a>
                        <a href="index.php"><img src="../image/reading-book (1).png">&nbsp;Eleve</a>
                        <a href="moniteur.php"><img src="../image/teacher2.png">&nbsp;Moniteur</a>
                        <a href="vehicule.php"><img src="../image/car2.png  ">&nbsp;Vehicules</a>
                        <div id="planning">
                            <a href="#"><img src="../image/school.png">&nbsp;Planning</a>
                            <a class="seance" href="code.php"><img src="../image/school.png">&nbsp;Planning cours de code</a>
                            <a class="seance" href="conduite.php"><img src="../image/school.png">&nbsp;Planning lecons de conduite</a>
                        </div>
                        <a href="examen.php"><img src="../image/school.png">&nbsp;Examens</a>
                        <div id="paiement">
                            <a href="#"><img src="../image/payment.png">&nbsp;Paiment</a>
                            <a class="gestion_paiement" href="paiement_forfaitaire.php">&nbsp;Paiement Forfaitaire</a>
                            <a class="gestion_paiement" href="payement.php">&nbsp;Paiement Échelonné</a>
                        </div>
                        <a href="attestation.php"><img src="../image/school.png">&nbsp;Nouveaux conducteurs</a>
                        <a href="recipice.php"><img src="../image/school.png">&nbsp;Recipise de paiment</a>
                    </ul>
                </div>

                <div class="container1">
                    <p class="titre">Gestion des Groupes</p>
                    <button onclick="toggleModal()" class="ajouter bt" name="ajouter">Créer</button>

                    <div class="modal1" id="user-modal">
                        <div class="modal1-header">
                            <h2>Creer un groupe</h2>   
                        </div>

                        <form method="POST" id="user-form-1"  >
                            <label class="required" for="nom_aj" class="form-label">Nom du groupe</label>
                            <input type="text" class="form-control " id="nom_aj" name="nom" required > 
                            <button class="modal1-close" onclick="toggleModal()">Fermer</button>
                            <input type="submit" name="en" value="Enregistrer">
                        </form>
                    </div>
                </div>

                <div class="container">
                    <div class="search-container">
                        <form method="POST" id="rechercher" >
                            <input type="text" placeholder="Recherche..." name="search">
                            <form method="POST"><button type="submit" name="recherche"  >Rechercher</button></form>
                        </form>
                    </div>
                    <table class="table " id="masque">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">nom</th>
                                <th scope="col">Eleves</th>
                                <th scope="col">action</th>
                            </tr>
                        </thead>

                        <tbody>';
                            if(isset($_POST["recherche"])){
                                if(!empty($_POST["search"])){
                                    ini_set('display_errors',1);
                                    error_reporting(E_ALL);
                                    $e=$_POST["search"];
                                    $p=strpos($e," ");
                                    if($p===FALSE){
                                        $groupes=$BDD->prepare("SELECT * from groupe where   nom LIKE '%$e%'  order by id_groupe ASC");
                                        $groupes->execute();
                                    }
                                    else{
                                        $m=explode(" ",$e);
                                        $groupes=$BDD->prepare("SELECT * from groupe where nom LIKE '%$m[0]%' and nom LIKE '%$m[1]%' order BY id_groupe ASC ");
                                        $groupes->execute();
                                    }
                                }
                                
                            }
                            else{
                                $groupes=$BDD->prepare("SELECT * FROM groupe   ORDER BY id_groupe DESC  ");
                                $groupes->execute();
                            }
                            foreach($groupes AS $result){
                                $id=$result["id_groupe"];
                                $nom=$result["nom"];
                                $t='groupe';
                                echo ' <tr>
                                            <th class="th1" scope="row">'.$id.'</th>
                                                <td class="td1">'.$nom.'</td>
                                                ';
                                                $_SESSION["groupe"]=$id;
                                                echo'
                                                <td><button class="btn btn-danger"><a class="text-light" href="eleve_par_groupe.php? groupe='.$id.' " >Voir la liste</a></button></td>
                                                <td>
                                                    <button class="btn btn-danger"><a class="text-light" href="../supprimer.php? supp='.$id.'&type='.$t.'" >supprimer</a></button>
                                                    <button  class="btn btn-primary btn1" data-bs-toggle="modal" data-bs-target="#myModal" name="modifier">modifier</button>
                                                    <form method="POST">
                                                        <input type="hidden"  name="idA" class="form-control ina1" value="'.$id.'" >
                                                        <input type="hidden"  name="nomA" class="form-control ina2" value="'.$nom.'" >
                            
                                                        <div class="modal" id="myModal">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title">Renommer</h5>
                                                                        <button type="button" class="btn-close bt1" data-bs-dismiss="modal">x</button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="mb-3">
                                                                            <input type="hidden" id="i1" name="id" class="form-control in" required   >
                                                                        </div>

                                                                        <div class="mb-3">
                                                                            <label class="form-label required">Nom</label>
                                                                            <input type="text" name="nom" class="form-control in" required  >
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="submit" class="btn btn-primary btn2" name="confirmer">confirmer</button>
                                                                            <button type="submit" class="btn btn-danger">Cancel</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </td>  
                                            </th>

                                        </tr>
                        </tbody>
              ';
            }
            echo"</table>
                   
                    <script src='https://code.jquery.com/jquery-3.3.1.slim.min.js' integrity='sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo' crossorigin='anonymous'></script>
                    <script src='https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js' integrity='sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49' crossorigin='anonymous'></script>
                    <script src='https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js' integrity='sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy' crossorigin='anonymous'></script>
                    <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js' integrity='sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW' crossorigin='anonymous'></script>
                   <script src='../../javascript/groupe.js'></script> 
                </div> 
    </html>";

            
            if(isset($_POST["confirmer"])){
                error_reporting(E_ALL);
                ini_set('display_errors','On');
                
                $modif=$BDD->prepare("UPDATE groupe set nom=:nom  where id_groupe=:id");
                $modif->bindParam("nom",$_POST["nom"]);
                $modif->bindParam("id",$_POST["id"]);
                $modif->execute();
            
                header("location: groupe.php",true);
            }
            if(isset($_POST["en"])){
                ini_set('display_errors', 1);
                error_reporting(E_ALL);

                $max_id=$BDD->prepare("SELECT max(id_groupe) as m FROM groupe");
                $max_id->execute();
                foreach($max_id AS $max){
                    $id=$max["m"]+1;
                }
                   
                $groupe=$BDD->prepare('INSERT INTO groupe values(:id,:nom)');
                $groupe->bindParam("id",$id);
                $groupe->bindParam("nom",$_POST["nom"]);
                $groupe->execute();
                header("location:   groupe.php",true);
            } 

            
            ob_end_flush();
    
    }

?>
   