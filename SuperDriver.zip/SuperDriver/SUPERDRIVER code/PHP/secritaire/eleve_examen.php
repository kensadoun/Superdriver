<?php
ob_start();
session_start();
if(!isset($_SESSION['nom'])){
    header("location:../../connexion.php",true);
}
else{
    if(isset($_SESSION['examen']) && !isset($_GET['examen'])){
        $id=$_SESSION['examen'];
    }
    else{
        $id=$_GET['examen'];
    }
    require_once "../connexionBDD.php";
    /*$username="user1";
    $passeword="user1";
    $BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);*/
    echo '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <title>Page Title</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

            <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
            <link rel="stylesheet" type="text/css" media="screen" href="../../css/admin2.css">
            <script src="main.js"></script>
        </head>
        <body>
            <div class="posP">
                <div class="posF nav-item dropdown">
                    <a href="#" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action">
                        <img src="../image/person.svg" class="person">
                       <b> Secrétaire</b>
                    </a>
                    <div class="dropdown-menu">
                        <a href="#" class="dropdown-item"> <img src="../image/person-gear.svg" /> <i class="fa fa-user-o"></i> Profile</a>
                        <div class="divider dropdown-divider"></div>
                        <a href="../deconnexion.php" class="dropdown-item"><i class="material-icons"><img src="../image/box-arrow-right.svg" /></i> Déconnexion</a>
                    </div>
                </div>
            </div>
        <div class="container1">
            <p class="titre">Liste des Eléves </p>
            
        </div>

        <div class="container">
            <div class="search-container">
                <form method="POST" id="rechercher" >
                    <input type="text" placeholder="Recherche..." name="search">
                    <form method="POST"><button type="submit" name="recherche"  >Rechercher</button></form>
                </form>
            </div>
                        <table class="table " id="masque">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nom</th>
                                    <th scope="col">Prenom</th>
                                    <th scope="col">Catégorie</th>
                                    <th scope="col">Date de naissance</th>
                                    <th scope="col">Nationalité</th>
                                    <th scope="col">Resultat</th>
                                </tr>
                            </thead>
                            <tbody>';

                            if(isset($_POST["recherche"])){
            
                                if(!empty($_POST["search"])){
                                    ini_set('display_errors',1);
                                    error_reporting(E_ALL);
                                    $e=$_POST["search"];
                                    $p=strpos($e," ");
                                    if($p===FALSE){
                                        $eleves=$BDD->prepare("SELECT e.id_eleve as id ,e.nom as nom ,e.prenom as prenom, e.catégorie_permis_demandee as categorie, e.date_naissance as date_naissance ,e.nationalite as nationalite ,p.etat as resultat, exam.type as type from eleves e,passer p, examen exam  where e.id_eleve=p.id_eleve and exam.id_examen=p.id_examen and exam.id_examen=:id and  (e.nom LIKE '%$e%' or e.prenom LIKE '%$e%' or e.catégorie_permis_demandee  LIKE '%$e%' or exam.type LIKE '%$e%' ) ORDER BY date DESC  ");
                                        $eleves->bindParam("id",$id);
                                        $eleves->execute();
                                    }
                          
                                }
                            }

                            else{
                                ini_set('display_errors',1);
                                error_reporting(E_ALL);
                                $eleves=$BDD->prepare("SELECT e.id_eleve as id,e.nom as nom ,e.prenom as prenom,e.catégorie_permis_demandee as categorie, e.date_naissance as date_naissance ,e.nationalite as nationalite ,p.etat as resultat ,exam.type as type from eleves e,passer p, examen exam  where e.id_eleve=p.id_eleve and exam.id_examen=p.id_examen and exam.id_examen=:id  ");
                                $eleves->bindParam("id",$id);
                                $eleves->execute();
                            }

                            
                            foreach($eleves AS $result){
                                $id_eleve=$result["id"];
                                $nom=$result["nom"];
                                $prenom=$result["prenom"];
                                $categorie=$result["categorie"];
                                $date_naissance=$result["date_naissance"];
                                $nationalite=$result["nationalite"];
                                $resultat=$result["resultat"];
                                $type=$result["type"];
                                

                                echo '          
                                <tr>
                                <th class="th1" scope="row">'.$id_eleve.'</th>
                                    <td class="td1">'.$nom.'</td>
                                    <td>'.$prenom.'</td>
                                    <td>'.$categorie.'</td>
                                    <td>'.$date_naissance.'</td>
                                    <td>'.$nationalite.'</td>';
                                    $autre=$BDD->prepare("SELECT count(exam.id_examen) as nbr from eleves e,passer p, examen exam  where e.id_eleve=p.id_eleve and exam.id_examen=p.id_examen and exam.id_examen!=:id and e.id_eleve=:id_eleve ");
                                    $autre->bindParam("id",$id);
                                    $autre->bindParam("id_eleve",$id_eleve);
                                    $autre->execute();
                                    foreach($autre as $r){

                                    }
                                    if($resultat===1){
                                        $msg="Réussi(e)";
                                        echo '<td style="color:#53AF50" >
                                                <form method="GET">'.$msg;
                                                if($r['nbr']==0){
                                                    echo'
                                                        <input type="hidden" name="eleve" value="'.$id_eleve.'">
                                                        <input type="hidden" name="examen" value="'.$id.'">
                                                        <button type="submit" class="btn btn-outline-danger  " style="border-color:#F9E0CF " name="modifier" >
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
                                                                <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
                                                            </svg>
                                                        </button>';
                                                }
                                                echo '
                                                </form>
                                            </td>
                                        ';
                                    }
                                    elseif($resultat===0){
                                        $msg="Echoué(e)";
                                        echo '
                                                    <form method="GET" >
                                                        <td style="color:#F24636" >'.$msg;
                                                        if($r['nbr']==0){
                                                            echo '<button type="submit" class="btn btn-outline-danger  " style="border-color:#F9E0CF "  name="modifier" >
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
                                                                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
                                                                </svg>
                                                            </button>
                                                            <input type="hidden" name="eleve" value="'.$id_eleve.'">
                                                            <input type="hidden" name="examen" value="'.$id.'">
                                                            ';
                                                        }
                                                        echo'
                                                            
                                                        </td> 
                                                    </form>
                                              ';
                                         
                                    }
                                    else{
                                        $msg="Pas encore";
                                        echo '<td style="color:orange" >
                                                    <form method="GET">
                                                        <input type="hidden" name="eleve" value="'.$id_eleve.'">
                                                        <input type="hidden" name="examen" value="'.$id.'">
                                                        <button type="submit" class="btn btn-success " name="reussi" >
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-emoji-smile-fill" viewBox="0 0 16 16">
                                                                <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zM7 6.5C7 7.328 6.552 8 6 8s-1-.672-1-1.5S5.448 5 6 5s1 .672 1 1.5zM4.285 9.567a.5.5 0 0 1 .683.183A3.498 3.498 0 0 0 8 11.5a3.498 3.498 0 0 0 3.032-1.75.5.5 0 1 1 .866.5A4.498 4.498 0 0 1 8 12.5a4.498 4.498 0 0 1-3.898-2.25.5.5 0 0 1 .183-.683zM10 8c-.552 0-1-.672-1-1.5S9.448 5 10 5s1 .672 1 1.5S10.552 8 10 8z"/>
                                                            </svg>
                                                        </button>
                                                        <button type="submit" class="btn btn-danger " name="echoue">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-emoji-frown-fill" viewBox="0 0 16 16">
                                                                <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zM7 6.5C7 7.328 6.552 8 6 8s-1-.672-1-1.5S5.448 5 6 5s1 .672 1 1.5zm-2.715 5.933a.5.5 0 0 1-.183-.683A4.498 4.498 0 0 1 8 9.5a4.5 4.5 0 0 1 3.898 2.25.5.5 0 0 1-.866.5A3.498 3.498 0 0 0 8 10.5a3.498 3.498 0 0 0-3.032 1.75.5.5 0 0 1-.683.183zM10 8c-.552 0-1-.672-1-1.5S9.448 5 10 5s1 .672 1 1.5S10.552 8 10 8z"/>
                                                            </svg>
                                                        </button>
                                                    </form>
                                                </td>'; 
                                    }
                                    
                                echo'
                                </th>
                                </tr>
                                </tbody>'; 
                            }

                            echo'
                            </table>
                            </div>
                            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
                                           <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
                                           <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
                                           <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
                                           <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script> 
                                           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
                               <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
                               <script src="../../javascript/planning.js"></script>';
                            
                            if(isset($_GET["reussi"])){
                                if(isset($_GET["eleve"]) && isset($_GET["examen"])){
                                    ini_set('display_errors',1);
                                    error_reporting(E_ALL);
                                    $id_eleve=$_GET["eleve"];
                                    $id_examen=$_GET["examen"];
                                    $resultat=$BDD->prepare("UPDATE passer set etat=1 where id_eleve=:id_eleve and id_examen=:id_examen");
                                    $resultat->bindParam("id_eleve",$id_eleve);
                                    $resultat->bindParam("id_examen",$id_examen);
                                    $resultat->execute();
                                    $_SESSION['examen']=$_GET["examen"];
                                    header("location: eleve_examen.php",true);
                                }
                            }

                            if(isset($_GET["echoue"])){
                                if(isset($_GET["eleve"]) && isset($_GET["examen"])){
                                    ini_set('display_errors',1);
                                    error_reporting(E_ALL);
                                    $id_eleve=$_GET["eleve"];
                                    $id_examen=$_GET["examen"];
                                    $resultat=$BDD->prepare("UPDATE passer set etat=0 where id_eleve=:id_eleve and id_examen=:id_examen");
                                    $resultat->bindParam("id_eleve",$id_eleve);
                                    $resultat->bindParam("id_examen",$id_examen);
                                    $resultat->execute();
                                    $_SESSION['examen']=$_GET["examen"];
                                    header("location: eleve_examen.php",true);
                                }
                            }

                            if(isset($_GET["modifier"])){
                                if(isset($_GET["eleve"]) && isset($_GET["examen"])){
                                    $id_eleve=$_GET["eleve"];
                                    $id_examen=$_GET["examen"];
                                    $resultat=$BDD->prepare("UPDATE passer set etat=NULL where id_eleve=:id_eleve and id_examen=:id_examen");
                                    $resultat->bindParam("id_eleve",$id_eleve);
                                    $resultat->bindParam("id_examen",$id_examen);
                                    $resultat->execute();
                                    $_SESSION['examen']=$_GET["examen"];
                                    header("location: eleve_examen.php",true);
                                }

                            }
                
}