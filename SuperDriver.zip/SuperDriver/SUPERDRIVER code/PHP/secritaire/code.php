<?php
ob_start();
session_start();

    if(!isset($_SESSION['nom'])){
        header("location:../../connexion.php",true);
    }

    else{
        require_once "../connexionBDD.php";
        /*$username="user1";
        $passeword="user1";
        $BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);*/
        if(isset($_POST['jour'])){
            echo'<option>  </option>';
                $date=$_POST['jour'];
                $heure=$BDD->prepare("SELECT heure FROM  cours_code where date=:jour");
                $heure->bindParam('jour',$date);
                $heure->execute();
                $ens_heures=array('08:00:00','09:00:00','10:00:00','11:00:00','13:00:00','14:00:00','15:00:00');
                foreach($heure as $result){
                    if(in_array($result['heure'],$ens_heures)){
                        $ind=array_search($result['heure'],$ens_heures);
                        array_splice($ens_heures, $ind,1);
                    }
                }
                $i=0;
                $l=count($ens_heures);
                while($i<$l){
                    echo'<option >'.$ens_heures[$i].'</option>';
                    $i=$i+1;
                }
            exit;
        }

        if(isset($_POST['date']) && isset($_POST['h'])){
            ini_set('display_errors',1);
            error_reporting(E_ALL);
            $d=$_POST['date'];
            $h=$_POST['heure'];
            $grps=$BDD->prepare("SELECT g.id_groupe as grp FROM  groupe g WHERE g.id_groupe NOT IN(SELECT c.id_groupe FROM cours_code c  where c.date=:jour and c.heure=:heure)");
            $grps->bindParam('jour',$d);
            $grps->bindParam('heure',$h);
            $grps->execute();
            $j=0;
            echo'<option>  </option>';
            foreach($grps as $result){
                echo'<option>'.$result['grp'].'</option>';
                
            }           
            exit;
        }
        if(isset($_POST['date2']) && isset($_POST['h2']) ){
            ini_set('display_errors',1);
            error_reporting(E_ALL);
            $d=$_POST['date2'];
            $h=$_POST['h2'];
            $moniteur=$BDD->prepare("SELECT m.nom as nm , m.prenom as prnm FROM   moniteur m WHERE (m.type_lecon='Théorique' or m.type_lecon='Théorique et Pratique') and m.en_fonction=1 and m.id_moniteur NOT IN(SELECT c.id_moniteur FROM cours_code c  where c.date=:jour and c.heure=:heure)");
            $moniteur->bindParam('jour',$d);
            $moniteur->bindParam('heure',$h);
            $moniteur->execute();
            $j=0;
            echo'<option>  </option>';
            foreach($moniteur as $result){
                echo'<option>'.$result['nm'].' '.$result['prnm'].'</option>';
            }

            exit;
        }
        echo'
            <!DOCTYPE html>
            <html>
                <head>
                    <meta charset="utf-8">
                    <meta http-equiv="X-UA-Compatible" content="IE=edge">
                    <title>Page Title</title>
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <link rel="stylesheet" href="../../css/bootstrap.min.css" >
                    <link rel="stylesheet" type="text/css" media="screen" href="../../css/admin2.css">
                    <link href="../../css/select2.min.css" rel="stylesheet" />
                </head>
                <body>
                <div class="posP">
                    <div class="posF nav-item dropdown">
                        <a href="#" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action">
                            <img src="../image/person.svg" class="person">
                            <b> Secrétaire</b>
                        </a>
                        <div class="dropdown-menu">
                            <a href="../profile.php" class="dropdown-item"> <img src="../image/person-gear.svg" /> <i class="fa fa-user-o"></i> Profile</a>
                            <div class="divider dropdown-divider"></div>
                            <a href="../deconnexion.php" class="dropdown-item"><i class="material-icons"><img src="../image/box-arrow-right.svg" /></i> Déconnexion</a>
                        </div>
                    </div>
                </div>
                <span id="toggler"  ><img onclick="toggleModal2()" src="../image/hamburger_menu_navbar_options_icon_196495.svg"></span>

                    <div class="side-menu fermer">
                        <div id="d" class="brand-name">
                            <h1>Brand</h1>
                        </div>
                        <ul>
                            <a href="compte.php"><img src="../image/school.png">&nbsp;Compte</a>
                            <a href="groupe.php"><img src="../image/reading-book (1).png">&nbsp;Groupes</a>
                            <a href="index.php"><img src="../image/reading-book (1).png">&nbsp;Eleve</a>
                            <a href="moniteur.php"><img src="../image/teacher2.png">&nbsp;Moniteur</a>
                            <a href="vehicule.php"><img src="../image/car2.png  ">&nbsp;Vehicules</a>
                            <div id="planning">
                                <a href="#"><img src="../image/school.png">&nbsp;Planning</a>
                                <a class="seance" href="code.php"><img src="../image/school.png">&nbsp;Planning cours de code</a>
                                <a class="seance" href="conduite.php"><img src="../image/school.png">&nbsp;Planning lecons de conduite</a>
                            </div>
                            <a href="examen.php"><img src="../image/school.png">&nbsp;Examens</a>
                            <div id="paiement">
                                <a href="#"><img src="../image/payment.png">&nbsp;Paiment</a>
                                <a class="gestion_paiement" href="paiement_forfaitaire.php">&nbsp;Paiement Forfaitaire</a>
                                <a class="gestion_paiement" href="payement.php">&nbsp;Paiement Échelonné</a>
                            </div>
                            <a href="attestation.php"><img src="../image/school.png">&nbsp;Nouveaux conducteurs</a>
                            <a href="recipice.php"><img src="../image/school.png">&nbsp;Recipise de paiment</a>
                        </ul>
                    </div>
                    <div class="container1">
                        <p class="titre">Gestion des plannings</p>
                        <button  onclick="toggleModal()" class="ajouter bt" name="ajouter">Ajouter</button>
                        <div class="modal1" id="user-modal">
                            <div class="modal1-header">
                                <h2>Ajouter une séance</h2>   
                            </div>
                            <form  method="POST"  >
                                <label for="nom">Date :</label>
                                <input type="date" id="date_aj" name="date" required>
                                <label for="essai">Heure :</label>
                                <select id="heure" name="heure" class="multiple-class" required> 
                                </select>
                                <label for="groupe">Groupe :</label>
                                <select id="groupe_aj" name="groupe" class="multiple-class" required>   
                                </select>
                                <label for="moniteur">Moniteur :</label>
                                <select id="moniteur_aj" name="moniteur"   class="multiple-class"  required>   
                                </select>
                                <div>
                                    <input type="submit"  value="Ajouter" name="ajouter2" /> 
                                    <button class="modal1-close" onclick="toggleModal()">Fermer</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="container">
                        <div class="search-container">
                            <form method="POST" id="rechercher" >
                                <input type="text" placeholder="Recherche..." name="search">
                                <form method="POST"><button type="submit" name="recherche"  >Rechercher</button></form>
                            </form>
                        </div>
                        <table class="table " id="masque">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Heure</th>
                                    <th scope="col">groupe</th>
                                    <th scope="col">Moniteur</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>                    
            ';
            if(isset($_POST["recherche"])){
                if(!empty($_POST["search"])){
                    ini_set('display_errors',1);
                    error_reporting(E_ALL);
                    $e=$_POST["search"];
                    $p=strpos($e," ");
                    if($p===FALSE){
                        $code=$BDD->prepare("SELECT c.*,g.nom as ng,m.nom as nm,m.prenom as pm from cours_code c,groupe g,moniteur m where c.id_moniteur=m.id_moniteur and c.id_groupe=g.id_groupe and c.date LIKE '%$e%' or c.heure LIKE '%$e%'  ORDER BY c.date DESC ,c.heure ASC ");
                        $code->execute();
                    }
                    else{
                        $m=explode(" ",$e);
                        $code=$BDD->prepare("SELECT c.*,g.nom as ng,m.nom as nm,m.prenom as pm  from cours_code c,groupe g,moniteur m where c.id_moniteur=m.id_moniteur and c.id_groupe=g.id_groupe and (c.date LIKE '%$m[0]%' and c.heure  LIKE '%$m[1]%') or (c.date LIKE '%$m[1]%' and c.heure LIKE '%$m[0]%') ORDER BY c.date DESC ,c.heure ASC ");
                        $code->execute();
                    }
                }
                
            }
            else{
                $code=$BDD->prepare("SELECT c.*,g.nom as ng,m.nom as nm,m.prenom as pm  FROM cours_code c ,groupe g,moniteur m where c.id_moniteur=m.id_moniteur and c.id_groupe=g.id_groupe ORDER BY c.date DESC ,c.heure ASC");
                $code->execute();
            }
            foreach($code AS $result){
                $id=$result["id_seance"];
                $date=$result["date"];
                $heure=$result["heure"];
                $groupe=$result["id_groupe"];
                $nmoniteur=$result["nm"];
                $pmoniteur=$result["pm"];
                $c="cours_code";
                echo '          <tr>
                                    <th class="th1" scope="row">'.$id.'</th>
                                        <td class="td1">'.$date.'</td>
                                        <td>'.$heure.'</td>
                                        <td>'.$groupe.'</td>
                                        <td>'.$nmoniteur.'</td>
                                        <td><button class="btn btn-danger"><a class="text-light" href="../supprimer.php? supp='.$id.'&type='.$c.' " >supprimer</a></button></td>
                                        <td> 
                                            <div class="container ">
                                                <button  class="btn btn-primary btn1" data-bs-toggle="modal" data-bs-target="#myModal" name="modifier">modifier</button>
                                                <form method="POST">
                                                    <input type="hidden"  name="idA" class="form-control ina1" value="'.$id.'" >
                                                    <input type="hidden"  name="dateA" class="form-control ina2" value="'.$date.'" >
                                                    <input type="hidden"  name="dateA" class="form-control ina6" value="'.$heure.'" >
                                                    <input type="hidden"  name="dateA" class="form-control ina7" value="'.$groupe.'" >
                                                    <input type="hidden"  name="dateA" class="form-control ina9" value="'.$nmoniteur.' '.$pmoniteur.'" >
                                                    ';
                                                    $h=$BDD->prepare("SELECT c.heure from cours_code c where c.date=:dat");
                                                    $h->bindParam('dat',$date);
                                                    $h->execute();
                                                    $ens_heures=array('08:00:00','09:00:00','10:00:00','11:00:00','13:00:00','14:00:00','15:00:00');
                                                    foreach($h as $result){
                                                                            
                                                        if(in_array($result['heure'],$ens_heures)){
                                                            $ind=array_search($result['heure'],$ens_heures);
                                                            array_splice($ens_heures, $ind,1);
                                                        }
                                                    }
                                                    
                                                    $g=$BDD->prepare("SELECT id_groupe from groupe where id_groupe!=:groupe ");
                                                    $g->bindParam('groupe',$groupe);
                                                    $g->execute();
                                                    $grps=array();
                                                    $j=0;
                                                    foreach($g as $result){
                                                        $grps[$j]=$result["id_groupe"];
                                                        $j++;
                                                    }

                                                    $m=$BDD->prepare("SELECT nom,prenom from moniteur where nom!=:nom and prenom!=:prenom");
                                                    $m->bindParam('nom',$nmoniteur);
                                                    $m->bindParam('prenom',$pmoniteur);
                                                    $m->execute();

                                                    $mn=array();
                                                    $k=0;
                                                    foreach($m as $result){
                                                        $mn[$k]=$result['nom'];
                                                        $k++;
                                                        $mn[$k]=$result['prenom'];
                                                        $k++;
                                                    }

                                                    echo'
                                                    <input type="hidden"  name="dateA" class="form-control ina3" value="'.implode(",",$ens_heures).'" >
                                                    <input type="hidden"  name="dateA" class="form-control ina8" value="'.implode(",",$grps).'" >
                                                    <input type="hidden"  name="dateA" class="form-control ina10" value="'.implode(",",$mn).'" >
                                                    <input type="hidden"  name="heureA" class="form-control ina4" value="'.$groupe.'" >
                                                    <input type="hidden"  name="prenomA" class="form-control ina5" value="'.$nmoniteur.'" >
            
                                                
                                                    <div class="modal" id="myModal">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Modifier les informations de la séance</h5>
                                                                    <button type="button" class="btn-close bt1" data-bs-dismiss="modal">x</button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="mb-3">
                    
                                                                        <input type="hidden" id="i1" name="id" class="form-control in" required   >
                                                                    </div>

                                                                    <div class="mb-3">
                                                                        <label class="form-label required">Date</label>
                                                                        <input type="date" name="date" class="form-control in" required  >
                                                                    </div>

                                                                    <div class="mb-3">
                                                                        <label class="form-label required">Heure</label>
                                                                        <select name="heure" class="form-control in " required >
                                                                        
                                                                        <option class="options"></option>
                                                                        </select>
                                                                        <!--<input type="text" name="prenom" class="form-control in " required >-->
                                                                    </div>
                                                                    
                                                                    <div class="mb-3">
                                                                        <label class="form-label required">Groupe</label>
                                                                        <select id="grp" name="groupe" class="in" required> 
                                                                        </select>
                                                                    </div>

                                                                    <div class="mb-3">
                                                                        <label class="form-label required">Moniteur</label>
                                                                        <select id="grp" name="moniteur" class="in" required> 
                                                                        </select>
                                                                    </div>

                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="submit" class="btn btn-primary btn2" name="confirmer">confirmer</button>
                                                                    <button type="submit" class="btn btn-danger">Cancel</button>              
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>   
                                                </form>
                                            </div>
                                        </td>
                                    </th>
        
                                </tr>
                            </tbody>
                                        ';           
            }
            echo ' 
                        </table>
                        <script src="main.js"></script>
                        <script src="../../javascript/planning.js"></script>
                        <script src="../../javascript/jquery.min.js"></script>
                        <script src="../../javascript/popper.min.js"></script>
                        <script src="../../javascript/bootstrap.min.js"></script>
                        <script src="../../javascript/bootstrap.bundle.min.js"></script>
                        <script src="../../javascript/select2.min.js"></script> 
                        <script>
                            $("#heure").select2({
                                minimumResultsForSearch: -1,
                                placeholder:"Heure",
                                allowClear: true
                            })

                            $("#groupe_aj").select2({
                                minimumResultsForSearch: -1,
                                placeholder:"Groupe",
                                allowClear: true
                            })

                            $("#moniteur_aj").select2({
                                placeholder:"Moniteur",
                                allowClear: true
                            })

                            $(document).ready(function(){
                                $("#date_aj").change(function(){
                                    var dateSel = $("#date_aj").val();
                                    $.ajax({
                                        type: "post",
                                        data: {jour: dateSel},
                                        success: function(response1){
                                            $("#heure").html(response1);
                                        }   
                                    });      
                                }); 
                            
                                $("#heure").change(function(){
                                    var heureSel = $("#heure").val();
                                    var dateSel = $("#date_aj").val();
                                    $.ajax({
                                        type: "post",
                                        data: {date:dateSel,h: heureSel},
                                        success: function(response2,response3){
                                            $("#groupe_aj").html(response2);
                                        }
                                    });
                                }); 

                                $("#groupe_aj").change(function(){
                                    var heureSel = $("#heure").val();
                                    var dateSel = $("#date_aj").val();
                                    $.ajax({
                                        type: "post",
                                        data: {date2:dateSel,h2: heureSel},
                                        success: function(response3){
                                            $("#moniteur_aj").html(response3);
                                        }
                                    });
                                }); 
                            });              
                        </script>';
        if(isset($_POST["ajouter2"])){
            if(isset($_POST['date']) && isset($_POST['heure']) && isset($_POST['groupe']) && isset($_POST['moniteur'])){
                ini_set('display_errors',1);
                error_reporting(E_ALL);
                $date=$_POST['date'];
                $heure=$_POST['heure'];
                $groupe=$_POST['groupe'];
                $moniteur=explode(" ",$_POST['moniteur']);
                $id_moniteur=$BDD->prepare("SELECT id_moniteur FROM moniteur where nom=:nom and prenom=:prenom");
                $id_moniteur->bindParam('nom',$moniteur[0]);
                $id_moniteur->bindParam('prenom',$moniteur[1]);
                $id_moniteur->execute();
                foreach($id_moniteur as $result){
                    $id_m=$result['id_moniteur'];
                }

                $nbr_id=$BDD->prepare("SELECT COUNT(id_seance) as m FROM cours_code");
                $nbr_id->execute();
                $nb=$nbr_id->fetchObject();
                if($nb==0){
                    $nouvel_id=1;
                }
                else{
                    $max_id=$BDD->prepare("SELECT max(id_seance) as max FROM cours_code");
                    $max_id->execute();
                    foreach($max_id as $result2){
                        $nouvel_id=$result2['max']+1;
                    }
                }
                $seance=$BDD->prepare("INSERT INTO cours_code VALUES(:id,:dat,:heure,:moniteur,:groupe)");
                $seance->bindParam('id',$nouvel_id);
                $seance->bindParam('dat',$date);
                $seance->bindParam('heure',$heure);
                $seance->bindParam('moniteur',$id_m);
                $seance->bindParam('groupe',$groupe);
                $seance->execute();
                header("location: code.php",true);
            }
        }
        if(isset($_POST['confirmer'])){
            if(isset($_POST['id']) && isset($_POST['date']) && isset($_POST['heure']) &&  isset($_POST['groupe']) && isset($_POST['moniteur'])){
                ini_set('display_errors',1);
                error_reporting(E_ALL);
                $id=$_POST['id'];
                $date=$_POST['date'];
                $heure=$_POST['heure'];
                $moniteur=$_POST['moniteur'];
                $id_groupe=$_POST['groupe'];
                $moniteur_arr=explode(" ",$moniteur);
                $id_moniteur=$BDD->prepare("SELECT id_moniteur from moniteur where nom=:nom and prenom=:prenom");
                $id_moniteur->bindParam("nom",$moniteur_arr[0]);
                $id_moniteur->bindParam("prenom",$moniteur_arr[1]);
                $id_moniteur->execute();
                $m=$id_moniteur->fetchObject();
                $modif=$BDD->prepare("UPDATE cours_code c SET  c.date=:dat , c.heure=:heure , c.id_moniteur=:moniteur , c.id_groupe=:groupe where   c.id_seance=:id  ");
                $modif->bindParam('id',$id);
                $modif->bindParam('dat',$date);
                $modif->bindParam('heure',$heure);
                $modif->bindParam('moniteur',$m->id_moniteur);
                $modif->bindParam('groupe',$id_groupe);
                $modif->execute();
                header("location: code.php",true);
            }
        }
        ob_end_flush();
    }
?>