<?php

use LDAP\Result;

ob_start();
    session_start();
    if(!isset($_SESSION['nom'])){
        header("location:../../connexion.php",true);
    }
    else{
        require_once "../connexionBDD.php";
        /*$username="user1";
        $passeword="user1";
        $BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);*/
        echo '<!DOCTYPE html>
            <head>
                <link rel="stylesheet" href="../../css/eleve-bootstrap.min.css">
                <link rel="stylesheet" href="../../css/admin2.css">
                <title>Interface d administration</title>
            
            </head>
            <body>
                <div class="posP">
                    <div class="posF nav-item dropdown">
                        <a href="#" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action">
                            <img src="../image/person.svg" class="person">
                            <b> Secrétaire</b>
                        </a>
                        <div class="dropdown-menu">
                            <a href="../profile.php" class="dropdown-item"> <img src="../image/person-gear.svg" /> <i class="fa fa-user-o"></i> Profile</a>
                            <div class="divider dropdown-divider"></div>
                            <a href="../deconnexion.php" class="dropdown-item"><i class="material-icons"><img src="../image/box-arrow-right.svg" /></i> Déconnexion</a>
                        </div>
                    </div>
                </div>
                <span id="toggler"  ><img onclick="toggleModal2()" src="../image/hamburger_menu_navbar_options_icon_196495.svg"></span>
                <div class="side-menu fermer">
                    <div class="brand-name">
                        <h1>Brand</h1>
                    </div>
                    <ul>
                        <a href="compte.php"><img src="../image/school.png">&nbsp;Compte</a>
                        <a href="groupe.php"><img src="../image/reading-book (1).png">&nbsp;Groupes</a>
                        <a href="index.php"><img src="../image/reading-book (1).png">&nbsp;Eleve</a>
                        <a href="moniteur.php"><img src="../image/teacher2.png">&nbsp;Moniteur</a>
                        <a href="vehicule.php"><img src="../image/car2.png  ">&nbsp;Vehicules</a>
                        <div id="planning">
                            <a href="#"><img src="../image/school.png">&nbsp;Planning</a>
                            <a class="seance" href="code.php"><img src="../image/school.png">&nbsp;Planning cours de code</a>
                            <a class="seance" href="conduite.php"><img src="../image/school.png">&nbsp;Planning lecons de conduite</a>
                        </div>
                        <a href="examen.php"><img src="../image/school.png">&nbsp;Examens</a>
                        <div id="paiement">
                            <a href="#"><img src="../image/payment.png">&nbsp;Paiment</a>
                            <a class="gestion_paiement" href="paiement_forfaitaire.php">&nbsp;Paiement Forfaitaire</a>
                            <a class="gestion_paiement" href="payement.php">&nbsp;Paiement Échelonné</a>
                        </div>
                        <a href="attestation.php"><img src="../image/school.png">&nbsp;Nouveaux conducteurs</a>
                        <a href="recipice.php"><img src="../image/school.png">&nbsp;Recipise de paiment</a>
                    </ul>
                </div>

               
                <div class="container1">
                    <p class="titre">Gestion des Eleves</p>
                    <button onclick="toggleModal()" class="ajouter bt" name="ajouter">Ajouter</button> 
                    <div class="modal1" id="user-modal">
                        <div class="modal1-header">
                            <h2>Ajouter un Eleve</h2>   
                        </div>

                        <form  id="user-form-1"  >
                            <div class="form-group position-relative">
                                <label class="required" for="nom_aj" class="form-label">Nom </label>
                                <input type="text" class="form-control " id="nom_aj" name="nom" required <i class="fa fa-times" id="verif_icone"></i> 
                                <div class="valid-feedback feedback-icone ">
                                    <i class="verif_icone fa fa-check"> </i>
                                </div>
                                <span id="error_nom"></span>
                            </div>
                        

                        <div class="form-group position-relative">
                            <label class="required" for="prenom">Prénom </label>
                            <input  type="text" id="prenom_aj" class="form-control " name="prenom" required>
                            <div class="valid-feedback feedback-icon">
                                <i class="verif_icone" class="fa fa-check"></i>
                            </div>
                            <span id="error_prenom"></span>
                        </div>
                        <div class="form-group position-relative">
                            <label class="required" for="date_naissance">Date de naissance </label>
                            <input type="date" id="date_naissance_aj" name="date_naissance"  class="form-control" required>
                            <span id="error_date_naissance"></span>
                        </div>
                        <div class="form-group position-relative">
                            <label class="required" for="nationalite" >Nationalité </label>
                            <input type="text" id="nationalite_aj" class="form-control " name="nationalite_aj" required>
                            <div class="valid-feedback feedback-icon">
                                <i class="verif_icone" class="fa fa-check"></i>
                            </div>
                            <span id="error_nationalite"></span>
                        </div>
                        <label class="required" for="Adresse">Adresse </label>

                        <input type="text" id="adresse_aj" name="adresse_aj" required>
                        <div class="form-group position-relative">
                            <label class="required"class="required" for="telephone">telephone </label>
                            <div class="input-group">
                                <span class="input-group-text" id="inputGroupPrepend2">0</span><input type="tel" class="form-control" id="telephone_aj" name="telephone_aj" max="10" required>
                            </div>
                            
                            <div class="valid-feedback feedback-icone ">
                                <i class="verif_icone fa fa-check"> </i>
                            </div>
                            <span id="error-Tel" ></span>
                        </div>
                        
                        <label  class="required" for="categoriePermis">Catégorie de permis </label>
                        <select id="categoriePermis_aj" name="categoriePermis" required>
                            <option value="">Sélectionnez une catégorie</option>
                            <option value="A">A</option>
                            <option value="B">B</option>
                            <option value="C">C</option>
                            <option value="D">D</option>
                            <option value="E">E</option>
                        </select>

                        <label class="required" for="groupe">Groupe </label>
                        <select id="groupe_aj" name="groupe" required>
                        <option value="">choisir un groupe</option>
                        ';
                        $groupe=$BDD->prepare("SELECT id_groupe from groupe");
                        $groupe->execute();
                        foreach($groupe as $result){
                            echo' <option value='. $result["id_groupe"].'>'.$result["id_groupe"].'</option>';
                        }
                        echo'      
                            </select>
                            <label class="required" label for="type">Type de paiement </label>
                            <select id="type_paiement_aj" name="type_paiement" required>
                                <option value="A">choisir un type</option>
                                <option value="Forfaitaire" >Forfaitaire</option>
                                <option value="Échelonné">Échelonné</option>
                            </select>
                            <label for="somme" id="somme" style="display:none">Somme:</label>
                            <input type="text" id="somme_aj" style="display:none" name="somme"/>
                            <input type="submit"  value="Suivant" >
                            <button class="modal1-close" onclick="toggleModal()">Fermer</button>
            
                        </form>
                        
                    <form style="display: none;" id="user-form-2" method="POST" >
                       <!-- <div  >-->
                            <div  class="form-group position-relative">
                                <label class="required" for="Identifiant">N de carte nationale d identite </label>
                                <input type="number" id="Identifiant" name="Identifiant" class="form-control" required>
                                <span id="error_identifiant"> </span>
                            </div>
                            
                            <div  class="form-group position-relative">
                                <label class="required" for="Mot de passe">Mot de passe  </label>
                                <input type="password" id="Mot de passe" name="mot_passe" class="form-control" required>
                                <span id="error_mot_passe"></span>
                            </div>


                          

                            <div  class="form-group position-relative">
                                <label class="required" for="Mot de passe2">Confirmer le mot de passe  </label>
                                <input type="password" id="Mot de passe2" name="mot_passe" class="form-control" required>
                                <span id="error_mot_passe2"></span>
                            </div>

                            <div  class="form-group position-relative">
                                <label class="required" for="adresseMail">Adresse mail de recuperation </label>
                                <input type="email" id="adresseMail" name="adrMail" required>
                                <span id="error_adresse_mail"></span>
                            </div>

                            <div>
                                <input type="button" class="btn" value="Précédent" onclick="showForm1()">
                                <input type="hidden" name="hide" id="in_hide">
                                <input type="submit" name="en" value="Enregistrer">
                            </div>
                        <!-- </div>-->
                    </form>
                </div>
            </div>

                                
                        
                <div class="container">
                    <div class="search-container">
                        <form method="POST" id="rechercher" >
                            <input type="text" placeholder="Recherche..." name="search">
                            <form method="POST"><button type="submit" name="recherche"  >Rechercher</button></form>
                        </form>
                    </div>
                    <table class="table " id="masque">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">nom</th>
                                <th scope="col">prénom</th>
                                <th scope="col">groupe</th>
                                <th scope="col">Téléphone</th>
                                <th scope="col">date_naissance</th>
                                <th scope="col">nationalité</th>
                                <th scope="col">adresse</th>
                                <th scope="col">catégorie permis demandée</th>
                                <th scope="col">action</th>
                            </tr>
                        </thead>

                        <tbody>';
                            if(isset($_POST["recherche"])){
                                if(!empty($_POST["search"])){
                                    ini_set('display_errors',1);
                                    error_reporting(E_ALL);
                                    $e=$_POST["search"];
                                    $p=strpos($e," ");
                                    if($p===FALSE){
                                        $eleves=$BDD->prepare("SELECT * from eleves where existe=1 and nom LIKE '%$e%' or prenom LIKE '%$e%' ");
                                        $eleves->execute();
                                    }
                                    else{
                                        $m=explode(" ",$e);
                                        $eleves=$BDD->prepare("SELECT * from eleves where existe=1 and (nom LIKE '%$m[0]%' and prenom  LIKE '%$m[1]%') or (nom LIKE '%$m[1]%' and prenom LIKE '%$m[0]%') ");
                                        $eleves->execute();
                                    }
                                }
                                
                            }
                            else{
                                $eleves=$BDD->prepare("SELECT * FROM eleves where existe=1 ORDER BY id_eleve DESC ");
                                $eleves->execute();
                            }
                            foreach($eleves AS $result){
                                $id=$result["id_eleve"];
                                $nom=$result["nom"];
                                $prenom=$result["prenom"];
                                $groupe=$result["groupe"];
                                $telephone=$result["telephone"];
                                $date_naissance=$result["date_naissance"];
                                $nationalite=$result["nationalite"];
                                $adresse=$result["adresse"];
                                $catégorie_permis_demandee=$result["catégorie_permis_demandee"];
                                $t='eleve';
                                echo ' <tr>
                                            <th class="th1" scope="row">'.$id.'</th>
                                                <td class="td1">'.$nom.'</td>
                                                <td>'.$prenom.'</td>
                                                <td>'.$groupe.'</td>
                                                <td> 0'.$telephone.'</td> 
                                                <td>'.$date_naissance.'</td>
                                                <td>'.$nationalite.'</td>
                                                <td>'.$adresse.'</td>
                                                <td>'.$catégorie_permis_demandee.'</td>
                                                <td><button class="btn btn-danger"><a class="text-light" href="../supprimer.php? supp='.$id.'&type='.$t.'" >archiver</a></button></td>
                                                <td> 
                                                    <div class="container ">
                                                        <button  class="btn btn-primary btn1" data-bs-toggle="modal" data-bs-target="#myModal" name="modifier">modifier</button>
                                                        <form method="POST">
                                                            <input type="hidden"  name="idA" class="form-control ina1" value="'.$id.'" >
                                                            <input type="hidden"  name="nomA" class="form-control ina2" value="'.$nom.'" >
                                                            <input type="hidden"  name="prenomA" class="form-control ina3" value="'.$prenom.'" >
                                                            <input type="hidden"  name="prenomA" class="form-control ina9" value="'.$groupe.'" >
                                                            <input type="hidden"  name="prenomA" class="form-control ina8" value="'.$telephone.'" >
                                                            <input type="hidden"  name="date_naissanceA" class="form-control ina4" value="'.$date_naissance.'" >
                                                            <input type="hidden"  name="nationaliteA" class="form-control ina5" value="'.$nationalite.'" >
                                                            <input type="hidden"  name="adresseA" class="form-control ina6" value="'.$adresse.'" >
                                                            <input type="hidden"  name="catégorie_permis_demandeeA" class="form-control ina7" value="'.$catégorie_permis_demandee.'" >
                                                            <div class="modal" id="myModal">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title">Modifier les informations de l éléve</h5>
                                                                            <button type="button" class="btn-close bt1" data-bs-dismiss="modal">x</button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <div class="mb-3">
                                                                                <!--<label class="form-label required">id</label>-->
                                                                                <input type="hidden" id="i1" name="id" class="form-control in" required   >
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required">Nom</label>
                                                                                <input type="text" name="nom" class="form-control in" required  >
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required">prénom</label>
                                                                                <input type="text" name="prenom" class="form-control in " required >
                                                                            </div>
                                                                            
                                                                            <div class="mb-3">
                                                                                <label class="form-label required">Groupe</label>
                                                                                <select id="grp" name="groupe" class="in" required> ';
        
                                                                                $groupes=$BDD->prepare("SELECT id_groupe from groupe");
                                                                                $groupes->execute();
                                                                                foreach($groupes as $result){
                                                                                    echo' <option value='. $result["id_groupe"].'>'.$result["id_groupe"].'</option>';
                                                                                }
                                                                                echo'      
                                                                                    </select>
                                        
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required">Téléphone</label>
                                                                                <input type="text" name="telephone" class="form-control in " required >
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required">Date de naissance</label>
                                                                                <input type="date" name="date_naissance" class="form-control in" required "></input>
                                                                            </div>

                                                                            <div class="mb-3 b">
                                                                                <label class="form-label required">Nationalité</label>
                                                                                <input type="text"  name="nationalite" class="form-control in" required "></input>
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required">adresse</label>
                                                                                <input type="text" name="adresse"  class="form-control in" required "></input>
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label required ">catégorie permis demandée</label>
                                                                                <input type="text" name="catégorie_permis_demandee" class="form-control in"></input>
                                                                            </div>
  
                                                                        </div>

                                                                        <div class="modal-footer">
                                                                            <button type="submit" class="btn btn-primary btn2" name="confirmer">confirmer</button>
                                                                            <button type="submit" class="btn btn-danger">Cancel</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </td>
                                            </th>

                                        </tr>
                        </tbody>
              ';
            }
            echo"</table>
                   
                    <script src='../../javascript/eleve-slim.min.js'></script>
                    <script src='../../javascript/eleve-popper.min.js'></script>
                    <script src='../../javascript/bootstrap.min.js' ></script>
                    <script src='../../javascript/bootstrap.bundle.min.js' ></script>
                    <script src='../../javascript/admin.js'></script> 
                </div> 
    </html>";

            if(isset($_POST["confirmer"])){
                error_reporting(E_ALL);
                ini_set('display_errors','On');
                $telephone=intval($_POST["telephone"]);
                $groupe=intval($_POST["groupe"]);
                $modif=$BDD->prepare("UPDATE eleves set nom=:nom ,prenom=:prenom,date_naissance=:date_naissance,nationalite=:nationalite,adresse=:adresse,catégorie_permis_demandee=:categorie_permis_demandee ,telephone=:telephone,groupe=:groupe where id_eleve=:id");
                $modif->bindParam("nom",$_POST["nom"]);
                $modif->bindParam("prenom",$_POST["prenom"]);
                $modif->bindParam("date_naissance",$_POST["date_naissance"]);
                $modif->bindParam("nationalite",$_POST["nationalite"]);
                $modif->bindParam("adresse",$_POST["adresse"]);
                $modif->bindParam("categorie_permis_demandee",$_POST["catégorie_permis_demandee"]);
                $modif->bindParam("telephone",$telephone);
                $modif->bindParam("groupe",$groupe);
                $modif->bindParam("id",$_POST["id"]);
                $modif->execute();
                header("location: index.php",true);
            }      
          
            if(isset($_POST["hide"])){
                ini_set('display_errors', 1);
                error_reporting(E_ALL);
                $n=json_decode($_POST["hide"]);
                $nbr=$BDD->prepare("SELECT count(id_eleve) as  m FROM eleves");
                $nbr->execute();
                $nb=$nbr->fetchObject();
                if($nb->m==0){
                    $id=1;
                }
                else{
                    $max_id=$BDD->prepare("SELECT max(id_eleve) as m FROM eleves");
                    $max_id->execute();
                    foreach($max_id AS $max){
                        $id=$max["m"]+1;
                    }
                }
                $telephone=intval($n->{'telephone'});
                $groupe=intval($n->{'groupe'});
                $eleve=$BDD->prepare('INSERT INTO eleves values(:id,:nom,:prenom,:date_naissance,:nationalite,:adresse,:categorie,:telephone,:groupe,1 )');
                $eleve->bindParam("id",$id);
                $eleve->bindParam("nom",$n->{'nom'});
                $eleve->bindParam("prenom",$n->{'prenom'});
                $eleve->bindParam("date_naissance",$n->{'date_naissance'});
                $eleve->bindParam("nationalite",$n->{'nationalite'});
                $eleve->bindParam("adresse",$n->{'adresse'});
                $eleve->bindParam("categorie",$n->{'categorie'});
                $eleve->bindParam("telephone",$telephone);
                $eleve->bindParam("groupe",$groupe);
                $eleve->execute();
                $type_utilisateur="eleve";
                $compte=$BDD->prepare('INSERT INTO compte values(:numero_utilisateur,:mot_passe,:type_utilisateur,NULL,:id_eleve,1,:adresse)');
                $compte->bindParam("numero_utilisateur",$_POST["Identifiant"]);
                $mot_de_passe=password_hash($_POST["mot_passe"],PASSWORD_DEFAULT);
                $compte->bindParam("mot_passe",$mot_de_passe);
                $compte->bindParam("type_utilisateur",$type_utilisateur);
                $compte->bindParam("id_eleve",$id);
                
                $compte->bindParam("adresse",$_POST["adrMail"]);
                $compte->execute();

                if($n->{'type_paiement'}=="Forfaitaire"){
                    ini_set('display_errors', 1);
                    error_reporting(E_ALL);
                    $max_id_p=$BDD->prepare("SELECT count(id_paiement) as m FROM paiement_forfaitaire");
                    $max_id_p->execute();
                    foreach($max_id_p AS $max){
                        $id_p=$max["m"]+1;
                    }
                    $paiement_f=$BDD->prepare("INSERT INTO paiement_forfaitaire values(:id_paiement,CURRENT_DATE(),:id_eleve,:somme)");
                    $paiement_f->bindParam("id_paiement",$id_p);
                    $paiement_f->bindParam("id_eleve",$id);
                    $paiement_f->bindParam("somme",$n->{'somme'});
                    $paiement_f->execute();
                    $_SESSION["somme"]= $n->{'somme'};
                    $_SESSION["type"]=$n->{'type_paiement'};
                    $_SESSION["date_paiement"]=date("Y-m-d");
                    $_SESSION["nom_etud"]=$n->{'nom'};
                    $_SESSION["prenom_etud"]=$n->{'prenom'};
                    $_SESSION["categorie"]=$n->{'categorie'};
                    header("location: recipisse.php",true);
                }
                else{
                    header("location: index.php",true);
                }    
            }
            ob_end_flush();
}
?>
   

