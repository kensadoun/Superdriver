<?php
ob_start();
session_start();
    if(!isset($_SESSION['nom'])){
        header("location:../../connexion.php",true);
    }
    else{
        require_once "../connexionBDD.php";
        /*$username="user1";
        $passeword="user1";
        $BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);*/
        if(isset($_POST['date']) && isset($_POST['h']) && isset($_POST['c']) && !isset($_POST['m'])){
            ini_set('display_errors',1);
            error_reporting(E_ALL);
            $date=$_POST['date'];
            $heure=$_POST['h'];
            $categorie=$_POST['c'];
            $moniteur=$BDD->prepare("SELECT m.nom as n,m.prenom as p FROM  moniteur m where m.categorie=:categorie and  m.en_fonction=1 and m.id_moniteur NOT IN(SELECT l.id_moniteur from lecons_conduite l where l.date=:jour and l.heure=:heure and l.categorie=:categorie)");
            $moniteur->bindParam('jour',$date);
            $moniteur->bindParam('heure',$heure);
            $moniteur->bindParam('categorie',$categorie);
            $moniteur->execute();
            echo'<option disabled selected></option>';
            foreach($moniteur as $result){
                echo'<option>'.$result['n'].' '.$result['p'].'</option>';
            }
            exit;
            
        }
        if(isset($_POST['date']) && isset($_POST['h']) && isset($_POST['c']) && isset($_POST['m']) && !isset($_POST['v'])){
            $date=$_POST['date'];
            $heure=$_POST['h'];
            $categorie=$_POST['c'];
            $moniteur=explode(" ",$_POST['m']);
            $vehicule=$BDD->prepare("SELECT v.matricule m from vehicule v where v.categorie=:categorie and v.matricule NOT IN(SELECT l.matricule from lecons_conduite l where l.date=:jour and l.heure=:heure and l.categorie=:categorie) ");
            $vehicule->bindParam('jour',$date);
            $vehicule->bindParam('heure',$heure);
            $vehicule->bindParam('categorie',$categorie);
            $vehicule->execute();
            echo'<option disabled selected>  </option>';
            foreach($vehicule as $result){
                echo'<option>'.$result['m'].'</option>';
            }
            exit;
        }
        if(isset($_POST['date']) && isset($_POST['h']) && isset($_POST['c']) && isset($_POST['m']) && isset($_POST['v']) && isset($_POST["type"])){
            ini_set('display_errors',1);
            error_reporting(E_ALL);
            $date=$_POST['date'];
            $heure=$_POST['h'];
            $categorie=$_POST['c'];
            $moniteur=explode(" ",$_POST['m']);
            $vehicule=$_POST['v'];
            $type=$_POST['type'];
            if($type=="créneau"){
                $eleve=$BDD->prepare("SELECT e.nom n ,e.prenom p from eleves e where e.catégorie_permis_demandee=:categorie and e.id_eleve NOT IN(SELECT l.id_eleve from lecons_conduite l where l.date=:jour and l.heure=:heure and l.categorie=:categorie) and e.id_eleve  IN(SELECT p.id_eleve from passer p ,examen exam where p.id_examen=exam.id_examen and exam.type='code' and p.etat=1 ) and e.id_eleve  NOT IN(SELECT pass.id_eleve from passer pass ,examen ex where pass.id_examen=ex.id_examen  and ex.type=:type and pass.etat=1 ) ;");
                $eleve->bindParam('jour',$date);
                $eleve->bindParam('heure',$heure);
                $eleve->bindParam('categorie',$categorie);
                $eleve->bindParam('type',$type);
                $eleve->execute();
            }
            elseif($type=="circulation"){
                $eleve=$BDD->prepare("SELECT e.nom n ,e.prenom p from eleves e where e.catégorie_permis_demandee=:categorie and e.id_eleve NOT IN(SELECT l.id_eleve from lecons_conduite l where l.date=:jour and l.heure=:heure and l.categorie=:categorie) and e.id_eleve  IN(SELECT p.id_eleve from passer p ,examen exam where p.id_examen=exam.id_examen and exam.type='code' and p.etat=1 ) and e.id_eleve  IN(SELECT pass.id_eleve from passer pass ,examen ex where pass.id_examen=ex.id_examen  and ex.type='créneau' and pass.etat=1 ) and e.id_eleve  NOT IN(SELECT pass.id_eleve from passer pass ,examen ex where pass.id_examen=ex.id_examen  and ex.type='circulation' and pass.etat=1 ) ;");
                $eleve->bindParam('jour',$date);
                $eleve->bindParam('heure',$heure);
                $eleve->bindParam('categorie',$categorie);
                $eleve->execute();

            }
            echo'<option disabled selected>  </option>';
            foreach($eleve as $result){
                echo'<option>'.$result['n'].' '.$result['p'].'</option>';
            }
            exit;
        }
        echo'
            <!DOCTYPE html>
            <html>
                <head>
                    <meta charset="utf-8">
                    <meta http-equiv="X-UA-Compatible" content="IE=edge">
                    <title>Page Title</title>
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <link rel="stylesheet" href="../../css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
                    <link href="../../css/select2.min.css" rel="stylesheet" />
                    <link rel="stylesheet" type="text/css" media="screen" href="../../css/admin2.css">                  
                </head>
                <body>
                    <div class="posP">
                        <div class="posF nav-item dropdown">
                            <a href="#" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action">
                                <img src="../image/person.svg" class="person">
                                <b> Secrétaire</b>
                            </a>
                            <div class="dropdown-menu">
                                <a href="../profile.php" class="dropdown-item"> <img src="../image/person-gear.svg" /> <i class="fa fa-user-o"></i> Profile</a>
                                <div class="divider dropdown-divider"></div>
                                <a href="../deconnexion.php" class="dropdown-item"><i class="material-icons"><img src="../image/box-arrow-right.svg" /></i> Déconnexion</a>
                            </div>
                        </div>
                    </div>
                    <span id="toggler"  ><img onclick="toggleModal2()" src="../image/hamburger_menu_navbar_options_icon_196495.svg"></span>

                    <div class="side-menu fermer">
                        <div id="d" class="brand-name">
                            <h1>Brand</h1>
                        </div>
                        <ul>
                            <a href="compte.php"><img src="../image/school.png">&nbsp;Compte</a>
                            <a href="groupe.php"><img src="../image/reading-book (1).png">&nbsp;Groupes</a>
                            <a href="groupe.php"><img src="../image/reading-book (1).png">&nbsp;Groupes</a>
                            <a href="index.php"><img src="../image/reading-book (1).png">&nbsp;Eleve</a>
                            <a href="moniteur.php"><img src="../image/teacher2.png">&nbsp;Moniteur</a>
                            <a href="vehicule.php"><img src="../image/car2.png  ">&nbsp;Vehicules</a>
                            <div id="planning">
                                <a href="#"><img src="../image/school.png">&nbsp;Planning</a>
                                <a class="seance" href="code.php"><img src="../image/school.png">&nbsp;Planning cours de code</a>
                                <a class="seance" href="conduite.php"><img src="../image/school.png">&nbsp;Planning lecons de conduite</a>
                            </div>
                            <a href="examen.php"><img src="../image/school.png">&nbsp;Examens</a>
                            <div id="paiement">
                                <a href="#"><img src="../image/payment.png">&nbsp;Paiment</a>
                                <a class="gestion_paiement" href="paiement_forfaitaire.php">&nbsp;Paiement Forfaitaire</a>
                                <a class="gestion_paiement" href="payement.php">&nbsp;Paiement Échelonné</a>
                            </div>
                            <a href="attestation.php"><img src="../image/school.png">&nbsp;Nouveaux conducteurs</a>
                            <a href="recipice.php"><img src="../image/school.png">&nbsp;Recipise de paiment</a>
                        </ul>
                    </div>
                    <div class="container1">
                        <p class="titre">Gestion des plannings</p>
                        <button  onclick="toggleModal()" class="ajouter bt" name="ajouter">Ajouter</button>
                        <div class="modal1" id="user-modal">
                            <div class="modal1-header">
                                <h2>Ajouter une séance</h2>   
                            </div>
                            <form  method="POST"  >

                                <label for="type">Type de lecon de conduite :</label>
                                <select id="type_l" name="type" class="multiple-class" required> 
                                    <option disabled  selected></option>  
                                    <option>créneau</option>
                                    <option>circulation</option>
                                </select>
                                <label for="categorie">Catégorie :</label>
                                <select id="categorie_aj" name="categorie" class="multiple-select" required>  
                                    <option disabled selected></option>
                                    <option>A</option>
                                    <option>B</option>
                                    <option>C</option>
                                    <option>D</option>
                                    <option>E</option>
                                </select>
                                <label for="date">Date :</label>
                                <input type="date" id="date_aj" name="date" required>
                                <label for="essai">Heure :</label>
                                <select id="heure" name="heure" class="multiple-class" required> 
                                    <option disabled selected></option>
                                    <option>08:00:00 </option>
                                    <option>09:00:00 </option>
                                    <option>10:00:00</option>
                                    <option>11:00:00</option>
                                    <option>13:00:00</option>
                                    <option>14:00:00</option>
                                    <option>15:00:00</option>
                                </select>
                                <label for="moniteur">Moniteur :</label>
                                <select id="moniteur_aj" name="moniteur" class="multiple-class" required>   
                                </select>
                                <label for="vehicule">Véhicule :</label>
                                <select id="vehicule_aj" name="vehicule"  class="multiple-class" required>   
                                </select>
                                <label for="eleve">Eleve :</label>
                                <select id="eleve_aj" name="eleve" required>   
                                </select>
                                <div>
                                    <input type="submit"  value="Ajouter" name="ajouter2" /> 
                                    <button class="modal1-close" onclick="toggleModal()">Fermer</button>
                                    </div>
                            </form>
                        </div>
                    </div>
                    <div class="container">
                        <div class="search-container">
                            <form method="POST" id="rechercher" >
                                <input type="text" placeholder="Recherche..." name="search">
                                <form method="POST"><button type="submit" name="recherche"  >Rechercher</button></form>
                            </form>
                        </div>
                        <table class="table " id="masque">
                            <thead>
                                <tr>
                                    <th scope="col">Date</th>
                                    <th scope="col">Heure</th>
                                    <th scope="col">Type</th>
                                    <th scope="col">Eleve</th>
                                    <th scope="col">Moniteur</th>
                                    <th scope="col">Catégorie</th>
                                    <th scope="col">Matricule de vehicule</th>
                                    <th scope="col">Marque de vehicule</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                        ';

                        if(isset($_POST["recherche"])){
                            if(!empty($_POST["search"])){
                                $e=$_POST["search"];
                                $p=strpos($e," ");
                                if($p===FALSE){
                                    ini_set('display_errors',1);
                                     error_reporting(E_ALL);
                                    $conduite=$BDD->prepare("SELECT l.*,e.nom as ne, e.prenom as pe,m.nom as nm,m.prenom as pm ,v.marque as mv from lecons_conduite l,eleves e,moniteur m,vehicule v where l.id_moniteur=m.id_moniteur and l.id_eleve=e.id_eleve and l.matricule=v.matricule and (l.date LIKE '%$e%' or l.heure LIKE '%$e%' or e.nom LIKE '%$e%' or e.prenom LIKE '%$e%' or m.nom LIKE '%$e%' or m.prenom LIKE '%$e%') ORDER BY l.date DESC ,l.heure ASC ");
                                    $conduite->execute();
                                }
                                else{
                                    $m=explode(" ",$e);
                                    $conduite=$BDD->prepare("SELECT l.*,e.nom as ne,e.prenom as pe, m.nom as nm,m.prenom as pm ,v.marque as mv from lecons_conduite l,eleves e,moniteur m ,vehicule v where l.id_moniteur=m.id_moniteur and l.id_eleve=e.id_eleve and l.matricule=v.matricule and ((l.date LIKE '%$m[0]%' and l.heure  LIKE '%$m[1]%') or (l.date LIKE '%$m[1]%' and l.heure LIKE '%$m[0]%')) ORDER BY l.date DESC ,l.heure ASC ");
                                    $coduite->execute();
                                }
                            }
                        }
                        else{
                            ini_set('display_errors',1);
                            error_reporting(E_ALL);
                            $conduite=$BDD->prepare("SELECT l.*,e.nom as ne,e.prenom as pe, m.nom as nm,m.prenom as pm ,v.marque as mv FROM lecons_conduite l ,eleves e,moniteur m,vehicule v where l.id_moniteur=m.id_moniteur and l.id_eleve=e.id_eleve and l.matricule=v.matricule   ORDER BY l.date DESC ,l.heure ASC");
                            $conduite->execute();
                        }
                        foreach($conduite AS $result){
                            $id=$result["id_seance"];
                            $date=$result["date"];
                            $heure=$result["heure"];
                            $neleve=$result["ne"];
                            $peleve=$result["pe"];
                            $nmoniteur=$result["nm"];
                            $pmoniteur=$result["pm"];
                            $categorie=$result["categorie"];
                            $matricule=$result["matricule"];
                            $marque=$result["mv"];
                            $type=$result["type_lecon_conduite"];
                            $c="lecon_conduite";
                            echo '          
                                <tr>
                                    <th class="th1" scope="row">'.$date.'</th>
                                        <!--<td class="td1">'.$date.'</td>-->
                                        
                                        <td>'.$heure.'</td>
                                        <td>'.$type.'</td>
                                        <td>'.$neleve.' '.$peleve.'</td>
                                        <td>'.$nmoniteur.' '.$pmoniteur.'</td>
                                        <td>'.$categorie.'</td>
                                        <td>'.$matricule.'</td>
                                        <td>'.$marque.'</td>
                                        <td><button class="btn btn-danger"><a class="text-light" href="../supprimer.php? supp='.$id.'&type='.$c.' " >supprimer</a></button></td>';
                        }
                    echo'
                    </tbody>
                    </table>
                    <script src="../../javascript/planning.js"></script>
                    <script src="../../javascript/jquery.min.js"></script>
                    <script src="../../javascript/popper.min.js"></script>
                    <script src="../../javascript/bootstrap.min.js"></script>
                    <script src="../../javascript/bootstrap.bundle.min.js"></script>
                    <script src="../../javascript/select2.min.js"></script>
                    <script>
                            $("#categorie_aj").select2({
                                minimumResultsForSearch: -1,
                                placeholder:"catégorie",
                                allowClear: true
                            });

                            $("#heure").select2({
                                minimumResultsForSearch: -1,
                                placeholder: "Heure",
                                allowClear: true
                            });

                            $("#moniteur_aj").select2({
                                minimumResultsForSearch: -1,
                                placeholder: "Moniteur",
                                allowClear: true
                            });

                            $("#vehicule_aj").select2({
                                minimumResultsForSearch: -1,
                                placeholder: "Véhicule",
                                allowClear: true
                            });

                            $("#type_l").select2({
                                minimumResultsForSearch: -1,
                                placeholder: "Type de lecon",
                                allowClear: true
                            });

                            $("#eleve_aj").select2({
                                minimumResultsForSearch: -1,
                                placeholder: "Éléve",
                                allowClear: true
                            });

                            $(document).ready(function(){ 
                                $("#type_l").change(function(){
                                    var moniteurSel=$("#moniteur_aj").val();
                                    var heureSel = $("#heure").val();
                                    var dateSel = $("#date_aj").val();
                                    var categorie = $("#categorie_aj").val();
                                    var vehicule = $("#vehicule_aj").val();
                                    var typeL = $("#type_l").val();
                                    $.ajax({
                                        type: "post",
                                        data: {date:dateSel,h: heureSel,c: categorie,m: moniteurSel,v :vehicule,type:typeL},
                                        success: function(response2){
                                            $("#eleve_aj").html(response2);
                                        }
                                    });
                                });

                                $("#categorie_aj").change(function(){
                                    var heureSel = $("#heure").val();
                                    var dateSel = $("#date_aj").val();
                                    var categorie = $("#categorie_aj").val();
                                    $.ajax({
                                        type: "post",
                                        data: {date:dateSel,h: heureSel,c: categorie},
                                        success: function(response1){
                                            $("#moniteur_aj").html(response1);
                                        }
                                    });
                                });
                                $("#date_aj").change(function(){
                                    var heureSel = $("#heure").val();
                                    var dateSel = $("#date_aj").val();
                                    var categorie = $("#categorie_aj").val();
                                    $.ajax({
                                        type: "post",
                                        data: {date:dateSel,h: heureSel,c: categorie},
                                        success: function(response1){
                                            $("#moniteur_aj").html(response1);
                                        }
                                    });
                                }); 
                                $("#heure").change(function(){
                                    var heureSel = $("#heure").val();
                                    var dateSel = $("#date_aj").val();
                                    var categorie = $("#categorie_aj").val();
                                    $.ajax({
                                        type: "post",
                                        data: {date:dateSel,h: heureSel,c: categorie},
                                        success: function(response1){

                                            $("#moniteur_aj").html(response1);
                                        }
                                    });
                                }); 
                                $("#moniteur_aj").change(function(){
                                    var moniteurSel=$("#moniteur_aj").val();
                                    var heureSel = $("#heure").val();
                                    var dateSel = $("#date_aj").val();
                                    var categorie = $("#categorie_aj").val();
                                    $.ajax({
                                        type: "post",
                                        data: {date:dateSel,h: heureSel,c: categorie,m: moniteurSel},
                                        success: function(response2){
                                            $("#vehicule_aj").html(response2);
                                        }
                                    });
                                }); 
                                $("#vehicule_aj").change(function(){
                                    var moniteurSel=$("#moniteur_aj").val();
                                    var heureSel = $("#heure").val();
                                    var dateSel = $("#date_aj").val();
                                    var categorie = $("#categorie_aj").val();
                                    var vehicule = $("#vehicule_aj").val();
                                    var typeL = $("#type_l").val();
                                    $.ajax({
                                        type: "post",
                                        data: {date:dateSel,h: heureSel,c: categorie,m: moniteurSel,v :vehicule,type:typeL},
                                        success: function(response2){
                                            $("#eleve_aj").html(response2);
                                        }
                                    });
                                }); 
                 
                            });    
                        </script>
            </body>';

            if(isset($_POST['ajouter2'])){
                if(isset($_POST['categorie']) && isset($_POST['date']) && isset($_POST['heure']) && isset($_POST['moniteur']) && isset($_POST['vehicule']) && isset($_POST['eleve']) && isset($_POST['type'])){
                    ini_set('display_errors',1);
                    error_reporting(E_ALL);
                    $categorie=$_POST['categorie'];
                    $date=$_POST['date'];
                    $heure=$_POST['heure'];
                    $m=explode(" ",$_POST['moniteur']);
                    $vehicule=$_POST['vehicule'];
                    $type=$_POST['type'];
                    $el=explode(" ",$_POST['eleve']);
                    $eleve=$BDD->prepare("SELECT id_eleve FROM eleves where nom=:nom and prenom=:prenom");
                    $eleve->bindParam("nom",$el[0]);
                    $eleve->bindParam("prenom",$el[1]);
                    $eleve->execute();
                    $id_eleve=$eleve->fetchObject();
                    $moniteur=$BDD->prepare("SELECT id_moniteur FROM moniteur where nom=:nom and prenom=:prenom");
                    $moniteur->bindParam("nom",$m[0]);
                    $moniteur->bindParam("prenom",$m[1]);
                    $moniteur->execute();
                    $id_moniteur=$moniteur->fetchObject();
                    $nbr=$BDD->prepare("SELECT COUNT(id_seance) as m from lecons_conduite");
                    $nbr->execute();
                    $nb=$nbr->fetchObject();
                    if($nb->m>0){
                        $max_id_seance=1;
                    }
                    else{
                        $max_id=$max->fetchObject();
                        $max=$BDD->prepare("SELECT max(id_seance) as max from lecons_conduite");
                        $max->execute();
                        $max_id=$max->fetchObject();
                        $max_id_seance=$max_id->max+1;
                    }
                    $seance=$BDD->prepare("INSERT INTO lecons_conduite values(:id,:date,:heure,:categorie,:id_moniteur,:id_eleve,:matricule,:type)");
                    $seance->bindParam("id",$max_id_seance);
                    $seance->bindParam("date",$date);
                    $seance->bindParam("heure",$heure);
                    $seance->bindParam("categorie",$categorie);
                    $seance->bindParam("id_moniteur",$id_moniteur->id_moniteur);
                    $seance->bindParam("id_eleve",$id_eleve->id_eleve);
                    $seance->bindParam("matricule",$vehicule);
                    $seance->bindParam("type",$type);
                    $seance->execute();
                    header('location:conduite.php',true);
                }
            }
    }
?>