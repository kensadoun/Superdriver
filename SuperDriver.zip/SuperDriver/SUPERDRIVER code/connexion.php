<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title>Auto-ecole</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">

    
</head>
<header class="mainhead">
    <nav>
        <img src="logo.png" alt="Description de l'image" class="logo">
        <ul>
            <li><a href='index.php'class='ligne'>Accueil</a></li>
            <li><a href='code de la route.php'class='ligne'>Code de la route</a></li>
            <li><a href='type de permis.php'class='ligne'>type de permis</a></li>
            <li><a href='connexion.php' class="con">Connexion</a></li>
        </ul>
    </nav>
    
    
</header>
<body>
    <div class="box">

        <form method="post" class="formBloc" >

            <h3><strong>Identifiez-vous</h3>

            <div class="formGroupe">
                <label for="identifiant">Identifiant</label>
                <input type="text" id="identifiant" name="identifiant" required />
            </div>

            <div class="formGroupe">
                <label for="mdp">Mot de passe</label>
                <input type="password" id="mdp" name="mot_passe" required />
            </div>

            <div class="formGroupe">
                <input type="submit" value="Valider" class="buttonSub" name="connexion" />
                
            </div>
            <div class="formGroupe">
                <h3 ><a href="mot_passe_oublie.php" >mot de passe oublié ?</a></h3>               
            </div>
            

            

        </form>

    </div>
    <script src="javascript/script.js"></script>
</body>

<?php
session_start();
require_once "PHP/connexionBDD.php";
/*$username="user1";
$passeword="user1";
$BDD=new PDO("mysql:host=localhost;dbname=phpmyadmin;",$username,$passeword);*/
if(isset($_POST["connexion"])){
    
    $infos=$BDD->prepare("SELECT * FROM compte where numero_utilisateur=:identifiant  ");
    $infos->bindParam("identifiant",$_POST["identifiant"]);
    $infos->execute();
    if($infos->rowCount()==1){
        $user=$infos->fetchObject();
        $mot_de_passe=$_POST["mot_passe"];
        if(password_verify($mot_de_passe,$user->mot_de_passe)){
            $_SESSION['numero_utilisateur']=$user->numero_utilisateur;
            $_SESSION['mot_de_passe']=$_POST["mot_passe"];
            $_SESSION['adresse_recuperation']=$user->adresse_recuperation;
            if($user->type_utilisateur=='admin'){
                $_SESSION['nom']='nom_secritaire';
                $_SESSION['prenom']='prenom_secritaire';
                $_SESSION['type_utilisateur']="admin";
                header("location:PHP/secritaire/index.php",true);
            }
            elseif($user->type_utilisateur=='eleve'){
                $eleve=$BDD->prepare("SELECT e.id_eleve as id ,e.nom as nom ,e.prenom as prenom FROM eleves e ,compte c where e.id_eleve=c.id_eleve and c.mot_de_passe=:mot_passe");
                $eleve->bindParam("mot_passe",$user->mot_de_passe);
                $eleve->execute();
                $infos_eleve=$eleve->fetchObject();
                $_SESSION['id_eleve']=$infos_eleve->id;
                $_SESSION['nom']=$infos_eleve->nom;
                $_SESSION['prenom']=$infos_eleve->prenom;
                header("location: PHP/eleve/CONDIDAT.php",true);
            }
            elseif($user->type_utilisateur=='moniteur'){
                $moniteur=$BDD->prepare("SELECT m.nom,m.prenom FROM moniteur m ,compte c where  m.id_moniteur=c.id_moniteur and c.numero_utilisateur=:numero_utilisateur and c.mot_de_passe=:mot_passe  ");
                $moniteur->bindParam("numero_utilisateur",$user->numero_utilisateur);
                $moniteur->bindParam("mot_passe",$user->mot_de_passe);
                $infos_moniteur=$moniteur->fetchObject();
                $_SESSION['nom']=$infos_moniteur->nom;
                $_SESSION['prenom']=$infos_moniteur->prenom;
            }
        }
        else{
            echo "<h1>le numero_utilisateur  ou le mot de passe est incorrect</h1>";
        }
    }
}
?>
</html>