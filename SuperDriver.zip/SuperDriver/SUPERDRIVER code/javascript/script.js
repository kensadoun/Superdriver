document.querySelector('a[href="index.php"]').addEventListener('click', function(event) {
    event.preventDefault();
    document.body.style.opacity = 0;
    setTimeout(function() {
        location.href = 'index.php';
    }, 500);
});
document.querySelector('a[href="code de la route.php"]').addEventListener('click', function(event) {
    event.preventDefault();
    document.body.style.opacity = 0;
    setTimeout(function() {
        location.href = 'code de la route.php';
    }, 500);
});
document.querySelector('a[href="type de permis.php"]').addEventListener('click', function(event) {
    event.preventDefault();
    document.body.style.opacity = 0;
    setTimeout(function() {
        location.href = 'type de permis.php';
    }, 500);
});
document.querySelector('a[href="connexion.php"]').addEventListener('click', function(event) {
    event.preventDefault();
    document.body.style.opacity = 0;
    setTimeout(function() {
        location.href = 'connexion.php';
    }, 500);
});


const inputs = document.querySelectorAll('input');

        for (let i = 0; i < inputs.length; i++) {

            let field = inputs[i];

            field.addEventListener('input', (e) => {

                if(e.target.value != ""){
                    e.target.parentNode.classList.add('animation');
                } else if (e.target.value == "") {
                    e.target.parentNode.classList.remove('animation');
                }
            })
        }


    
 

        
const par3 = document.querySelector('.par3');


window.addEventListener('scroll', () => {
  const distanceFromTop = par3.getBoundingClientRect().top;

  
  if (distanceFromTop < window.innerHeight) {
   
    par3.classList.add('animate');
  } else {
    par3.classList.remove('animate');
  }
});


          
const par5 = document.querySelector('.par5');


window.addEventListener('scroll', () => {
  
  const distanceFromTop = par5.getBoundingClientRect().top;

 
  if (distanceFromTop < window.innerHeight) {
    
    par5.classList.add('animate');
  } else {
    
    par5.classList.remove('animate');
  }
});
          
          


      
