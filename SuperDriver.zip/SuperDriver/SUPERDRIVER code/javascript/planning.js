
const modal = document.getElementById("user-modal");
const ajouter = document.getElementById("user-form-1");
const search=document.getElementById("rechercher");
const tableau=document.getElementById("masque");
function toggleModal() {
    modal.classList.toggle("active");
    form1.style.display = "block";
    form1.reset();
}

function toggleModal2() {
    document.getElementsByClassName('side-menu')[0].classList.toggle("fermer");
}



let btns=document.querySelectorAll('.btn1');
let btns_arr=[...btns];
btns_arr.forEach((item)=>{
    item.addEventListener('click',()=>{
        document.getElementsByClassName('in')[0].value=document.getElementsByClassName('ina1')[btns_arr.indexOf(item)].value;
        document.getElementsByClassName('in')[1].value=document.getElementsByClassName('ina2')[btns_arr.indexOf(item)].value;

        var ins=document.getElementsByClassName('in');
        const opt=ins[2].getElementsByTagName("option");
        var long=opt.length;
        var j=0;
        while(j<long){
            ins[2].removeChild(opt[0]);
            j++;
        }
        var ina3=document.getElementsByClassName('ina3')[btns_arr.indexOf(item)].value;
        var ina6=document.getElementsByClassName('ina6')[btns_arr.indexOf(item)];
        var ina7=document.getElementsByClassName('ina7')[btns_arr.indexOf(item)];
        var option=document.createElement('option');
        option.classList.add("opt");
        option.innerHTML=ina6.value;
        ins[2].appendChild(option);
        var heures=ina3.split(",");
        var i=0;
        l=heures.length;
        while(i<l){
            var option=document.createElement('option');
            option.classList.add("opt");
            option.innerHTML=heures[i];
            ins[2].appendChild(option);
            i++;
        }

        const opt2=ins[3].getElementsByTagName("option");
        var long2=opt2.length;
        var j=0;
        while(j<long2){
            ins[3].removeChild(opt2[0]);
            j++;
        }

        var option=document.createElement('option');
        option.classList.add("grps");
        option.innerHTML=ina7.value;
        ins[3].appendChild(option);
        
        var groupes=document.getElementsByClassName('ina8')[btns_arr.indexOf(item)].value;
        var groupes_arr=groupes.split(",");
        var k=0;
        var len=groupes_arr.length;

        while(k<len){
            var option=document.createElement('option');
            option.classList.add("grps");
            option.innerHTML=groupes_arr[k];
            ins[3].appendChild(option);
            k++;
        }
        
        const opt3=ins[4].getElementsByTagName("option");
        var long3=opt3.length;
        var j=0;
        while(j<long3){
            ins[4].removeChild(opt3[0]);
            j++;
        }


        var ina9=document.getElementsByClassName('ina9')[btns_arr.indexOf(item)];
        var option=document.createElement('option');
        option.classList.add("mntr");
        option.innerHTML=ina9.value;
        ins[4].appendChild(option);

        var moniteurs=document.getElementsByClassName('ina10')[btns_arr.indexOf(item)].value;
        var moniteurs_arr=moniteurs.split(",");
        //alert("moniteurs_arr="+moniteurs_arr)
        var k=0;
        var longeur=moniteurs_arr.length;

        while(k<longeur){
            var option=document.createElement('option');
            option.classList.add("mntr");
            option.innerHTML=moniteurs_arr[k]+' '+moniteurs_arr[k+1];
            ins[4].appendChild(option);
            k=k+2;

        }

        //document.getElementsByClassName('in')[2].value=document.getElementsByClassName('ina3')[btns_arr.indexOf(item)].value;
        //var option=document.createElement('option');
        //document.getElementsByClassName('opt')[0].innerHTML=document.getElementsByClassName('ina3')[btns_arr.indexOf(item)].value;
        //document.getElementsByClassName('in')[2].appendChild(option)

    })
});

