
		const modal = document.getElementById("user-modal");
		const form1 = document.getElementById("user-form-1");
		const form2 = document.getElementById("user-form-2");
		const search=document.getElementById("rechercher");
		const tableau=document.getElementById("masque");
		const type_paiement=document.getElementById("type_paiement_aj");
		const somme=document.getElementById("somme_aj");
		const label_type=document.getElementById("somme")

		function toggleModal() {
			modal.classList.toggle("active");
			form1.style.display = "block";
			form2.style.display = "none";
			form1.reset();
			form2.reset();
		}

		function toggleModal2() {
			document.getElementsByClassName('side-menu')[0].classList.toggle("fermer");
		}

		function showForm1() {
			form2.style.display = "none";
			form1.style.display = "block";
		}

		type_paiement.addEventListener("change",()=>{
			if(type_paiement.value=="Forfaitaire"){
				label_type.display="block";
				somme.style.display="block";
				form1.style.display = "block";
			}
			else{
				label_type.style.display="none";
				somme.style.display="none";
			}
		})
		form1.addEventListener("submit", function(event) {
			event.preventDefault();
			if(verifierNom() && verifierPrenom() && verifierDateNaissance() && verifierNationalite()  && verifierTelephone()){
				form1.style.display = "none";
				form2.style.display = "block";
				let nom=String(document.getElementById("nom_aj").value);
				let prenom=String(document.getElementById("prenom_aj").value);
				let groupe=String(document.getElementById("groupe_aj").value);
				let date_naissance=String(document.getElementById("date_naissance_aj").value);
				let nationalite=String(document.getElementById("nationalite_aj").value);
				let adresse=String(document.getElementById("adresse_aj").value);
				let telephone=String(document.getElementById("telephone_aj").value);
				let categorie=String(document.getElementById("categoriePermis_aj").value);
				let type_paiement=String(document.getElementById("type_paiement_aj").value);
				if(document.getElementById("type_paiement_aj").value=="Forfaitaire"){
					var somme=String(document.getElementById("somme_aj").value);
					var text = '{ "nom":"'+nom+'", "prenom":"'+prenom+'","date_naissance":"'+date_naissance+'","nationalite":"'+nationalite+'","adresse":"'+adresse+'","categorie":"'+categorie+'","telephone":"'+telephone+'","groupe":"'+groupe+'","type_paiement":"'+type_paiement+'","somme":"'+somme+'"}';
				}
				else{
					var text = '{ "nom":"'+nom+'", "prenom":"'+prenom+'","date_naissance":"'+date_naissance+'","nationalite":"'+nationalite+'","adresse":"'+adresse+'","categorie":"'+categorie+'","telephone":"'+telephone+'","groupe":"'+groupe+'","type_paiement":"'+type_paiement+'"}';
				}
				document.getElementById("in_hide").value=text;
			}
		});

		form2.addEventListener("submit", function(event) {
			event.preventDefault();
			if(verifierMotPasse() && verifierEgaliteMotPasse() && verifierNumeroUtilisateur()){
				form2.submit();
				toggleModal();
			}			
		});



		let btns=document.querySelectorAll('.btn1');
		let btns_arr=[...btns];
		btns_arr.forEach((item)=>{
			item.addEventListener('click',()=>{
				document.getElementsByClassName('in')[0].value=document.getElementsByClassName('ina1')[btns_arr.indexOf(item)].value;
				document.getElementsByClassName('in')[1].value=document.getElementsByClassName('ina2')[btns_arr.indexOf(item)].value;
				document.getElementsByClassName('in')[2].value=document.getElementsByClassName('ina3')[btns_arr.indexOf(item)].value;
				document.getElementsByClassName('in')[3].value=document.getElementsByClassName('ina9')[btns_arr.indexOf(item)].value;
				document.getElementsByClassName('in')[4].value=document.getElementsByClassName('ina8')[btns_arr.indexOf(item)].value;
				document.getElementsByClassName('in')[5].value=document.getElementsByClassName('ina4')[btns_arr.indexOf(item)].value;
				document.getElementsByClassName('in')[6].value=document.getElementsByClassName('ina5')[btns_arr.indexOf(item)].value;
				document.getElementsByClassName('in')[7].value=document.getElementsByClassName('ina6')[btns_arr.indexOf(item)].value;
				document.getElementsByClassName('in')[8].value=document.getElementsByClassName('ina7')[btns_arr.indexOf(item)].value;
			})
		});
		const nom_aj=document.getElementById("nom_aj");
		const error_nom=document.getElementById("error_nom");

		const prenom_aj=document.getElementById("prenom_aj");
		const error_prenom=document.getElementById("error_prenom");

		const nationalite_aj=document.getElementById("nationalite_aj");
		const error_nationalite=document.getElementById("error_nationalite");

		const msg_nom=document.getElementById("msg_nom");
		const verif_icone=document.getElementsByTagName("i")[0];
		const telephone_aj=document.getElementById("telephone_aj");
		const error_tel=document.getElementById("error-Tel");
		const error_mot_passe=document.getElementById("error_mot_passe");
		const error_mot_passe2=document.getElementById("error_mot_passe2");
		nom_aj.addEventListener("keyup",()=>{
			var regex=/[^a-z]/gi;
			nom_aj.value=nom_aj.value.replace(regex,"")
			if(nom_aj.classList.contains("is-valid")){
				nom_aj.classList.remove("is-valid")
			}
			else {
				if(nom_aj.classList.contains("is-invalid")){
					nom_aj.classList.remove("is-invalid")
				}
			}

			if(nom_aj.value.length==1){
				nom_aj.classList.add("is-invalid")
				error_nom.innerHTML="Le nom est invalide !"
				error_nom.style.color="red"
			}

			else{
				nom_aj.classList.add("is-valid")
				error_nom.innerHTML="Le nom est invalide !"
				error_nom.style.color="green"
			}
	
		})

		function verifierNom(){
			var regex=/[^a-z]/gi;
			nom_aj.value=nom_aj.value.replace(regex,"")
			if(nom_aj.classList.contains("is-valid")){
				nom_aj.classList.remove("is-valid")
			}
			else {
				if(nom_aj.classList.contains("is-invalid")){
					nom_aj.classList.remove("is-invalid")
				}
			}

			if(nom_aj.value.length==1){
				nom_aj.classList.add("is-invalid")
				error_nom.style.color="red"
				error_nom.innerHTML="Nom invalide !"
				return false;
				
			}
			else{
				if(nom_aj.value.length<=0){
					nom_aj.classList.add("is-invalid")
					error_nom.style.color="red"
					error_nom.innerHTML="Veuillez saisir le nom !"
					return false;
				}
				else{
					nom_aj.classList.add("is-valid")
					error_nom.innerHTML="Le nom est valide !"
					error_nom.style.color="green"
					return true;
				}
			}
		}


		function verifierPrenom(){
			var regex=/[^a-z]/gi;
			prenom_aj.value=prenom_aj.value.replace(regex,"")
			if(prenom_aj.classList.contains("is-valid")){
				prenom_aj.classList.remove("is-valid")
			}
			else {
				if(prenom_aj.classList.contains("is-invalid")){
					prenom_aj.classList.remove("is-invalid")
				}
			}
			if(prenom_aj.value.length==1){
				error_prenom.innerHTML="Le prénom est invalide !"
				prenom_aj.classList.add("is-invalid")
				error_prenom.style.color="red"
				return false;
				
			}
			else{
				if(prenom_aj.value.length<=0){
					error_prenom.innerHTML="Veuillez saisir le prénom !"
					prenom_aj.classList.add("is-invalid")
					error_prenom.style.color="red"
					return false;
				}
				else{
					prenom_aj.classList.add("is-valid")
					error_prenom.innerHTML="Le prénom est valide !"
					error_prenom.style.color="green"
					return true;
				}
			}
		}

		nom_aj.addEventListener("blur",()=>{verifierNom()});


		prenom_aj.addEventListener("keyup",()=>{
			var regex=/[^a-z]/gi;
			prenom_aj.value=prenom_aj.value.replace(regex,"")
			if(prenom_aj.classList.contains("is-valid")){
				prenom_aj.classList.remove("is-valid")
			}
			else {
				if(prenom_aj.classList.contains("is-invalid")){
					prenom_aj.classList.remove("is-invalid")
				}
			}

			if(prenom_aj.value.length==1){
				prenom_aj.classList.add("is-invalid")
				error_prenom.innerHTML="Le prénom est invalide !"
				error_prenom.style.color="red"
			}

			else{
				prenom_aj.classList.add("is-valid")
				error_prenom.innerHTML="Le prénom est valide !"
				error_prenom.style.color="green"
			}
	
		})


		
		prenom_aj.addEventListener("blur",()=>{
			verifierPrenom();	
		})


		nationalite_aj.addEventListener("keyup",()=>{
			var regex=/[^a-z]/gi;
			nationalite_aj.value=nationalite_aj.value.replace(regex,"")
			if(nationalite_aj.classList.contains("is-valid")){
				nationalite_aj.classList.remove("is-valid")
			}
			else {
				if(nationalite_aj.classList.contains("is-invalid")){
					nationalite_aj.classList.remove("is-invalid")
				}
			}
			if(nationalite_aj.value.length==1){
				nationalite_aj.classList.add("is-invalid")
				error_nationalite.innerHTML="La nationalite est invalide !"
				error_nationalite.style.color="red"
			}
			else{
				nationalite_aj.classList.add("is-valid")
				error_nationalite.innerHTML="La nationalite est valide !"
				error_nationalite.style.color="green"
			}
		})

		function verifierNationalite(){
			var regex=/[^a-z]/gi;
			nationalite_aj.value=nationalite_aj.value.replace(regex,"")
			if(nationalite_aj.classList.contains("is-valid")){
				nationalite_aj.classList.remove("is-valid")
			}
			else {
				if(nationalite_aj.classList.contains("is-invalid")){
					nationalite_aj.classList.remove("is-invalid")
				}
			}
			if(nationalite_aj.value.length==1){
				nationalite_aj.classList.add("is-invalid")
				error_nationalite.style.color="red"
				error_nationalite.innerHTML="La nationalité est invalide !"
				return false;	
			}
			else{
				if(nationalite_aj.value.length<=0){
					nationalite_aj.classList.add("is-invalid")
					error_nationalite.style.color="red"
					error_nationalite.innerHTML="Veuillez saisir la nationalite !"
					return false;
				}
				else{
					nationalite_aj.classList.add("is-valid")
					error_nationalite.innerHTML="La nationalite est valide !"
					error_nom.style.color="green"
					return true;
				}
			}
		}
		nationalite_aj.addEventListener("blur",()=>{
			verifierNationalite();
			
		})

		telephone_aj.addEventListener("keyup",()=>{
			if(telephone_aj.classList.contains("is-valid")){
				telephone_aj.classList.remove("is-valid")
			}
			else {
				if(telephone_aj.classList.contains("is-invalid")){
					telephone_aj.classList.remove("is-invalid")
				}
			}

			telephone_aj.value=telephone_aj.value.trim();
			if(isNaN(telephone_aj.value)  || telephone_aj.value[0]=='0' || telephone_aj.value.length>9    ){
				telephone_aj.classList.add("is-invalid")
				if(isNaN(telephone_aj.value)  ){
					error_tel.innerHTML="le numero ne doit contenir que des chiffres!"
				}
				else{
					if(telephone_aj.value[0]=='0')
						error_tel.innerHTML="Le premier chiffre à saisir doit étre different de 0 !"
					else {
						error_tel.innerHTML="le numero contient plus de '10' chiffres !"
					}
				}
				error_tel.style.color="red";
				
			}
			else{
				telephone_aj.classList.remove("is-invalid")
				error_tel.innerHTML=""			
			}
		})

		function verifierTelephone(){
			if(!isNaN(telephone_aj.value) && telephone_aj.value[0]!='0' && telephone_aj.value.length==9){
				telephone_aj.classList.add("is-valid")
				error_tel.innerHTML="le numéro de téléphone est valide!"
				error_tel.style.color="green";
				return true
			}
			else{
				telephone_aj.classList.add("is-invalid")
				if(telephone_aj.value[0]=='0'){
					error_tel.innerHTML="Le premier chiffre à saisir doit étre different de 0 !"
				}
				else{
					error_tel.innerHTML="le numéro de téléphone est invalide!"
				}
				error_tel.style.color="red"
				return false

			}
		}
		const mot_passe=document.getElementById("Mot de passe");
		const mot_passe2=document.getElementById("Mot de passe2");
		telephone_aj.addEventListener("blur",()=>{
			verifierTelephone();
			
		})
	
		function verifierMotPasse(){
			if(mot_passe.classList.contains("is-valid")){
				mot_passe.classList.remove("is-valid")
			}
			else {
				if(mot_passe.classList.contains("is-invalid")){
					mot_passe.classList.remove("is-invalid")
				}
			}
			if(mot_passe.value.length<8  ){
				mot_passe.classList.add("is-invalid")
				error_mot_passe.innerHTML="le mot de passe doit contenir au moins 8 caracteres!";
				error_mot_passe.style.color="red";
				return false;
			}
			else{
				mot_passe.classList.add("is-valid")
				error_mot_passe.style.color="green";
				error_mot_passe.innerHTML="";
				return true;
				
			}
		}

		function verifierEgaliteMotPasse(){
			if(mot_passe2.classList.contains("is-valid")){
				mot_passe2.classList.remove("is-valid")
			}
			else {
				if(mot_passe2.classList.contains("is-invalid")){
					mot_passe2.classList.remove("is-invalid")
				}
			}
			if(mot_passe.value!=mot_passe2.value){
				mot_passe2.classList.add("is-invalid")
				error_mot_passe2.innerHTML="Veuillez retaper le mot de passe!";
				error_mot_passe2.style.color="red";
				return false;
			}
			else{
				mot_passe2.classList.add("is-valid")
				error_mot_passe2.style.color="green";
				error_mot_passe2.innerHTML="";
				return true;	
			}
		}

		mot_passe.addEventListener("keyup",()=>{
			verifierMotPasse();
		})


		mot_passe.addEventListener("blur",()=>{
		
			verifierMotPasse();
		})

		mot_passe2.addEventListener("keyup",()=>{
			verifierEgaliteMotPasse()
		})


		mot_passe2.addEventListener("blur",()=>{
			verifierEgaliteMotPasse()
		})

		const date_naissance2=document.getElementById("date_naissance_aj");
		const error_date_naissance=document.getElementById("error_date_naissance");

		function verifierDateNaissance(){
			const date=new Date();
			const annee=date.getFullYear()
			let date_naissance=String(document.getElementById("date_naissance_aj").value)
			const naissance=new Date(date_naissance)
			const annee_naissance=naissance.getFullYear();			
			if(document.getElementById("date_naissance_aj").classList.contains("is-valid")){
				document.getElementById("date_naissance_aj").classList.remove("is-valid")
			}
			else {
				if(document.getElementById("date_naissance_aj").classList.contains("is-invalid")){
					document.getElementById("date_naissance_aj").classList.remove("is-invalid")
				}
			}
			if((annee-annee_naissance)<17){
				document.getElementById("date_naissance_aj").classList.add("is-invalid")
				document.getElementById("error_date_naissance").innerHTML="l'éléve à moins de 17 ans";
				document.getElementById("error_date_naissance").style.color="red";
				return false;
			}
			else{
				document.getElementById("date_naissance_aj").classList.add("is-valid")
				document.getElementById("error_date_naissance").innerHTML="La date est valide"
				document.getElementById("error_date_naissance").style.color="green";
				return true;
			}
		}

		const NumeroUtilisateur=document.getElementById("Identifiant");
		const error_identifiant=document.getElementById("error_identifiant");
		NumeroUtilisateur.addEventListener("keydown",(e)=>{
			var lettres = /[a-zA-Z]/;			
			if(lettres.test(NumeroUtilisateur.value)){
				e.preventDefault();
			}
		})

		function verifierNumeroUtilisateur(){
					
			if(NumeroUtilisateur.classList.contains("is-valid")){
				NumeroUtilisateur.classList.remove("is-valid")
			}
			else {
				if(NumeroUtilisateur.classList.contains("is-invalid")){
					NumeroUtilisateur.classList.remove("is-invalid")
				}
			}

			if(NumeroUtilisateur.value.length==0){
				NumeroUtilisateur.classList.add("is-invalid")
				error_identifiant.innerHTML="Veuillez saisir remplir ce champs !";
				error_identifiant.style.color="red";
				return false;
			}

			else{
				NumeroUtilisateur.classList.add("is-valid")
				error_identifiant.innerHTML="Le numero d'utilisateur est valide";
				error_identifiant.style.color="green";
				return true;
			}
		}


		NumeroUtilisateur.addEventListener("blur",()=>{
			verifierNumeroUtilisateur()
		})
	