const modal = document.getElementById("user-modal");
		const form1 = document.getElementById("user-form-1");
		const form2 = document.getElementById("user-form-2");
		const search=document.getElementById("rechercher");
		const tableau=document.getElementById("masque");
		function toggleModal() {
			modal.classList.toggle("active");
			form1.style.display = "block";
			form2.style.display = "none";
			form1.reset();
			form2.reset();
		}

        function toggleModal2() {
			document.getElementsByClassName('side-menu')[0].classList.toggle("fermer");
		}

		function showForm1() {
			form2.style.display = "none";
			form1.style.display = "block";
		}
		form1.addEventListener("submit", function(event) {
            event.preventDefault();
            if(verifierNom() && verifierPrenom() && verifierTelephone()){ 
			    form1.style.display = "none";
			    form2.style.display = "block";
			    let nom=String(document.getElementById("nom_aj").value);
			    let prenom=String(document.getElementById("prenom_aj").value);
			    let adresse=String(document.getElementById("adresse_aj").value);
			    let telephone=String(document.getElementById("telephone_aj").value);
                let type_lecon=String(document.getElementById("type_lecon").value);
                if(type_lecon=='Pratique'  || type_lecon=='Théorique et Pratique'){
			        let categorie=String(document.getElementById("categoriePermis_aj").value);
                    var text = '{ "nom":"'+nom+'", "prenom":"'+prenom+'","adresse":"'+adresse+'","categorie":"'+categorie+'","telephone":"'+telephone+'","type_lecon":"'+type_lecon+'"}'
                }
                else{
                    var text = '{ "nom":"'+nom+'", "prenom":"'+prenom+'","adresse":"'+adresse+'","telephone":"'+telephone+'","type_lecon":"'+type_lecon+'"}'
                }
			    document.getElementById("in_hide").value=text;
            }
		});

		form2.addEventListener("submit", function(event) {
			event.preventDefault();
            if(verifierMotPasse() && verifierEgaliteMotPasse() && verifierNumeroUtilisateur()){
			// Ajouter le code pour traiter le formulaire ici
                form2.submit();
			    toggleModal();

            }
		});

        var type_lecon=document.getElementById('type_lecon');
        var categorie=document.getElementById('categoriePermis_aj');
        var labelC=document.getElementById('label_c');
        type_lecon.addEventListener('change',()=>{
            if(type_lecon.value=='Pratique'  || type_lecon.value=='Théorique et Pratique'){
                categorie.hidden=false;
                labelC.style.display='flex';
                categorie.setAttribute('hidden')
                categorie.setAttribute('required')
            }
            else{
                labelC.style.display='none';
                categorie.hidden=true;
            }

        })

        let btns=document.querySelectorAll('.btn1');
		let btns_arr=[...btns];
		btns_arr.forEach((item)=>{
			item.addEventListener('click',()=>{
                document.getElementsByClassName('in')[0].value=document.getElementsByClassName('ina1')[btns_arr.indexOf(item)].value;
				document.getElementsByClassName('in')[1].value=document.getElementsByClassName('ina2')[btns_arr.indexOf(item)].value;
				document.getElementsByClassName('in')[2].value=document.getElementsByClassName('ina3')[btns_arr.indexOf(item)].value;
				document.getElementsByClassName('in')[3].value=document.getElementsByClassName('ina4')[btns_arr.indexOf(item)].value;
				document.getElementsByClassName('in')[4].value=document.getElementsByClassName('ina5')[btns_arr.indexOf(item)].value;
                var ins=document.getElementsByClassName('in');
                const opt1=ins[5].getElementsByTagName("option");
                var long=opt1.length;
                var j=0;
                while(j<long){
                    ins[5].removeChild(opt1[0]);
                    j++;
                }
                var ins=document.getElementsByClassName('in');
                const opt2=ins[6].getElementsByTagName("option");
                var long=opt2.length;
                var j=0;
                while(j<long){
                    ins[6].removeChild(opt2[0]);
                    j++;
                }
                var ina6=document.getElementsByClassName('ina6')[btns_arr.indexOf(item)].value;
                var ina7=document.getElementsByClassName('ina7')[btns_arr.indexOf(item)].value;
                var ins=document.getElementsByClassName('in');
                var option=document.createElement('option');
                var option1=document.createElement('option');
                option1.classList.add("opt");
                var option2=document.createElement('option');
                option2.classList.add("opt");
                var option3=document.createElement('option');
                option2.classList.add("opt");
                var types=["Pratique","Théorique","Théorique et Pratique"];
                var index=types.indexOf(ina6);
                types.splice(index,1);
                option1.innerHTML=ina6;
                option2.innerHTML=types[0];
                option3.innerHTML=types[1];
                ins[5].appendChild(option1);
                ins[5].appendChild(option2);
                ins[5].appendChild(option3);
                if(ina6!="Théorique"){
                    var categories=["A","B","C","D","E"];
                    var index_c=categories.indexOf(ina7);
                    categories.splice(index_c,1);
                    var option4=document.createElement('option');
                    option4.classList.add("optC");
                    var option5=document.createElement('option');
                    option5.classList.add("optC");

                    var option6=document.createElement('option');
                    option6.classList.add("optC");

                    var option7=document.createElement('option');
                    option7.classList.add("optC");
                    option4.innerHTML=ina7;
                    ins[6].appendChild(option4);
                    option5.innerHTML=categories[0];
                    ins[6].appendChild(option4);
                    option5.innerHTML=categories[1];
                    ins[6].appendChild(option5);
                    option6.innerHTML=categories[2];
                    ins[6].appendChild(option6);
                    option7.innerHTML=categories[3];
                    ins[6].appendChild(option7);
                }
                else{
                    var option=document.createElement('option');
                    option.classList.add("optC");
                    option.innerHTML='/';
                    ins[6].appendChild(option)
                }

                ins[5].addEventListener("change",()=>{
                    if(ins[5].value!="Théorique"){
                        ins[6].innerHTML='Séléctionner une categorie';
                        var optionS=document.createElement('option');
                        optionS.classList.add("optCc");
                        var optionA=document.createElement('option');
                        optionA.classList.add("optCc");
                        var optionB=document.createElement('option');
                        optionB.classList.add("optCc");
                        var optionC=document.createElement('option');
                        optionC.classList.add("optCc");
                        var optionD=document.createElement('option');
                        optionD.classList.add("optCc");
                        var optionE=document.createElement('option');
                        optionE.classList.add("optCc");
                        optionS.innerHTML='Séléctionner une catégorie';
                        optionS.selected=true;
                        optionS.hidden=true;
                        ins[6].appendChild(optionS);
                        optionA.innerHTML='A';
                        ins[6].appendChild(optionA);
                        optionB.innerHTML='B';
                        ins[6].appendChild(optionB);
                        optionC.innerHTML='C';
                        ins[6].appendChild(optionC);
                        optionD.innerHTML='D';
                        ins[6].appendChild(optionD);
                        optionE.innerHTML='E';
                        ins[6].appendChild(optionE);
                    }
                    else{
                        const opts=ins[6].getElementsByTagName("option");
                        long=opts.length;
                        var j=0;
                        while(j<long){
                            ins[6].removeChild(opt2[0]);
                            j++;
                        }
                        var optionN=document.createElement('option');
                        optionN.classList.add("optCcN");
                        optionN.innerHTML='/';
                        ins[6].appendChild(optionN)
                    }
                })
                
			})
		});
        const nom_aj=document.getElementById("nom_aj");
		const error_nom=document.getElementById("error_nom");
		const prenom_aj=document.getElementById("prenom_aj");
		const error_prenom=document.getElementById("error_prenom");
        const telephone_aj=document.getElementById("telephone_aj");
		const error_tel=document.getElementById("error-Tel");
        nom_aj.addEventListener("keyup",()=>{
			var regex=/[^a-z]/gi;
			nom_aj.value=nom_aj.value.replace(regex,"")
			if(nom_aj.classList.contains("is-valid")){
				nom_aj.classList.remove("is-valid")
			}
			else {
				if(nom_aj.classList.contains("is-invalid")){
					nom_aj.classList.remove("is-invalid")
				}
			}

			if(nom_aj.value.length==1){
				nom_aj.classList.add("is-invalid")
				error_nom.innerHTML="Le nom est invalide !"
				error_nom.style.color="red"
			}

			else{
				nom_aj.classList.add("is-valid")
				error_nom.innerHTML="Le nom est invalide !"
				error_nom.style.color="green"
			}
	
		})

		function verifierNom(){
			var regex=/[^a-z]/gi;
			nom_aj.value=nom_aj.value.replace(regex,"")
			if(nom_aj.classList.contains("is-valid")){
				nom_aj.classList.remove("is-valid")
			}
			else {
				if(nom_aj.classList.contains("is-invalid")){
					nom_aj.classList.remove("is-invalid")
				}
			}

			if(nom_aj.value.length==1){
				nom_aj.classList.add("is-invalid")
				error_nom.style.color="red"
				error_nom.innerHTML="Nom invalide !"
				return false;
				
			}
			else{
				if(nom_aj.value.length<=0){
					nom_aj.classList.add("is-invalid")
					error_nom.style.color="red"
					error_nom.innerHTML="Veuillez saisir le nom !"
					return false;
				}
				else{
					nom_aj.classList.add("is-valid")
					error_nom.innerHTML="Le nom est valide !"
					error_nom.style.color="green"
					return true;
				}
			}
		}
		function verifierPrenom(){
			var regex=/[^a-z]/gi;
			prenom_aj.value=prenom_aj.value.replace(regex,"")
			if(prenom_aj.classList.contains("is-valid")){
				prenom_aj.classList.remove("is-valid")
			}
			else {
				if(prenom_aj.classList.contains("is-invalid")){
					prenom_aj.classList.remove("is-invalid")
				}
			}
			if(prenom_aj.value.length==1){
				error_prenom.innerHTML="Le prénom est invalide !"
				prenom_aj.classList.add("is-invalid")
				error_prenom.style.color="red"
				return false;
				
			}
			else{
				if(prenom_aj.value.length<=0){
					error_prenom.innerHTML="Veuillez saisir le prénom !"
					prenom_aj.classList.add("is-invalid")
					error_prenom.style.color="red"
					return false;
				}
				else{
					prenom_aj.classList.add("is-valid")
					error_prenom.innerHTML="Le prénom est valide !"
					error_prenom.style.color="green"
					return true;
				}
			}
		}
		nom_aj.addEventListener("blur",()=>{verifierNom()});
		prenom_aj.addEventListener("keyup",()=>{
			var regex=/[^a-z]/gi;
			prenom_aj.value=prenom_aj.value.replace(regex,"")
			if(prenom_aj.classList.contains("is-valid")){
				prenom_aj.classList.remove("is-valid")
			}
			else {
				if(prenom_aj.classList.contains("is-invalid")){
					prenom_aj.classList.remove("is-invalid")
				}
			}

			if(prenom_aj.value.length==1){
				prenom_aj.classList.add("is-invalid")
				error_prenom.innerHTML="Le prénom est invalide !"
				error_prenom.style.color="red"
			}

			else{
				prenom_aj.classList.add("is-valid")
				error_prenom.innerHTML="Le prénom est valide !"
				error_prenom.style.color="green"
			}
	
		})
		prenom_aj.addEventListener("blur",()=>{
			verifierPrenom();	
		})

        telephone_aj.addEventListener("keyup",()=>{
			if(telephone_aj.classList.contains("is-valid")){
				telephone_aj.classList.remove("is-valid")
			}
			else {
				if(telephone_aj.classList.contains("is-invalid")){
					telephone_aj.classList.remove("is-invalid")
				}
			}

			telephone_aj.value=telephone_aj.value.trim();
			if(isNaN(telephone_aj.value)  || telephone_aj.value[0]=='0' || telephone_aj.value.length>9    ){
				telephone_aj.classList.add("is-invalid")
				if(isNaN(telephone_aj.value)  ){
					error_tel.innerHTML="le numero ne doit contenir que des chiffres!"
				}
				else{
					if(telephone_aj.value[0]=='0')
						error_tel.innerHTML="Le premier chiffre à saisir doit étre different de 0 !"
					else {
						error_tel.innerHTML="le numero contient plus de '10' chiffres !"
					}
				}
				error_tel.style.color="red";
				
			}
			else{
				telephone_aj.classList.remove("is-invalid")
				error_tel.innerHTML=""			
			}
		})

		function verifierTelephone(){
			if(!isNaN(telephone_aj.value) && telephone_aj.value[0]!='0' && telephone_aj.value.length==9){
				telephone_aj.classList.add("is-valid")
				error_tel.innerHTML="le numéro de téléphone est valide!"
				error_tel.style.color="green";
				return true
			}
			else{
				telephone_aj.classList.add("is-invalid")
				if(telephone_aj.value[0]=='0'){
					error_tel.innerHTML="Le premier chiffre à saisir doit étre different de 0 !"
				}
				else{
					error_tel.innerHTML="le numéro de téléphone est invalide!"
				}
				error_tel.style.color="red"
				return false

			}
		}
		const mot_passe=document.getElementById("Mot de passe");
		const mot_passe2=document.getElementById("Mot de passe2");
		telephone_aj.addEventListener("blur",()=>{
			verifierTelephone();
			
		})
	
		function verifierMotPasse(){
			if(mot_passe.classList.contains("is-valid")){
				mot_passe.classList.remove("is-valid")
			}
			else {
				if(mot_passe.classList.contains("is-invalid")){
					mot_passe.classList.remove("is-invalid")
				}
			}
			if(mot_passe.value.length<8  ){
				mot_passe.classList.add("is-invalid")
				error_mot_passe.innerHTML="le mot de passe doit contenir au moins 8 caracteres!";
				error_mot_passe.style.color="red";
				return false;
			}
			else{
				mot_passe.classList.add("is-valid")
				error_mot_passe.style.color="green";
				error_mot_passe.innerHTML="";
				return true;
				
			}
		}

		function verifierEgaliteMotPasse(){
			if(mot_passe2.classList.contains("is-valid")){
				mot_passe2.classList.remove("is-valid")
			}
			else {
				if(mot_passe2.classList.contains("is-invalid")){
					mot_passe2.classList.remove("is-invalid")
				}
			}
			if(mot_passe.value!=mot_passe2.value){
				mot_passe2.classList.add("is-invalid")
				error_mot_passe2.innerHTML="Veuillez retaper le mot de passe!";
				error_mot_passe2.style.color="red";
				return false;
			}
			else{
				mot_passe2.classList.add("is-valid")
				error_mot_passe2.style.color="green";
				error_mot_passe2.innerHTML="";
				return true;	
			}
		}

		mot_passe.addEventListener("keyup",()=>{
			verifierMotPasse();
		})


		mot_passe.addEventListener("blur",()=>{
		
			verifierMotPasse();
		})

		mot_passe2.addEventListener("keyup",()=>{
			verifierEgaliteMotPasse()
		})


		mot_passe2.addEventListener("blur",()=>{
			verifierEgaliteMotPasse()
		})

        const NumeroUtilisateur=document.getElementById("Identifiant");
		const error_identifiant=document.getElementById("error_identifiant");
		NumeroUtilisateur.addEventListener("keydown",(e)=>{
			var lettres = /[a-zA-Z]/;			
			if(lettres.test(NumeroUtilisateur.value)){
				e.preventDefault();
			}
		})

		function verifierNumeroUtilisateur(){
					
			if(NumeroUtilisateur.classList.contains("is-valid")){
				NumeroUtilisateur.classList.remove("is-valid")
			}
			else {
				if(NumeroUtilisateur.classList.contains("is-invalid")){
					NumeroUtilisateur.classList.remove("is-invalid")
				}
			}

			if(NumeroUtilisateur.value.length==0){
				NumeroUtilisateur.classList.add("is-invalid")
				error_identifiant.innerHTML="Veuillez saisir remplir ce champs !";
				error_identifiant.style.color="red";
				return false;
			}

			else{
				NumeroUtilisateur.classList.add("is-valid")
				error_identifiant.innerHTML="Le numero d'utilisateur est valide";
				error_identifiant.style.color="green";
				return true;
			}
		}


		NumeroUtilisateur.addEventListener("blur",()=>{
			verifierNumeroUtilisateur()
		})
	