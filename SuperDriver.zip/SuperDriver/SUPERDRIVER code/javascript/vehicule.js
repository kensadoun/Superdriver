        const modal = document.getElementById("user-modal");
		const form1 = document.getElementById("user-form-1");
		const search=document.getElementById("rechercher");
		function toggleModal() {
			modal.classList.toggle("active");
			form1.style.display = "block";
			form1.reset();
		}
		function showForm1() {
			form1.style.display = "block";
		}
	
        function toggleModal2() {
			document.getElementsByClassName('side-menu')[0].classList.toggle("fermer");
		}

        let btns=document.querySelectorAll('.btn1');
		let btns_arr=[...btns];
		btns_arr.forEach((item)=>{
			item.addEventListener('click',()=>{
                document.getElementsByClassName('in')[0].value=document.getElementsByClassName('ina1')[btns_arr.indexOf(item)].value;
				document.getElementsByClassName('in')[1].value=document.getElementsByClassName('ina2')[btns_arr.indexOf(item)].value;
				//document.getElementsByClassName('in')[2].value=document.getElementsByClassName('ina3')[btns_arr.indexOf(item)].value;
                //alert(document.getElementsByClassName('ina3')[btns_arr.indexOf(item)].value)
				document.getElementsByClassName('in')[3].value=document.getElementsByClassName('ina4')[btns_arr.indexOf(item)].value;
                //alert(document.getElementsByClassName('ina4')[btns_arr.indexOf(item)].value)
				document.getElementsByClassName('in')[4].value=document.getElementsByClassName('ina5')[btns_arr.indexOf(item)].value;


                var ins=document.getElementsByClassName('in');
                const opt1=ins[2].getElementsByTagName("option");
                var long=opt1.length;
                var j=0;
                while(j<long){
                    ins[2].removeChild(opt1[0]);
                    j++;
                }

                var ina3=document.getElementsByClassName('ina3')[btns_arr.indexOf(item)].value;

                var categories=["A","B","C","D","E"];
                var index_c=categories.indexOf(ina3);
                categories.splice(index_c,1);

                var option1=document.createElement('option');
                option1.classList.add("opt");

                var option2=document.createElement('option');
                option2.classList.add("opt");

                var option3=document.createElement('option');
                option2.classList.add("opt");

                var option4=document.createElement('option');
                option2.classList.add("opt");

                var option5=document.createElement('option');
                option2.classList.add("opt");


                option1.innerHTML=ina3;
                option2.innerHTML=categories[0];
                option3.innerHTML=categories[1];
                option4.innerHTML=categories[2];
                option5.innerHTML=categories[3];

                ins[2].appendChild(option1);
                ins[2].appendChild(option2);
                ins[2].appendChild(option3);
                ins[2].appendChild(option4);
                ins[2].appendChild(option5);

                
			})
		});