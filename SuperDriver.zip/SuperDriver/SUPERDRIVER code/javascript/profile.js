const sub=document.getElementById("f1");
const mot_passe=document.getElementById("inputPassword");
const mot_passe2=document.getElementById("inputPassword2");
const error_mot_passe=document.getElementsByClassName("error_mot_passe")[0];
const error_mot_passe2=document.getElementsByClassName("error_mot_passe")[1];
sub.addEventListener("submit",(e)=>{
    e.preventDefault();
    if(verifierMotPasse() && verifierEgaliteMotPasse()){
        sub.submit()
    }
})
function verifierMotPasse(){
    //alert(mot_passe.value)
    if(mot_passe.classList.contains("is-valid")){
        mot_passe.classList.remove("is-valid")
    }
    else {
        if(mot_passe.classList.contains("is-invalid")){
            mot_passe.classList.remove("is-invalid")
        }
    }
    if(mot_passe.value.length<8  ){
        mot_passe.classList.add("is-invalid")
        error_mot_passe.innerHTML="le mot de passe doit contenir au moins 8 caracteres!";
        error_mot_passe.style.color="red";
        return false;
    }
    else{
        mot_passe.classList.add("is-valid")
        error_mot_passe.style.color="green";
        error_mot_passe.innerHTML="";

        return true;
        
    }
}

function verifierEgaliteMotPasse(){
    //alert(mot_passe.value)
    /*if(mot_passe2.classList.contains("is-valid")){
        mot_passe2.classList.remove("is-valid")
    }
    else {
        if(mot_passe2.classList.contains("is-invalid")){
            mot_passe2.classList.remove("is-invalid")
        }
    }*/
    if(mot_passe.value!=mot_passe2.value){
        alert("fdf")
        
        //mot_passe2.classList.add("is-invalid")
        error_mot_passe2.innerHTML="Veuillez retaper le mot de passe!";
        error_mot_passe2.style.color="red";
        return false;
        
    }
    else{
        alert("rf")
        //mot_passe2.classList.add("is-valid")
        error_mot_passe2.style.color="green";
        error_mot_passe2.innerHTML="";
        return true;	
    }
}

mot_passe.addEventListener("keyup",()=>{
    verifierMotPasse();
})


mot_passe.addEventListener("blur",()=>{

    verifierMotPasse();
})

/*mot_passe2.addEventListener("click",()=>{
    verifierMotPasse()
    //verifierEgaliteMotPasse()
})


mot_passe2.addEventListener("blur",()=>{
    verifierMotPasse()
    //verifierEgaliteMotPasse()
})*/


