<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title>Auto-ecole</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">

    
</head>
<header class="mainhead">
    <nav>
        <img src="logo.png" alt="Description de l'image" class="logo">
        <ul>
            <li><a href='index.php'class='ligne'>Accueil</a></li>
            <li><a href='code de la route.php'class='ligne'>Code de la route</a></li>
            <li><a href='type de permis.php'class='ligne'>type de permis</a></li>
            <li><a href='connexion.php' class="con">Connexion</a></li>
        </ul>
    </nav>

</header>
<body>
    
    
    <script src="javascript/script.js"></script>
</body>
</html>