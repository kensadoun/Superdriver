<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title>Auto-ecole</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<header class="mainhead">
    <nav>
        <img src="logo.png" alt="Description de l'image" class="logo">
        <ul>
            <li><a href='index.php'class='ligne'>Accueil</a></li>
            <li><a href='code de la route.php'class='ligne'>Code de la route</a></li>
            <li><a href='type de permis.php'class='ligne'>type de permis</a></li>
            <li><a href='connexion.php' class="con">Connexion</a></li>
        </ul>
    </nav>


</header>
<body >
    <img src="type.PNG" alt="Description de l'image" class="imagetype" >
    <img src="code.PNG" alt="Description de l'image" class="imagecode">
    <p class="par1" id="text">L'auto-ecole numèro une pour réussir son permis avec l'apprentissage le plus simple. </p>
    <p class="par2">Super Driver est un etablissement agréé et déclaré  organisme de formation avec un taux de 94% de réussite.
    </p>
    <p class="par3">Souriez! Vous allez avoir votre permis </p>
    <div class="par4">
    <p >Avant de décrocher votre permis de conduire il vous faut réussir 
        le code de la route ! Un prérequis qui correspand à la partie théorique de 
        l'apprentissage et de la conduite.
    </p>
    <p>
        Que vous passiez votre code de la route pour la premiére fois ou que vous souhaitiez
        le repaser ,Super Driver est la pour vous accompagner.
    </p>
</div>
<img src="imageacceuil.png" alt="Description de l'image" class="imageacceuil" >
<p class="par5">Devenez un as du volant </p>
<p class="par6">une fois les base thèorique aquise ,Super Driver est la pour vous accompaner dans votre
    apprentissage de la conduite et cela dans plusieurs categorie de véhicules,alors n'hesiter plus a nos 
    rejoindre et a vous inscrire au niveaux de notre etablissement.
     </p>
     <p class="par7">A très vite.</p>
     <footer>
        <p>&copy; 2023 Super Driver</p>
        <p class="add">Addrese :34 Rue de la liberté</p>
        <p class="add">Contact :SuperDriver@gmail.com</p>
      </footer>
      
    <script src="javascript/script.js"></script>
</body>
</html>